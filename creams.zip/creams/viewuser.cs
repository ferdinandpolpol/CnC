﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace creams
{
    public partial class viewuser : Form
    {
        MySqlConnection conn;
        public viewuser()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;");
        }
        
    private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //This is for an error when you press the table header, it will show an error in the syntax
            try
            {
                //Collects the values from the tables to the textbox's
                fnametxtbox.Text = dataGridView1.Rows[e.RowIndex].Cells["firstname"].Value.ToString();
                lnametxtbox.Text = dataGridView1.Rows[e.RowIndex].Cells["lastname"].Value.ToString();
                usertxtbox.Text = dataGridView1.Rows[e.RowIndex].Cells["username"].Value.ToString();
                passtxtbox.Text = dataGridView1.Rows[e.RowIndex].Cells["password"].Value.ToString();
                textBox4.Text = dataGridView1.Rows[e.RowIndex].Cells["staffid"].Value.ToString();
                
                //Checks for the stafftype value
                string type = dataGridView1.Rows[e.RowIndex].Cells["stafftype"].Value.ToString();
                //
                textBox6.Text = dataGridView1.Rows[e.RowIndex].Cells["active"].Value.ToString();

                //Checks if the user is an admin
                if (!checkadmin())
                {
                    activatebtn.Enabled = false;
                    deactivatebtn.Enabled = false;
                }
                //Else, disable activate and deactivate buttons
                else
                {
                    if (textBox6.Text == "Active")
                    {
                        activatebtn.Enabled = false;
                        deactivatebtn.Enabled = true;
                    }
                    else if (textBox6.Text == "Inactive")
                    {
                        activatebtn.Enabled = true;
                        deactivatebtn.Enabled = false;
                    }
                }
                
                
                //Checker for which staff type to preload a checked radio
                if (type == "Admin")
                {
                    adminradio.Checked = true;
                }
                else if (type == "Staff")
                {
                    staffradio.Checked = true;
                }
            }
            catch (Exception er)
            {
                showinactive();
                //This is to prevent an error in the code when the table header is pressed
                //No message is shown to prevent annoying, repeating message
            }
        }

        private void viewuser_Load(object sender, EventArgs e)
        {
            button1.Visible = false;
            button2.Visible = false;
            textBox4.Enabled = false;
            fnametxtbox.Enabled = false;
            lnametxtbox.Enabled = false;
            usertxtbox.Enabled = false;
            passtxtbox.Enabled = false;
            refreshdatabase();

            //If not admin, hide the add button 
            if (!checkadmin())
            {
                adduserbtn.Visible = false;
                activatebtn.Enabled = false;
                deactivatebtn.Enabled = false;
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            //checks for the staff type radio button
            string type = "";
            if (adminradio.Checked)
            {
                type = adminradio.Text;
            }
            else if (staffradio.Checked)
            {
                type = staffradio.Text;
            }
            
            //Verifies that all fields are populated
            if (string.IsNullOrWhiteSpace(lnametxtbox.Text) ||
                string.IsNullOrWhiteSpace(usertxtbox.Text) ||
                string.IsNullOrWhiteSpace(passtxtbox.Text) ||
                string.IsNullOrWhiteSpace(fnametxtbox.Text) || 
                type == null)
            {
                //Shows error message
                MessageBox.Show("Error: Empty field/s");
            }
            //If all conditions satisfied, this will update the user
            else
            {
                conn.Open();
                /*
                //checks if user is existing
                string checkuser = "select * from staff where username='" + textBox2.Text + "'";
                MySqlCommand check = new MySqlCommand(checkuser, conn);
                MySqlDataAdapter adp = new MySqlDataAdapter(check);
                DataTable dt = new DataTable();
                adp.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    // Problem, if user will not change the username of the selection from view user, it will
                    // show the error message username already exists
                     * Pseudo fix
                     * if textboxt2.Text == checkuser
                     *  continue
                     * else
                     *  Error!
                     
                    MessageBox.Show("Username already exists!");
                    textBox2.Clear();
                    conn.Close();
                }*/
                //else
                //{
                //Updates the user values
                string q = "update staff set firstname='" + fnametxtbox.Text + "',lastname='"
                        + lnametxtbox.Text + "',username='" + usertxtbox.Text + "',password='"
                        + passtxtbox.Text + "',stafftype='" + type + "' where staffid='" + textBox4.Text + "'";
                MySqlCommand comm = new MySqlCommand(q, conn);
                comm.ExecuteNonQuery();
                conn.Close();

                    // Informs the user for succesful update
                MessageBox.Show("Successfully updated user " + fnametxtbox.Text + ", " + lnametxtbox.Text + "!");
                //}
                refreshdatabase();
                refreshtext();
                button1.Visible = false;
                button2.Visible = false;
                fnametxtbox.Enabled = false;
                lnametxtbox.Enabled = false;
                usertxtbox.Enabled = false;
                passtxtbox.Enabled = false;
            }
        }

        //Activate Button
        private void button1_Click(object sender, EventArgs e)
        {
            //Enables the activate button
            activatebtn.Enabled = true;
            conn.Open();
            //Update staff status to active
            string q = "update staff set active='Active' where staffid='" + textBox4.Text + "'";
            MySqlCommand comm = new MySqlCommand(q, conn);
            comm.ExecuteNonQuery();
            MessageBox.Show("User " + fnametxtbox.Text + ", " + lnametxtbox.Text + " Activated!");
            conn.Close();
            refreshdatabase();
            refreshtext();
            activatebtn.Enabled = true;
            deactivatebtn.Enabled = true;
        }

        //Deactivate Button
        private void button2_Click(object sender, EventArgs e)
        {
            //enables the deactivate button
            deactivatebtn.Enabled = true;
            conn.Open();
            //Update staff status to inactive
            string q = "update staff set active='Inactive' where staffid='" + textBox4.Text + "'";
            MySqlCommand comm = new MySqlCommand(q, conn);
            comm.ExecuteNonQuery();
            MessageBox.Show("User " + fnametxtbox.Text + ", " + lnametxtbox.Text + " Deactivated!");
            conn.Close();
            //}
            refreshdatabase();
            refreshtext();
            activatebtn.Enabled = true;
            deactivatebtn.Enabled = true;
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            button1.Visible = false;
            button2.Visible = false;
            fnametxtbox.Enabled = false;
            lnametxtbox.Enabled = false;
            usertxtbox.Enabled = false;
            passtxtbox.Enabled = false;
        }
        
        //Methods
        private void refreshdatabase()
        {
            conn.Open();
            //selects all the staff from the database
            MySqlCommand comm = new MySqlCommand("select * from staff order by active, firstname", conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm); //used on select query only
            DataTable dt = new DataTable();
            adp.Fill(dt);

            //Loads the database values to the dataGridView
            dataGridView1.DataSource = dt;

            showinactive();
            conn.Close();

            //.Visible removes the unnecessary and valuable information
            dataGridView1.Columns["staffid"].Visible = false;
            dataGridView1.Columns["password"].Visible = false;

            //Changes the header text from the database
            dataGridView1.Columns["firstname"].HeaderText = "Firstname";
            dataGridView1.Columns["lastname"].HeaderText = "Lastname";
            dataGridView1.Columns["username"].HeaderText = "Username";
            dataGridView1.Columns["stafftype"].HeaderText = "Staff Type";
            dataGridView1.Columns["active"].HeaderText = "Status";

        }
        //Clears all Textbox
        private void refreshtext()
        {
            lnametxtbox.Clear();
            usertxtbox.Clear();
            passtxtbox.Clear();
            textBox4.Clear();
            fnametxtbox.Clear();
            textBox6.Clear();
        }
        //Makes inactive users show a color red row
        private void showinactive()
        {

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if ((string)row.Cells["active"].Value == "Inactive")
                {
                    row.DefaultCellStyle.BackColor = Color.IndianRed;
                }
            }
        }
        private bool checkadmin()
        {
            conn.Open();
            //checks user privilege
            string query = "select stafftype from staff where username like '" + loginform.currentuser + "'";
            MySqlCommand comm = new MySqlCommand(query, conn);

            string privilege = Convert.ToString(comm.ExecuteScalar());
            conn.Close();
            if (privilege == "Admin")
                return true;
            else
                return false;
        }

        private void adduserbtn_Click(object sender, EventArgs e)
        {
            newuser nu = new creams.newuser();
            nu.ShowDialog();
            refreshdatabase();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            button1.Visible = true;
            button2.Visible = true;
            fnametxtbox.Enabled = true;
            lnametxtbox.Enabled = true;
            usertxtbox.Enabled = true;
            passtxtbox.Enabled = true;
        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
