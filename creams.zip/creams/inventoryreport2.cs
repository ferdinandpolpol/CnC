﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace creams
{
    public partial class inventoryreport2 : Form
    {
        public inventoryreport2()
        {
            InitializeComponent();
        }

        public static string fromDate;
        public static string toDate;
        public static bool prodbutton1;
        public static bool prodbutton2;
        public static bool prodbutton3;

        private void button3_Click(object sender, EventArgs e)
        {
            inventoryreport.generate1 = false;
            inventoryreport.generate2 = false;
            inventoryreport.generate3 = false;
            prodbutton1 = true;
            prodbutton2 = false;
            prodbutton3 = false;
            fromDate = dateTimePicker1.Value.Date.ToString("yyyy-MM-dd 00:00");
            toDate = dateTimePicker2.Value.Date.AddDays(1).AddSeconds(-1).ToString("yyyy-MM-dd HH:mm");
            showinvreport sr = new showinvreport();
            sr.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            inventoryreport.generate1 = false;
            inventoryreport.generate2 = false;
            inventoryreport.generate3 = false;
            prodbutton1 = false;
            prodbutton2 = true;
            prodbutton3 = false;
            showinvreport sr = new showinvreport();
            sr.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            inventoryreport.generate1 = false;
            inventoryreport.generate2 = false;
            inventoryreport.generate3 = false;
            prodbutton1 = false;
            prodbutton2 = false;
            prodbutton3 = true;
            showinvreport sr = new showinvreport();
            sr.ShowDialog();
        }
    }
}
