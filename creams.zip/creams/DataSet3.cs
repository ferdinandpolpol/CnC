﻿namespace creams
{


    partial class DataSet3
    {
        partial class DataTable1DataTable
        {
        }
    }
}
