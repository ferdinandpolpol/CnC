﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;


namespace creams
{
    public partial class salesreport : Form
    {
        MySqlConnection conn;
        public static string orderid;
        public static bool active;
        public salesreport()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;");
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
        private void refreshdatabase()
        {
            conn.Open();
            string query = "SELECT orders.date,p.orderid,concat(customer.lastname, ', ', customer.firstname) as 'Customer',GROUP_CONCAT(Distinct CONCAT(ol.quantity, ' ', ol.productname)) AS 'Orders',orders.total AS 'Total',p.amount as 'Paid',orders.discount,'', p.remaining, p.type " +
 " FROM orders, customer, payments p,orderline ol " +
 " WHERE orders.type != 'Delivery' and orders.customerid = customer.customerid AND orders.orderid = p.orderid AND orders.orderid = ol.orderid and p.orderid = ol.orderid GROUP BY orderid " +
 " union all " +
 " select orders.date, p.orderid, 'Walk-in', GROUP_CONCAT(Distinct CONCAT(ol.quantity, ' ', ol.productname)) AS 'Orders',orders.total AS 'Total',p.amount as 'Paid',orders.discount,'', p.remaining, p.type " +
 " from orders, payments p, orderline ol " +
 " where orders.type != 'Delivery' and orders.customerid = 0 and orders.orderid = p.orderid and orders.orderid = ol.orderid and p.orderid = ol.orderid group by orderid order by date desc";
            MySqlCommand comm = new MySqlCommand(query, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView1.DataSource = dt;
            dataGridView1.Columns["orderid"].HeaderText = "Order #";
            dataGridView1.Columns["type"].Visible = false;

            dataGridView1.Columns[7].Visible = false;
            dataGridView1.Columns["date"].HeaderText = "Date";
            dataGridView1.Columns["remaining"].HeaderText = "Balance";
            //dataGridView1.Columns["due"].HeaderText = "Payment Due";
            //dataGridView1.Columns["paychange"].Visible = false;

            string q = "select r.date,rl.returnlineid, rl.returnid, ol.productname, rl.productstatus, rl.returntype, rl.quantityreturned, rl.subtotal, rl.action from returnline rl, orderline ol, creamsncrumbs.`return` r where rl.orderlineid=ol.orderlineid and r.returnid=rl.returnid and rl.returntype='Refund' order by returnlineid desc";
            MySqlCommand comm1 = new MySqlCommand(q, conn);
            MySqlDataAdapter adp1 = new MySqlDataAdapter(comm1);
            DataTable dt1 = new DataTable();
            adp1.Fill(dt1);
            dataGridView2.DataSource = dt1;

            dataGridView1.Columns[0].HeaderText = "Date";
            dataGridView2.Columns[1].Visible = false;
            dataGridView2.Columns[2].HeaderText = "Return #";
            dataGridView2.Columns[3].HeaderText = "Product";
            dataGridView2.Columns[4].HeaderText = "Status"; ;
            dataGridView2.Columns[5].HeaderText = "Type"; ;
            dataGridView2.Columns[6].HeaderText = "Quantity Returned"; ;
            dataGridView2.Columns[7].HeaderText = "Subtotal"; ;
            dataGridView2.Columns[8].HeaderText = "Action";


            conn.Close();

            double sales = 0;
            double amount = 0;
            double discount = 0;
            double returns = 0;
            foreach(DataGridViewRow row in dataGridView1.Rows)
            {
                sales += Convert.ToDouble(row.Cells[4].Value);
                amount += Convert.ToDouble(row.Cells[5].Value);
                discount += Convert.ToDouble(row.Cells["discount"].Value);
            }
            foreach (DataGridViewRow row in dataGridView2.Rows)
            {
                returns += Convert.ToDouble(row.Cells[7].Value);
            }
            label3.Text = sales.ToString();
            label16.Text = amount.ToString();
            label8.Text = (sales - amount).ToString();
            label4.Text = discount.ToString();
            label10.Text = returns.ToString();

            
        }
        private void orders_Load(object sender, EventArgs e)
        {
            refreshdatabase();
            dataGridView2.Visible = false;
            button6.Visible = false;
            crystalReportViewer1.Visible = false;
            fillfilter();
            button4.Visible = false;
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            
            orderdetails od = new orderdetails();
            active = true;
            od.ShowDialog();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            orderid = dataGridView1["orderid", dataGridView1.CurrentRow.Index].Value.ToString();
        }



        private void orders_FormClosing(object sender, FormClosingEventArgs e)
        {
            active = false;
            orderid = null;
        }

        private void fillfilter()
        {
            comboBox1.Items.Add("All");
            comboBox1.Items.Add("Today");
            comboBox1.Items.Add("Week");
            comboBox1.Items.Add("Month");
            comboBox1.Items.Add("Year");
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(comboBox1.Text == "All")
            {
                refreshdatabase();
            }
            else
            {
                string range = "1 DAY";
                if(comboBox1.Text == "Today")
                {
                    range = "1 DAY";
                }
                else if (comboBox1.Text == "Week")
                {
                    range = "1 WEEK";
                }
                else if (comboBox1.Text == "Month")
                {
                    range = "1 MONTH";
                }
                else if (comboBox1.Text == "Year")
                {
                    range = "1 YEAR";
                }
                string query = "SELECT orders.date,p.orderid,concat(customer.lastname, ', ', customer.firstname) as 'Customer',GROUP_CONCAT(Distinct CONCAT(ol.quantity, ' ', ol.productname)) AS 'Orders',orders.total AS 'Total',p.amount as 'Paid',orders.discount,'', p.remaining, p.type " +
 " FROM orders, customer, payments p,orderline ol " +
 " WHERE (orders.date BETWEEN (CURRENT_DATE() - INTERVAL " + range + ") AND NOW()) and orders.type != 'Delivery' and orders.customerid = customer.customerid AND orders.orderid = p.orderid AND orders.orderid = ol.orderid and p.orderid = ol.orderid GROUP BY orderid " +
 " union all " +
 " select orders.date, p.orderid, 'Walk-in', GROUP_CONCAT(Distinct CONCAT(ol.quantity, ' ', ol.productname)) AS 'Orders',orders.total AS 'Total',p.amount as 'Paid',orders.discount,'', p.remaining, p.type " +
 " from orders, payments p, orderline ol " +
 " where (orders.date BETWEEN (CURRENT_DATE() - INTERVAL "+range+") AND NOW()) and orders.type != 'Delivery' and orders.customerid = 0 and orders.orderid = p.orderid and orders.orderid = ol.orderid and p.orderid = ol.orderid group by orderid order by date desc";
                MySqlCommand comm = new MySqlCommand(query, conn);
                MySqlDataAdapter adp = new MySqlDataAdapter(comm);
                DataTable dt = new DataTable();
                adp.Fill(dt);

                dataGridView1.DataSource = dt;
                dataGridView1.Columns["orderid"].HeaderText = "Order #";
                dataGridView1.Columns["type"].Visible = false;

                dataGridView1.Columns[7].Visible = false;
                dataGridView1.Columns["date"].HeaderText = "Date";
                dataGridView1.Columns["remaining"].HeaderText = "Balance";

                double sales = 0;
                double amount = 0;
                double discount = 0;
                double returns = 0;
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    sales += Convert.ToDouble(row.Cells[4].Value);
                    amount += Convert.ToDouble(row.Cells[5].Value);
                    discount += Convert.ToDouble(row.Cells["discount"].Value);
                }
                foreach (DataGridViewRow row in dataGridView2.Rows)
                {
                    returns += Convert.ToDouble(row.Cells[7].Value);
                }
                label3.Text = sales.ToString();
                label16.Text = amount.ToString();
                label8.Text = (sales - amount).ToString();
                label4.Text = discount.ToString();
                label10.Text = returns.ToString();
            }
            
            
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if(orderid == null)
            {
                MessageBox.Show("Please select an order.");
            }
            else
            {
                active = true;

                orderdetails od = new orderdetails();
                od.ShowDialog();
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string s = System.IO.Directory.GetCurrentDirectory().ToString();


            int x = s.IndexOf("bin\\Debug");
            if (x != -1)
            {
                s = s.Remove(x);
            }
            s += "CrystalReport2.rpt";
            crystalReportViewer1.Visible = true;
            ReportDocument cryRpt = new ReportDocument();
            cryRpt.Load(@s);
            if (apply)
            {
                ParameterFieldDefinitions crParameterFieldDefinitions;
                ParameterFieldDefinition crParameterFieldDefinition;
                ParameterValues crParameterValues = new ParameterValues();
                ParameterDiscreteValue crParameterDiscreteValue = new ParameterDiscreteValue();

                crParameterDiscreteValue.Value = dateTimePicker1.Value.Date.ToString("yyyy-MM-dd");
                crParameterFieldDefinitions = cryRpt.DataDefinition.ParameterFields;
                crParameterFieldDefinition = crParameterFieldDefinitions["fromDate"];
                crParameterValues = crParameterFieldDefinition.CurrentValues;

                crParameterValues.Clear();
                crParameterValues.Add(crParameterDiscreteValue);
                crParameterFieldDefinition.ApplyCurrentValues(crParameterValues);

                crParameterDiscreteValue.Value = (dateTimePicker2.Value.Date).AddDays(1).ToString("yyyy-MM-dd");
                crParameterFieldDefinitions = cryRpt.DataDefinition.ParameterFields;
                crParameterFieldDefinition = crParameterFieldDefinitions["toDate"];
                crParameterValues = crParameterFieldDefinition.CurrentValues;

                crParameterValues.Clear();
                crParameterValues.Add(crParameterDiscreteValue);
                crParameterFieldDefinition.ApplyCurrentValues(crParameterValues);
            }
            else if(cancel)
            {
                ParameterFieldDefinitions crParameterFieldDefinitions;
                ParameterFieldDefinition crParameterFieldDefinition;
                ParameterValues crParameterValues = new ParameterValues();
                ParameterDiscreteValue crParameterDiscreteValue = new ParameterDiscreteValue();

                crParameterDiscreteValue.Value = (dateTimePicker1.Value.Date).AddYears(-99).ToString("yyyy-MM-dd");
                crParameterFieldDefinitions = cryRpt.DataDefinition.ParameterFields;
                crParameterFieldDefinition = crParameterFieldDefinitions["fromDate"];
                crParameterValues = crParameterFieldDefinition.CurrentValues;

                crParameterValues.Clear();
                crParameterValues.Add(crParameterDiscreteValue);
                crParameterFieldDefinition.ApplyCurrentValues(crParameterValues);

                crParameterDiscreteValue.Value = (dateTimePicker2.Value.Date).AddYears(99).ToString("yyyy-MM-dd");
                crParameterFieldDefinitions = cryRpt.DataDefinition.ParameterFields;
                crParameterFieldDefinition = crParameterFieldDefinitions["toDate"];
                crParameterValues = crParameterFieldDefinition.CurrentValues;

                crParameterValues.Clear();
                crParameterValues.Add(crParameterDiscreteValue);
                crParameterFieldDefinition.ApplyCurrentValues(crParameterValues);
            }
            
            crystalReportViewer1.ReportSource = cryRpt;
            crystalReportViewer1.Refresh();
            button4.Visible = true;

        }
        bool apply = false;
        bool cancel = true;
        private void button2_Click(object sender, EventArgs e)
        {
            apply = true;
            cancel = false;
            DateTime toDate = dateTimePicker2.Value.Date;
            string query = "SELECT orders.date, p.orderid, CONCAT(customer.lastname, ', ', customer.firstname) AS 'Customer', GROUP_CONCAT(DISTINCT CONCAT(ol.quantity, ' ', ol.productname)) AS 'Orders', orders.total AS 'Total', p.amount AS 'Paid', orders.discount, '', p.remaining, p.type"
+" FROM orders, customer, payments p, orderline ol"
+" WHERE (orders.date BETWEEN '"+dateTimePicker1.Value.Date.ToString("yyyy-MM-dd")+ "' AND '" + toDate.AddDays(1).ToString("yyyy-MM-dd") + "') AND orders.type != 'Delivery' AND orders.customerid = customer.customerid AND orders.orderid = p.orderid AND orders.orderid = ol.orderid AND p.orderid = ol.orderid"
+ " GROUP BY orderid"
+" UNION ALL SELECT orders.date, p.orderid, 'Walk-in', GROUP_CONCAT(DISTINCT CONCAT(ol.quantity, ' ', ol.productname)) AS 'Orders', orders.total AS 'Total', p.amount AS 'Paid', orders.discount, '', p.remaining, p.type"
+" FROM orders, payments p, orderline ol"
+ " WHERE (orders.date BETWEEN '" + dateTimePicker1.Value.Date.ToString("yyyy-MM-dd") + "' AND '" + toDate.AddDays(1).ToString("yyyy-MM-dd") + "') AND orders.type != 'Delivery' AND orders.customerid = 0 AND orders.orderid = p.orderid AND orders.orderid = ol.orderid AND p.orderid = ol.orderid"
+ " GROUP BY orderid ORDER BY date DESC";
            MySqlCommand comm = new MySqlCommand(query, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView1.DataSource = dt;

            double sales = 0;
            double amount = 0;
            double discount = 0;
            double returns = 0;
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                sales += Convert.ToDouble(row.Cells[4].Value);
                amount += Convert.ToDouble(row.Cells[5].Value);
                discount += Convert.ToDouble(row.Cells["discount"].Value);
            }
            foreach (DataGridViewRow row in dataGridView2.Rows)
            {
                returns += Convert.ToDouble(row.Cells[7].Value);
            }
            label3.Text = sales.ToString();
            label16.Text = amount.ToString();
            label8.Text = (sales - amount).ToString();
            label4.Text = discount.ToString();
            label10.Text = returns.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            cancel = true;
            apply = false;
            refreshdatabase();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            crystalReportViewer1.Visible = false;
            button4.Visible = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            dataGridView2.Visible = true;
            button5.Visible = false;
            button6.Visible = true;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            dataGridView2.Visible = false;
            button5.Visible = true;
            button6.Visible = false;
        }
    }
}
