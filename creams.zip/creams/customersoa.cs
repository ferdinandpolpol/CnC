﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace creams
{
    public partial class customersoa : Form
    {
        MySqlConnection conn;
        private string tempfname;
        private string tempstatus;
        private string templname;
        private string tempcontact;
        private string tempaddress;
        public customersoa()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;");
        }

        private void customersoa_Load(object sender, EventArgs e)
        {

            disableupdate();

            fillcustomerdetails();

            label10.Text = viewcustomer.custid;

            comboBox1.Items.Add("Active");
            comboBox1.Items.Add("Inactive");
            refreshdatabase();
        }
        private void refreshdatabase()
        {
            conn.Open();
            string query = "select orders.orderid, orders.total as 'Purchase amount', concat(staff.lastname, ', ', staff.firstname) as 'Staff'  from orders, customer, staff where orders.customerid=" + label10.Text + " and orders.total>0 and orders.customerid=customer.customerid and orders.staffid=staff.staffid";
            MySqlCommand comm = new MySqlCommand(query, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView1.DataSource = dt;

            label11.Text = totalpurchase().ToString();
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void disableupdate()
        {
            button1.Visible = false;
            button2.Visible = false;
            comboBox1.Enabled = false;
            textBox2.Enabled = false;
            textBox3.Enabled = false;
            textBox4.Enabled = false;
            textBox5.Enabled = false;
        }
        private void enableupdate()
        {
            button1.Visible = true;
            button2.Visible = true;
            comboBox1.Enabled = true;
            textBox2.Enabled = true;
            textBox3.Enabled = true;
            textBox4.Enabled = true;
            textBox5.Enabled = true;
        }
        private void button3_Click(object sender, EventArgs e)
        {
            tempfname = textBox2.Text;
            templname = textBox3.Text;
            tempcontact = textBox5.Text;
            tempaddress = textBox4.Text;
            tempstatus = comboBox1.Text;
            enableupdate();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            disableupdate();
            textBox2.Text = tempfname;
            textBox3.Text = templname;
            textBox5.Text = tempcontact;
            textBox4.Text = tempaddress;
            comboBox1.Text = tempstatus;
        }
        private void fillcustomerdetails()
        {
            string q = "select * from customer where customerid = '" + viewcustomer.custid + "'";
            conn.Open();
            MySqlCommand cmdDataBase = new MySqlCommand(q, conn);
            MySqlDataReader myReader;

            myReader = cmdDataBase.ExecuteReader();

            while (myReader.Read())
            {
                string fname = myReader.GetString("firstname");
                string lname = myReader.GetString("lastname");
                string status = myReader.GetString("status");
                string contact = myReader.GetString("contact");
                string address = myReader.GetString("address");

                textBox2.Text = fname;
                textBox3.Text = lname;
                textBox4.Text = address;
                textBox5.Text = contact;
                comboBox1.Text = status;
            }
            conn.Close();
        }
        private double totalpurchase()
        {
            try
            {
                string query = "select sum(total) from orders where customerid=" + label10.Text;
                MySqlCommand comm = new MySqlCommand(query, conn);
                double total = Convert.ToDouble(comm.ExecuteScalar());

                return total;
            }
            catch(Exception er)
            {
                return 0;
            }

            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string q = "update customer set firstname = '" + textBox2.Text + "', lastname = '" + textBox3.Text + "', contact = '" + textBox5.Text + "', address = '" + textBox4.Text + "', status = '" + comboBox1.Text + "' where customerid=" + label10.Text;
            MySqlCommand comm = new MySqlCommand(q, conn);
            comm.ExecuteNonQuery();
            MessageBox.Show("Updated user!");
            disableupdate();
        }
    }
}
