﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace creams
{
    public partial class newsupplier : Form
    {
        public MySqlConnection conn;
        public newsupplier()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;");
        }

        private void submitbtn_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrWhiteSpace(suppliername.Text) ||
                string.IsNullOrWhiteSpace(contact.Text) ||
                string.IsNullOrWhiteSpace(address.Text))
            {
                MessageBox.Show("Empty field/s");
            }
            else
            {
                conn.Open();
                string q = "insert into supplier(suppliername, suppliercontact, supplieraddress) values('" + suppliername.Text + "','" + contact.Text + "','" + address.Text + "')";
                MySqlCommand comm = new MySqlCommand(q, conn);
                comm.ExecuteNonQuery();
                MessageBox.Show("Supplier added!");
                conn.Close();
            }
            this.Close();
        }

        private void cancelbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void contact_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }
    }
}
