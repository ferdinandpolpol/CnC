﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace creams
{
    public partial class payment : Form
    {
        MySqlConnection conn;
        public payment()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;");
        }

        public static bool cancel;
        public static string amount;
        public static string total;
        public static string change;
        private void payment_Load(object sender, EventArgs e)
        {
            cancel = false;                                 //Restate cancel to false
            if(neworder.active == true)
            {
                textBox1.Text = neworder.customerid;
                orderidtxt.Text = neworder.orderid;
                totaltxtbox.Text = neworder.total;
            }
            else if(newsalesorder.active == true)
            {
                textBox1.Text = newsalesorder.customerid;
                orderidtxt.Text = newsalesorder.orderid;
                totaltxtbox.Text = newsalesorder.total;
            }
            changetxtbox.Text = 0.ToString();
            amounttxtbox.Text = 0.ToString();
            radioButton1.Checked = true;
            
            textBox2.Enabled = false;
            dateTimePicker1.Enabled = false;

            if(textBox1.Text == 0.ToString())
            {
                radioButton2.Enabled = false;
            }
            else
            {
                getcustomerbalance();
            }
            
            dateTimePicker1.MinDate = DateTime.Now;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            neworder.active = false;
            newsalesorder.active = false;
            this.Close();
            cancel = true;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private double getchange()
        {
            try
            {
                double change = Convert.ToDouble(amounttxtbox.Text) - Convert.ToDouble(totaltxtbox.Text);
                return change;
            }
            catch(Exception er)
            {
                return 0;
            }
            
        }

        private void amounttxtbox_TextChanged(object sender, EventArgs e)
        {
            changetxtbox.Text = getchange().ToString();
        }
        bool submitted;

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                if (string.IsNullOrWhiteSpace(amounttxtbox.Text))
                {
                    MessageBox.Show("Please enter an amount");
                }
                else if (Convert.ToDouble(amounttxtbox.Text) < Convert.ToDouble(totaltxtbox.Text) || amounttxtbox.Text == 0.ToString())
                {
                    MessageBox.Show("Insufficient amount");
                }
                else
                {
                    submitted = true;
                    double credit = Math.Abs(Convert.ToDouble(changetxtbox.Text));
                    conn.Open();
                    string q = "insert into payments(orderid, total, amount, type, remaining, due,status) values('" + orderidtxt.Text + "','" + totaltxtbox.Text + "','" + totaltxtbox.Text + "', 'Regular', '0', now(), 'Paid');"
                            + "insert into paymentline(customerid, paymentid, balance, payment, paychange) values('" + textBox1.Text + "','" + getpaymentid() + "','" + credit + "','" + amounttxtbox.Text + "','"+changetxtbox.Text+"')";              
                    MySqlCommand comm = new MySqlCommand(q, conn);
                    comm.ExecuteNonQuery();
                    conn.Close();
                    this.Close();
                    amount = amounttxtbox.Text;
                    total = totaltxtbox.Text;
                    change = changetxtbox.Text;
                    neworder.active = false;
                    newsalesorder.active = false;
                }
            }
            else if (radioButton2.Checked == true)
            {
                conn.Close();
                conn.Open();
                if (Convert.ToDouble(amounttxtbox.Text) > Convert.ToDouble(totaltxtbox.Text))
                {
                    MessageBox.Show("Credit payment cannot be payed greater than total. Did you want regular payment?");
                }
                else
                {
                    submitted = true;
                    double credit = Math.Abs(Convert.ToDouble(changetxtbox.Text));
                    string duedate;
                    
                    string q = "set foreign_key_checks=0;insert into payments(orderid, total, amount, type, remaining, due,status) values('" + orderidtxt.Text + "','" + totaltxtbox.Text + "','" + amounttxtbox.Text + "', 'Downpayment','" + credit + "','" + dateTimePicker1.Value.Date.ToString("yyyyMMdd") +"', 'Pending');"
                             + "insert into paymentline(customerid, paymentid, balance, payment, paychange) values('" + textBox1.Text + "','" + getpaymentid() + "','"+credit+"','"+amounttxtbox.Text+"','0')";
                    MySqlCommand comm = new MySqlCommand(q, conn);
                    comm.ExecuteNonQuery();
                    amount = amounttxtbox.Text;
                    total = totaltxtbox.Text;
                    change = changetxtbox.Text;
                    string q1 = "update customer set balance = balance + " + credit + " where customerid='" + textBox1.Text + "'";
                    MySqlCommand comm2 = new MySqlCommand(q1, conn);
                    comm2.ExecuteNonQuery();
                    conn.Close();
                    this.Close();
                    
                    neworder.active = false;
                    newsalesorder.active = false;
                }
            }
        }

        private void payment_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (submitted)
            {
                cancel = false;
            }
            else
            {
                cancel = true;
            }
            neworder.active = false;
            newsalesorder.active = false;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if(Convert.ToDouble(textBox2.Text) >= 2000)
            {
                MessageBox.Show("Customer cannot create downpayment");
            }
            else
            {
                textBox2.Enabled = true;
                dateTimePicker1.Enabled = true;
                label4.Text = "Balance";
                if (neworder.active)
                {
                    dateTimePicker1.Value = neworder.deliverydate;
                }
                else
                {
                    dateTimePicker1.Value = DateTime.Now.AddDays(30);
                }          
            }
        }
        private void getcustomerbalance()
        {
            conn.Close();
            conn.Open();
            string q = "select balance from customer where customerid = '"+textBox1.Text+"'";
            MySqlCommand com = new MySqlCommand(q, conn);
            textBox2.Text = com.ExecuteScalar().ToString();
            conn.Close();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            textBox2.Enabled = false;
            dateTimePicker1.Enabled = false;
            dateTimePicker1.Value = DateTime.Now;
            label4.Text = "Change";
        }
        private string getpaymentid()
        {
            string q = "select count(*) from payments";
            MySqlCommand com = new MySqlCommand(q, conn);
            return (Convert.ToInt32(com.ExecuteScalar()) + 1).ToString() ;
        }

        private void amounttxtbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back && e.KeyChar != '.')
            {
                e.Handled = true;
            }
        }
    }
}
