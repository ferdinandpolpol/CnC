﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace creams
{
    public partial class records : Form
    {
        MySqlConnection conn;
        public records()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;convert zero datetime=True");

        }

        private void records_Load(object sender, EventArgs e)
        {
            refreshdatabase1();


        }
        private void refreshdatabase1()
        {
            conn.Open();
            //selects all the product from the database
            MySqlCommand comm = new MySqlCommand("select stockinline.date as 'Date', product.productname,product.productunit, stockinline.quantity, stockinline.expirydate as 'Expiry', stockinline.purchaseid as 'PO #', stockinline.deliverynumber as 'DR #' from stockinline, product where stockinline.productid=product.productid order by stockinlineid desc", conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm); //used on select query only
            DataTable dt = new DataTable();
            adp.Fill(dt);

            //Loads the database values to the dataGridView
            dataGridView1.DataSource = dt;
            dataGridView1.Columns["productname"].HeaderText = "Product";
            dataGridView1.Columns["productunit"].HeaderText = "Unit";
            dataGridView1.Columns["quantity"].HeaderText = "Quantity In";

            MySqlCommand comm1 = new MySqlCommand("SELECT s.stockoutid, s.date as 'Date', p.productname as 'Product', p.productunit as 'Unit', sum(s.quantity) as 'Quantity', s.reason as 'Reason' FROM creamsncrumbs.stockout s, product p where p.productid = s.productid group by date, productname, productunit order by stockoutid desc", conn);
            MySqlDataAdapter adp1 = new MySqlDataAdapter(comm1); //used on select query only
            DataTable dt1 = new DataTable();
            adp1.Fill(dt1);

            //Loads the database values to the dataGridView
            dataGridView2.DataSource = dt1;
            dataGridView2.Columns["stockoutid"].Visible = false;

            string q = "select t.date, p.productname, p.productunit, t.salequantity, t.converted_quantity, t.converted_unit from transfer t, product p where p.productid=t.transferid";
            MySqlCommand comm2 = new MySqlCommand(q, conn);
            MySqlDataAdapter adp2 = new MySqlDataAdapter(comm2); //used on select query only
            DataTable dt2 = new DataTable();
            adp2.Fill(dt2);

            //Loads the database values to the dataGridView
            dataGridView3.DataSource = dt2;
            dataGridView3.Columns[0].HeaderText = "Date of Transfer";
            dataGridView3.Columns[1].HeaderText = "Product";
            dataGridView3.Columns[2].HeaderText = "Original Unit";
            dataGridView3.Columns[3].HeaderText = "Quantity Used";
            dataGridView3.Columns[4].HeaderText = "Converted Quantity";
            dataGridView3.Columns[5].HeaderText = "Unit Converted";

            string q1 = "SELECT  date as 'Date', productname as 'Product', SUM(quantity) as 'Quantity', reason as 'Reason' FROM creamsncrumbs.productionstockout GROUP BY date, productname; ";
            MySqlCommand comm3 = new MySqlCommand(q1, conn);
            MySqlDataAdapter adp3 = new MySqlDataAdapter(comm3); //used on select query only
            DataTable dt3 = new DataTable();
            adp3.Fill(dt3);

            //Loads the database values to the dataGridView
            dataGridView4.DataSource = dt3;

            string q2 = "SELECT po.date, concat(st.lastname, ', ', st.firstname), s.suppliername, po.purchaseid as 'PO#', po.total FROM purchaseorder po, supplier s, staff st where st.staffid=po.staffid and po.supplierid=s.supplierid; ";
            MySqlCommand comm4 = new MySqlCommand(q2, conn);
            MySqlDataAdapter adp4 = new MySqlDataAdapter(comm4); //used on select query only
            DataTable dt4 = new DataTable();
            adp4.Fill(dt4);

            //Loads the database values to the dataGridView
            dataGridView5.DataSource = dt4;
            dataGridView5.Columns[0].HeaderText = "Date of Purchase";
            dataGridView5.Columns[1].HeaderText = "Staff";
            dataGridView5.Columns[2].HeaderText = "Supplier";
            dataGridView5.Columns[3].HeaderText = "PO #";
            dataGridView5.Columns[4].HeaderText = "Purchase Total";

            string q3 = "SELECT sr.stockreturnid as 'Stock Return #', concat(st.lastname, ', ', st.firstname) as 'Staff', sr.purchaseid as 'PO #', sr.date as 'Date' FROM stockreturn sr, staff st where sr.staffid=st.staffid;";
            MySqlCommand comm5 = new MySqlCommand(q3, conn);
            MySqlDataAdapter adp5 = new MySqlDataAdapter(comm5); //used on select query only
            DataTable dt5 = new DataTable();
            adp5.Fill(dt5);

            //Loads the database values to the dataGridView
            dataGridView6.DataSource = dt5;

            conn.Close();
        }

        private void fillreason()
        {
            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void dataGridView5_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string q = "SELECT pd.purchaseid, concat(p.productname,', ', p.productunit), pd.quantity, pd.totalquantity FROM purchasedetails pd, product p where pd.productid=p.productid and pd.purchaseid = '"+dataGridView5[3, dataGridView5.CurrentRow.Index].Value.ToString()+"';";
            MySqlCommand comm2 = new MySqlCommand(q, conn);
            MySqlDataAdapter adp2 = new MySqlDataAdapter(comm2); //used on select query only
            DataTable dt2 = new DataTable();
            adp2.Fill(dt2);

            dataGridView7.DataSource = dt2;
            dataGridView7.Columns[0].HeaderText = "PO #";
            dataGridView7.Columns[1].HeaderText = "Product";
            dataGridView7.Columns[2].HeaderText = "Quantity Left";
            dataGridView7.Columns[3].HeaderText = "Total Quantity";
        }

        private void dataGridView6_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string q = "SELECT sr.stockreturnid as 'Stock Return #', concat(p.productname, ' ', p.productunit) as 'Product', sr.quantity as 'Quantity', sr.reason as 'Reason' FROM stockreturnline sr, product p where p.productid=sr.productid and sr.stockreturnid = '" + dataGridView6[0, dataGridView6.CurrentRow.Index].Value.ToString() + "';";
            MySqlCommand comm2 = new MySqlCommand(q, conn);
            MySqlDataAdapter adp2 = new MySqlDataAdapter(comm2); //used on select query only
            DataTable dt2 = new DataTable();
            adp2.Fill(dt2);

            dataGridView8.DataSource = dt2;
            dataGridView8.Columns[0].Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            conn.Open();
            //selects all the product from the database
            MySqlCommand comm = new MySqlCommand("select stockinline.date as 'Date', product.productname,product.productunit, stockinline.quantity, stockinline.expirydate as 'Expiry', stockinline.purchaseid as 'PO #', stockinline.deliverynumber as 'DR #' from stockinline, product where stockinline.productid=product.productid and stockinline.date between '" + dateTimePicker1.Value.Date.ToString("yyyy-MM-dd 00:00") + "' and '" + dateTimePicker2.Value.Date.AddDays(1).AddSeconds(-1).ToString("yyyy-MM-dd HH:mm") + "' order by stockinlineid desc", conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm); //used on select query only
            DataTable dt = new DataTable();
            adp.Fill(dt);

            //Loads the database values to the dataGridView
            dataGridView1.DataSource = dt;
            dataGridView1.Columns["productname"].HeaderText = "Product";
            dataGridView1.Columns["productunit"].HeaderText = "Unit";
            dataGridView1.Columns["quantity"].HeaderText = "Quantity In";

            MySqlCommand comm1 = new MySqlCommand("SELECT s.stockoutid, s.date as 'Date', p.productname as 'Product', p.productunit as 'Unit', sum(s.quantity) as 'Quantity', s.reason as 'Reason' FROM creamsncrumbs.stockout s, product p where p.productid = s.productid and s.date between '" + dateTimePicker1.Value.Date.ToString("yyyy-MM-dd 00:00") + "' and '" + dateTimePicker2.Value.Date.AddDays(1).AddSeconds(-1).ToString("yyyy-MM-dd HH:mm") + "'  group by date, productname, productunit order by stockoutid desc", conn);
            MySqlDataAdapter adp1 = new MySqlDataAdapter(comm1); //used on select query only
            DataTable dt1 = new DataTable();
            adp1.Fill(dt1);

            //Loads the database values to the dataGridView
            dataGridView2.DataSource = dt1;
            dataGridView2.Columns["stockoutid"].Visible = false;

            string q = "select t.date, p.productname, p.productunit, t.salequantity, t.converted_quantity, t.converted_unit from transfer t, product p where p.productid=t.transferid and t.date between '" + dateTimePicker1.Value.Date.ToString("yyyy-MM-dd 00:00") + "' and '" + dateTimePicker2.Value.Date.AddDays(1).AddSeconds(-1).ToString("yyyy-MM-dd HH:mm") + "' ";
            MySqlCommand comm2 = new MySqlCommand(q, conn);
            MySqlDataAdapter adp2 = new MySqlDataAdapter(comm2); //used on select query only
            DataTable dt2 = new DataTable();
            adp2.Fill(dt2);

            //Loads the database values to the dataGridView
            dataGridView3.DataSource = dt2;
            dataGridView3.Columns[0].HeaderText = "Date of Transfer";
            dataGridView3.Columns[1].HeaderText = "Product";
            dataGridView3.Columns[2].HeaderText = "Original Unit";
            dataGridView3.Columns[3].HeaderText = "Quantity Used";
            dataGridView3.Columns[4].HeaderText = "Converted Quantity";
            dataGridView3.Columns[5].HeaderText = "Unit Converted";

            string q1 = "SELECT  date as 'Date', productname as 'Product', SUM(quantity) as 'Quantity', reason as 'Reason' FROM creamsncrumbs.productionstockout where date between '" + dateTimePicker1.Value.Date.ToString("yyyy-MM-dd 00:00") + "' and '" + dateTimePicker2.Value.Date.AddDays(1).AddSeconds(-1).ToString("yyyy-MM-dd HH:mm") + "' GROUP BY date, productname; ";
            MySqlCommand comm3 = new MySqlCommand(q1, conn);
            MySqlDataAdapter adp3 = new MySqlDataAdapter(comm3); //used on select query only
            DataTable dt3 = new DataTable();
            adp3.Fill(dt3);

            //Loads the database values to the dataGridView
            dataGridView4.DataSource = dt3;

            string q2 = "SELECT po.date, concat(st.lastname, ', ', st.firstname), s.suppliername, po.purchaseid as 'PO#', po.total FROM purchaseorder po, supplier s, staff st where st.staffid=po.staffid and po.supplierid=s.supplierid and po.date between '" + dateTimePicker1.Value.Date.ToString("yyyy-MM-dd 00:00") + "' and '" + dateTimePicker2.Value.Date.AddDays(1).AddSeconds(-1).ToString("yyyy-MM-dd HH:mm") + "' ; ";
            MySqlCommand comm4 = new MySqlCommand(q2, conn);
            MySqlDataAdapter adp4 = new MySqlDataAdapter(comm4); //used on select query only
            DataTable dt4 = new DataTable();
            adp4.Fill(dt4);

            //Loads the database values to the dataGridView
            dataGridView5.DataSource = dt4;
            dataGridView5.Columns[0].HeaderText = "Date of Purchase";
            dataGridView5.Columns[1].HeaderText = "Staff";
            dataGridView5.Columns[2].HeaderText = "Supplier";
            dataGridView5.Columns[3].HeaderText = "PO #";
            dataGridView5.Columns[4].HeaderText = "Purchase Total";

            string q3 = "SELECT sr.stockreturnid as 'Stock Return #', concat(st.lastname, ', ', st.firstname) as 'Staff', sr.purchaseid as 'PO #', sr.date as 'Date' FROM stockreturn sr, staff st where sr.staffid=st.staffid and sr.date between '" + dateTimePicker1.Value.Date.ToString("yyyy-MM-dd 00:00") + "' and '" + dateTimePicker2.Value.Date.AddDays(1).AddSeconds(-1).ToString("yyyy-MM-dd HH:mm") + "' ;";
            MySqlCommand comm5 = new MySqlCommand(q3, conn);
            MySqlDataAdapter adp5 = new MySqlDataAdapter(comm5); //used on select query only
            DataTable dt5 = new DataTable();
            adp5.Fill(dt5);

            //Loads the database values to the dataGridView
            dataGridView6.DataSource = dt5;

            conn.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            refreshdatabase1();
        }
    }
}
