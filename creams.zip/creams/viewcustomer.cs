﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace creams
{
    public partial class viewcustomer : Form
    {
        MySqlConnection conn;
        public static string custid;

        public viewcustomer()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;");
        }

        private void viewcustomer_Load(object sender, EventArgs e)
        {
            label4.Visible = false;
            customerid.Visible = false;
            refreshdatabase();
            checkadmin();
            if (!checkadmin())
            {
                addcustomerbtn.Enabled = false;
            }
            else
            {
                addcustomerbtn.Enabled = true;
            }

            validation1.Visible = true;
        
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            custid = customerid.Text = dataGridView1["customerid", dataGridView1.CurrentRow.Index].Value.ToString();
            custname.Text = dataGridView1[1, dataGridView1.CurrentRow.Index].Value.ToString() + ", " + dataGridView1[2, dataGridView1.CurrentRow.Index].Value.ToString();
            validation1.Visible = false;
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void updatebtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(customerid.Text))
            {
                MessageBox.Show("Please choose a customer.");
            }
            else
            {
                customeraccount soa = new customeraccount();
                soa.ShowDialog();
                refreshdatabase();
            }
        }
        //refresh the datagridview
        private void refreshdatabase()
        {
            conn.Open();
            MySqlCommand comm = new MySqlCommand("select customerid, lastname as 'Lastname', firstname as 'Firstname', contact, address, balance as 'Balance' from customer", conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm); //used on select query only
            DataTable dt = new DataTable();
            adp.Fill(dt);

            //Loads the database values to the dataGridView
            dataGridView1.DataSource = dt;
            conn.Close();

            //.Visible removes the unnecessary and valuable information
            dataGridView1.Columns["customerid"].Visible = false;

            //Changes the header text from the database
            dataGridView1.Columns["contact"].HeaderText = "Contact";
            dataGridView1.Columns["address"].HeaderText = "Address";

        }
        //refresh text
        private void refreshtext()
        {
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void addcustomerbtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            newcustomer newcust = new newcustomer();
            newcust.ShowDialog();
            refreshdatabase();
            this.Show();
        }

        private bool checkadmin()
        {
            conn.Open();
            //checks user privilege
            string query = "select stafftype from staff where username like '" + loginform.currentuser + "'";
            MySqlCommand comm = new MySqlCommand(query, conn);

            string privilege = Convert.ToString(comm.ExecuteScalar());
            conn.Close();
            if (privilege == "Admin")
                return true;
            else
                return false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            refreshdatabase();
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            custid = customerid.Text = dataGridView1["customerid", dataGridView1.CurrentRow.Index].Value.ToString();
            customeraccount soa = new customeraccount();
            soa.ShowDialog();
        }
    }
}
