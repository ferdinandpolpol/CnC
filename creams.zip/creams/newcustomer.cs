﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace creams
{
    public partial class newcustomer : Form
    {
        public MySqlConnection conn;
        public newcustomer()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;");
        }

        private void fnamelabel_Click(object sender, EventArgs e)
        {

        }

        private void newcustomer_Load(object sender, EventArgs e)
        {

        }

        private void submitbtn_Click(object sender, EventArgs e)
        {
            conn.Open();
            //Verifies that all fields are populated
            if (string.IsNullOrWhiteSpace(fnametxtbox.Text) ||
                string.IsNullOrWhiteSpace(lnametxtbox.Text) ||
                string.IsNullOrWhiteSpace(contacttxtbox.Text) ||
                string.IsNullOrWhiteSpace(addresstxtbox.Text) )
            {
                //Shows error message
                MessageBox.Show("Error: One of the fields are empty");
            }
            // If user does not exist, it will proceed to adding a user
            else
            {
                //If all conditions satisfied, this will add the user
                // String for inserting the values into the staff table
                string q = "insert into customer(firstname, lastname, contact, address) values('" +
                fnametxtbox.Text + "','" + lnametxtbox.Text + "','" + contacttxtbox.Text + "','" + addresstxtbox.Text + "')";
                MySqlCommand comm = new MySqlCommand(q, conn);
                comm.ExecuteNonQuery();

                MessageBox.Show("Successfully added customer " + fnametxtbox.Text + ", " + lnametxtbox.Text + "!");
                this.Close();
            }
            conn.Close();
        }

        private void cancelbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void contacttxtbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }
    }
}
