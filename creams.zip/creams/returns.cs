﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace creams
{
    public partial class returns : Form
    {
        MySqlConnection conn;
        public returns()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            conn.Open();
            string query = "set foreign_key_checks=0;insert into creamsncrumbs.`return`(returnid,orderid,returntotal) values('" + getreturnid() + "','0','0'); set foreign_key_checks=1;";
            MySqlCommand comm = new MySqlCommand(query, conn);
            comm.ExecuteNonQuery();
            conn.Close();

            newreturns returns = new creams.newreturns();
            returns.ShowDialog();
        }
        private string getreturnid()
        {
            MySqlCommand comm = new MySqlCommand("SELECT count(*) FROM creamsncrumbs.`return`;", conn);
            Int32 norows = Convert.ToInt32(comm.ExecuteScalar());
            norows += 1;
            return norows.ToString();
        }

        private void returns_Load(object sender, EventArgs e)
        {
            refreshdatabase();
        }
        private void refreshdatabase()
        {
            string q = "select r.date,rl.returnlineid, rl.returnid, ol.productname, rl.productstatus, rl.returntype, rl.quantityreturned, rl.subtotal, rl.action from returnline rl, orderline ol, creamsncrumbs.`return` r where rl.orderlineid=ol.orderlineid and r.returnid=rl.returnid order by returnlineid desc";
            MySqlCommand comm1 = new MySqlCommand(q, conn);
            MySqlDataAdapter adp1 = new MySqlDataAdapter(comm1);
            DataTable dt1 = new DataTable();
            adp1.Fill(dt1);
            dataGridView1.DataSource = dt1;

            dataGridView1.Columns[0].HeaderText = "Date";
            dataGridView1.Columns[1].Visible = false;
            dataGridView1.Columns[2].HeaderText = "Return #";
            dataGridView1.Columns[3].HeaderText = "Product";
            dataGridView1.Columns[4].HeaderText = "Status"; ;
            dataGridView1.Columns[5].HeaderText = "Type"; ;
            dataGridView1.Columns[6].HeaderText = "Quantity Returned"; ;
            dataGridView1.Columns[7].HeaderText = "Subtotal"; ;
            dataGridView1.Columns[8].HeaderText = "Action";

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string q = "select r.date,rl.returnlineid, rl.returnid, ol.productname, rl.productstatus, rl.returntype, rl.quantityreturned, rl.subtotal, rl.action from returnline rl, orderline ol, creamsncrumbs.`return` r where rl.orderlineid=ol.orderlineid and r.returnid=rl.returnid " +
                "and r.date between '"+dateTimePicker1.Value.Date.ToString("yyyy-MM-dd 00:00")+"' and '"+dateTimePicker2.Value.Date.AddDays(1).AddSeconds(-1).ToString("yyyy-MM-dd HH:mm")+"' order by returnlineid desc";
            MySqlCommand comm1 = new MySqlCommand(q, conn);
            MySqlDataAdapter adp1 = new MySqlDataAdapter(comm1);
            DataTable dt1 = new DataTable();
            adp1.Fill(dt1);
            dataGridView1.DataSource = dt1;

            dataGridView1.Columns[0].HeaderText = "Date";
            dataGridView1.Columns[1].Visible = false;
            dataGridView1.Columns[2].HeaderText = "Return #";
            dataGridView1.Columns[3].HeaderText = "Product";
            dataGridView1.Columns[4].HeaderText = "Status"; ;
            dataGridView1.Columns[5].HeaderText = "Type"; ;
            dataGridView1.Columns[6].HeaderText = "Quantity Returned"; ;
            dataGridView1.Columns[7].HeaderText = "Subtotal"; ;
            dataGridView1.Columns[8].HeaderText = "Action";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            refreshdatabase();
        }
    }
}
