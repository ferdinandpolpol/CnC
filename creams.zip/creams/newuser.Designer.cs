﻿namespace creams
{
    partial class newuser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.fnamelabel = new System.Windows.Forms.Label();
            this.fnametxtbox = new System.Windows.Forms.TextBox();
            this.lnamelabel = new System.Windows.Forms.Label();
            this.lnametxtbox = new System.Windows.Forms.TextBox();
            this.userlabel = new System.Windows.Forms.Label();
            this.usertxtbox = new System.Windows.Forms.TextBox();
            this.passlabel = new System.Windows.Forms.Label();
            this.passtxtbox = new System.Windows.Forms.TextBox();
            this.adminradio = new System.Windows.Forms.RadioButton();
            this.staffradio = new System.Windows.Forms.RadioButton();
            this.cancelbtn = new System.Windows.Forms.Button();
            this.submitbtn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // fnamelabel
            // 
            this.fnamelabel.AutoSize = true;
            this.fnamelabel.Location = new System.Drawing.Point(28, 75);
            this.fnamelabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.fnamelabel.Name = "fnamelabel";
            this.fnamelabel.Size = new System.Drawing.Size(89, 21);
            this.fnamelabel.TabIndex = 0;
            this.fnamelabel.Text = "Firstname:";
            // 
            // fnametxtbox
            // 
            this.fnametxtbox.Location = new System.Drawing.Point(32, 98);
            this.fnametxtbox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.fnametxtbox.Name = "fnametxtbox";
            this.fnametxtbox.Size = new System.Drawing.Size(267, 27);
            this.fnametxtbox.TabIndex = 1;
            // 
            // lnamelabel
            // 
            this.lnamelabel.AutoSize = true;
            this.lnamelabel.Location = new System.Drawing.Point(28, 133);
            this.lnamelabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lnamelabel.Name = "lnamelabel";
            this.lnamelabel.Size = new System.Drawing.Size(91, 21);
            this.lnamelabel.TabIndex = 2;
            this.lnamelabel.Text = "Lastname:";
            // 
            // lnametxtbox
            // 
            this.lnametxtbox.Location = new System.Drawing.Point(32, 156);
            this.lnametxtbox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lnametxtbox.Name = "lnametxtbox";
            this.lnametxtbox.Size = new System.Drawing.Size(267, 27);
            this.lnametxtbox.TabIndex = 3;
            // 
            // userlabel
            // 
            this.userlabel.AutoSize = true;
            this.userlabel.Location = new System.Drawing.Point(28, 192);
            this.userlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.userlabel.Name = "userlabel";
            this.userlabel.Size = new System.Drawing.Size(92, 21);
            this.userlabel.TabIndex = 4;
            this.userlabel.Text = "Username:";
            // 
            // usertxtbox
            // 
            this.usertxtbox.Location = new System.Drawing.Point(32, 215);
            this.usertxtbox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.usertxtbox.Name = "usertxtbox";
            this.usertxtbox.Size = new System.Drawing.Size(267, 27);
            this.usertxtbox.TabIndex = 5;
            // 
            // passlabel
            // 
            this.passlabel.AutoSize = true;
            this.passlabel.Location = new System.Drawing.Point(28, 256);
            this.passlabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.passlabel.Name = "passlabel";
            this.passlabel.Size = new System.Drawing.Size(86, 21);
            this.passlabel.TabIndex = 6;
            this.passlabel.Text = "Password:";
            // 
            // passtxtbox
            // 
            this.passtxtbox.Location = new System.Drawing.Point(32, 279);
            this.passtxtbox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.passtxtbox.Name = "passtxtbox";
            this.passtxtbox.PasswordChar = '*';
            this.passtxtbox.Size = new System.Drawing.Size(267, 27);
            this.passtxtbox.TabIndex = 7;
            // 
            // adminradio
            // 
            this.adminradio.AutoSize = true;
            this.adminradio.Location = new System.Drawing.Point(80, 345);
            this.adminradio.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.adminradio.Name = "adminradio";
            this.adminradio.Size = new System.Drawing.Size(80, 25);
            this.adminradio.TabIndex = 0;
            this.adminradio.TabStop = true;
            this.adminradio.Text = "Admin";
            this.adminradio.UseVisualStyleBackColor = true;
            this.adminradio.CheckedChanged += new System.EventHandler(this.adminradio_CheckedChanged);
            // 
            // staffradio
            // 
            this.staffradio.AutoSize = true;
            this.staffradio.Location = new System.Drawing.Point(175, 345);
            this.staffradio.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.staffradio.Name = "staffradio";
            this.staffradio.Size = new System.Drawing.Size(64, 25);
            this.staffradio.TabIndex = 1;
            this.staffradio.TabStop = true;
            this.staffradio.Text = "Staff";
            this.staffradio.UseVisualStyleBackColor = true;
            // 
            // cancelbtn
            // 
            this.cancelbtn.BackColor = System.Drawing.Color.Brown;
            this.cancelbtn.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.cancelbtn.FlatAppearance.BorderSize = 0;
            this.cancelbtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.cancelbtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.cancelbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cancelbtn.ForeColor = System.Drawing.Color.White;
            this.cancelbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cancelbtn.Location = new System.Drawing.Point(165, 392);
            this.cancelbtn.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cancelbtn.Name = "cancelbtn";
            this.cancelbtn.Size = new System.Drawing.Size(144, 63);
            this.cancelbtn.TabIndex = 10;
            this.cancelbtn.Text = "Cancel";
            this.cancelbtn.UseVisualStyleBackColor = false;
            this.cancelbtn.Click += new System.EventHandler(this.cancelbtn_Click);
            // 
            // submitbtn
            // 
            this.submitbtn.BackColor = System.Drawing.Color.ForestGreen;
            this.submitbtn.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.submitbtn.FlatAppearance.BorderSize = 0;
            this.submitbtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.submitbtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.submitbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.submitbtn.ForeColor = System.Drawing.Color.White;
            this.submitbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.submitbtn.Location = new System.Drawing.Point(16, 392);
            this.submitbtn.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.submitbtn.Name = "submitbtn";
            this.submitbtn.Size = new System.Drawing.Size(144, 63);
            this.submitbtn.TabIndex = 11;
            this.submitbtn.Text = "Submit";
            this.submitbtn.UseVisualStyleBackColor = false;
            this.submitbtn.Click += new System.EventHandler(this.submitbtn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(28, 322);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(131, 21);
            this.label2.TabIndex = 12;
            this.label2.Text = "Employee Type:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Maroon;
            this.label1.Location = new System.Drawing.Point(108, 28);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 25);
            this.label1.TabIndex = 13;
            this.label1.Text = "Add User";
            // 
            // newuser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MistyRose;
            this.ClientSize = new System.Drawing.Size(328, 468);
            this.ControlBox = false;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.staffradio);
            this.Controls.Add(this.submitbtn);
            this.Controls.Add(this.adminradio);
            this.Controls.Add(this.cancelbtn);
            this.Controls.Add(this.passtxtbox);
            this.Controls.Add(this.passlabel);
            this.Controls.Add(this.usertxtbox);
            this.Controls.Add(this.userlabel);
            this.Controls.Add(this.lnametxtbox);
            this.Controls.Add(this.lnamelabel);
            this.Controls.Add(this.fnametxtbox);
            this.Controls.Add(this.fnamelabel);
            this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(7, 4, 7, 4);
            this.Name = "newuser";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add New User";
            this.Load += new System.EventHandler(this.newuser_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label fnamelabel;
        private System.Windows.Forms.TextBox fnametxtbox;
        private System.Windows.Forms.Label lnamelabel;
        private System.Windows.Forms.TextBox lnametxtbox;
        private System.Windows.Forms.Label userlabel;
        private System.Windows.Forms.TextBox usertxtbox;
        private System.Windows.Forms.Label passlabel;
        private System.Windows.Forms.TextBox passtxtbox;
        private System.Windows.Forms.RadioButton staffradio;
        private System.Windows.Forms.RadioButton adminradio;
        private System.Windows.Forms.Button cancelbtn;
        private System.Windows.Forms.Button submitbtn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}