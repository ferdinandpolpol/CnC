﻿namespace creams
{
    partial class newcustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.submitbtn = new System.Windows.Forms.Button();
            this.cancelbtn = new System.Windows.Forms.Button();
            this.lnametxtbox = new System.Windows.Forms.TextBox();
            this.lnamelabel = new System.Windows.Forms.Label();
            this.fnametxtbox = new System.Windows.Forms.TextBox();
            this.fnamelabel = new System.Windows.Forms.Label();
            this.contacttxtbox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.addresstxtbox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Maroon;
            this.label2.Location = new System.Drawing.Point(187, -115);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(174, 31);
            this.label2.TabIndex = 38;
            this.label2.Text = "Add Product";
            // 
            // submitbtn
            // 
            this.submitbtn.BackColor = System.Drawing.Color.ForestGreen;
            this.submitbtn.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.submitbtn.FlatAppearance.BorderSize = 0;
            this.submitbtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.submitbtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.submitbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.submitbtn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.submitbtn.ForeColor = System.Drawing.Color.White;
            this.submitbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.submitbtn.Location = new System.Drawing.Point(24, 288);
            this.submitbtn.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.submitbtn.Name = "submitbtn";
            this.submitbtn.Size = new System.Drawing.Size(131, 46);
            this.submitbtn.TabIndex = 4;
            this.submitbtn.Text = "Submit";
            this.submitbtn.UseVisualStyleBackColor = false;
            this.submitbtn.Click += new System.EventHandler(this.submitbtn_Click);
            // 
            // cancelbtn
            // 
            this.cancelbtn.BackColor = System.Drawing.Color.Brown;
            this.cancelbtn.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.cancelbtn.FlatAppearance.BorderSize = 0;
            this.cancelbtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.cancelbtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.cancelbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cancelbtn.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelbtn.ForeColor = System.Drawing.Color.White;
            this.cancelbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.cancelbtn.Location = new System.Drawing.Point(164, 288);
            this.cancelbtn.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.cancelbtn.Name = "cancelbtn";
            this.cancelbtn.Size = new System.Drawing.Size(131, 46);
            this.cancelbtn.TabIndex = 5;
            this.cancelbtn.Text = "Cancel";
            this.cancelbtn.UseVisualStyleBackColor = false;
            this.cancelbtn.Click += new System.EventHandler(this.cancelbtn_Click);
            // 
            // lnametxtbox
            // 
            this.lnametxtbox.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnametxtbox.Location = new System.Drawing.Point(18, 131);
            this.lnametxtbox.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.lnametxtbox.Name = "lnametxtbox";
            this.lnametxtbox.Size = new System.Drawing.Size(285, 27);
            this.lnametxtbox.TabIndex = 1;
            // 
            // lnamelabel
            // 
            this.lnamelabel.AutoSize = true;
            this.lnamelabel.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnamelabel.Location = new System.Drawing.Point(13, 109);
            this.lnamelabel.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lnamelabel.Name = "lnamelabel";
            this.lnamelabel.Size = new System.Drawing.Size(91, 21);
            this.lnamelabel.TabIndex = 29;
            this.lnamelabel.Text = "Lastname:";
            // 
            // fnametxtbox
            // 
            this.fnametxtbox.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fnametxtbox.Location = new System.Drawing.Point(18, 82);
            this.fnametxtbox.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.fnametxtbox.Name = "fnametxtbox";
            this.fnametxtbox.Size = new System.Drawing.Size(285, 27);
            this.fnametxtbox.TabIndex = 0;
            // 
            // fnamelabel
            // 
            this.fnamelabel.AutoSize = true;
            this.fnamelabel.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fnamelabel.Location = new System.Drawing.Point(15, 59);
            this.fnamelabel.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.fnamelabel.Name = "fnamelabel";
            this.fnamelabel.Size = new System.Drawing.Size(89, 21);
            this.fnamelabel.TabIndex = 27;
            this.fnamelabel.Text = "Firstname:";
            this.fnamelabel.Click += new System.EventHandler(this.fnamelabel_Click);
            // 
            // contacttxtbox
            // 
            this.contacttxtbox.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contacttxtbox.Location = new System.Drawing.Point(18, 182);
            this.contacttxtbox.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.contacttxtbox.MaxLength = 11;
            this.contacttxtbox.Name = "contacttxtbox";
            this.contacttxtbox.Size = new System.Drawing.Size(285, 27);
            this.contacttxtbox.TabIndex = 2;
            this.contacttxtbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.contacttxtbox_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 159);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(149, 21);
            this.label1.TabIndex = 39;
            this.label1.Text = "Contact Number:";
            // 
            // addresstxtbox
            // 
            this.addresstxtbox.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addresstxtbox.Location = new System.Drawing.Point(18, 232);
            this.addresstxtbox.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.addresstxtbox.Name = "addresstxtbox";
            this.addresstxtbox.Size = new System.Drawing.Size(285, 27);
            this.addresstxtbox.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(13, 209);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 21);
            this.label3.TabIndex = 41;
            this.label3.Text = "Address:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Maroon;
            this.label4.Location = new System.Drawing.Point(74, 9);
            this.label4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(170, 25);
            this.label4.TabIndex = 43;
            this.label4.Text = "Add Customer";
            // 
            // newcustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MistyRose;
            this.ClientSize = new System.Drawing.Size(318, 342);
            this.ControlBox = false;
            this.Controls.Add(this.label4);
            this.Controls.Add(this.addresstxtbox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.contacttxtbox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.submitbtn);
            this.Controls.Add(this.cancelbtn);
            this.Controls.Add(this.lnametxtbox);
            this.Controls.Add(this.lnamelabel);
            this.Controls.Add(this.fnametxtbox);
            this.Controls.Add(this.fnamelabel);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.Name = "newcustomer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add Customer";
            this.Load += new System.EventHandler(this.newcustomer_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button submitbtn;
        private System.Windows.Forms.Button cancelbtn;
        private System.Windows.Forms.TextBox lnametxtbox;
        private System.Windows.Forms.Label lnamelabel;
        private System.Windows.Forms.TextBox fnametxtbox;
        private System.Windows.Forms.Label fnamelabel;
        private System.Windows.Forms.TextBox contacttxtbox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox addresstxtbox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}