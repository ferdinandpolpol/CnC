﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace creams
{
    public partial class stockout : Form
    {
        MySqlConnection conn;
        public stockout()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;");
        }

        private void stockout_Load(object sender, EventArgs e)
        {
            groupBox1.Enabled = false;
            //fillreason();
            conn.Open();
            refreshdatabase();
        }
        private void refreshdatabase()
        {
            string query = "select p.productid,p.productname, p.productunit,si.* from saleinventory si, product p where si.productid=p.productid and quantity > 0 order by p.productname ";
            MySqlCommand comm = new MySqlCommand(query, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView1.DataSource = dt;
            dataGridView1.Columns["saleid"].Visible = false;
            dataGridView1.Columns["productid"].Visible = false;
            dataGridView1.Columns["purchaseid"].Visible = false;
            dataGridView1.Columns["stockinlineid"].Visible = false;
            dataGridView1.Columns["productid1"].Visible = false;
            dataGridView1.Columns["date"].Visible = false;
            dataGridView1.Columns["productname"].HeaderText = "Name of Product";
            dataGridView1.Columns["productunit"].HeaderText = "Unit";

            showexpired();
        }

        private void stockout_FormClosing(object sender, FormClosingEventArgs e)
        {
            conn.Close();
        }
        bool grid1clicked = false;
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            groupBox1.Enabled = true;
            grid1clicked = true;
            DateTime expirydate = Convert.ToDateTime(dataGridView1["expiry", dataGridView1.CurrentRow.Index].Value);
            string remaining = (expirydate - DateTime.Now).Days.ToString();
            comboBox2.Items.Clear();
            if (Convert.ToInt32(remaining) < 14)
            {
                comboBox2.Items.Add("Expired");
                comboBox2.Items.Add("Damaged");
            }
            else
            {

                comboBox2.Items.Add("Damaged");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            conn.Close();
            conn.Open();

            foreach (DataGridViewRow row in dataGridView2.Rows)
            {
                string saleinv = "select * from saleinventory where productid='" + row.Cells["productid"].Value.ToString() + "'";
                MySqlCommand comm1 = new MySqlCommand(saleinv, conn);
                MySqlDataAdapter adp = new MySqlDataAdapter(comm1); //used on select query only
                DataTable dt = new DataTable();
                adp.Fill(dt);

                dataGridView1.DataSource = dt;
                string pid = row.Cells["productid"].Value.ToString();
                string pname = row.Cells["productname"].Value.ToString();
                string punit = row.Cells["unit"].Value.ToString();
                string quantity = row.Cells["quantity"].Value.ToString();
                string reason = row.Cells["reason"].Value.ToString();
                foreach (DataGridViewRow row2 in dataGridView1.Rows)
                {
                    if (Convert.ToInt32(row2.Cells["quantity"].Value) > 0)
                    {
                        string saleid = row2.Cells["saleid"].Value.ToString();
                        string prodid = row2.Cells["productid"].Value.ToString();
                        if (Convert.ToInt32(row2.Cells["quantity"].Value) >= Convert.ToInt32(row.Cells["quantity"].Value))
                        {
                            string q1 = "update saleinventory set saleinventory.quantity = saleinventory.quantity - '" + quantity + "' where saleinventory.saleid = '" + saleid + "';" +
                                        "insert into stockout(productid, quantity, reason) values('" + prodid + "','" + quantity + "','"+reason+"')";
                            MySqlCommand com1 = new MySqlCommand(q1, conn);
                            com1.ExecuteNonQuery();
                            break;
                        }
                        else if (Convert.ToInt32(row2.Cells["quantity"].Value) < Convert.ToInt32(row.Cells["quantity"].Value))
                        {
                            string salequantity = row2.Cells["quantity"].Value.ToString();
                            string olquantity = row.Cells["quantity"].Value.ToString();
                            string quantityleft = (Convert.ToInt32(olquantity) - Convert.ToInt32(salequantity)).ToString();

                            string q1 = "update saleinventory set saleinventory.quantity = 0 where saleinventory.saleid = '" + saleid + "';" +
                                        "insert into stockout(productid, quantity, reason) values('" + prodid + "','" + salequantity + "','" + reason + "');";
                            MySqlCommand com1 = new MySqlCommand(q1, conn);
                            com1.ExecuteNonQuery();
                            row.Cells["quantity"].Value = Convert.ToInt32(quantity) - Convert.ToInt32(quantityleft);
                            dataGridView2.Rows.Add(pid, pname, punit, quantityleft, reason);
                            break;
                        }
                    }
                    else
                    {
                        continue;
                    }
                }
            }

            conn.Close();
            MessageBox.Show("Successful");
            this.Close();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void fillreason()
        {
            comboBox2.Items.Add("Expired");
            comboBox2.Items.Add("Damaged");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (!grid1clicked)
            {
                MessageBox.Show("Please select product");
                textBox1.Clear();
            }
            else
            {
                bool isexist = false;

                string productid = dataGridView1["productid", dataGridView1.CurrentRow.Index].Value.ToString();
                string productname = dataGridView1["productname", dataGridView1.CurrentRow.Index].Value.ToString();
                string productunit = dataGridView1["productunit", dataGridView1.CurrentRow.Index].Value.ToString();
                string qty = textBox1.Text;
                string reason = comboBox2.Text;

                string q = "select sum(quantity) from saleinventory where productid = '" + productid + "'";
                MySqlCommand comm = new MySqlCommand(q, conn);
                int saleqty = Convert.ToInt32(comm.ExecuteScalar());
                foreach (DataGridViewRow row in dataGridView2.Rows)
                {
                    if (row.Cells["productid"].Value.ToString() == productid)
                    {
                        isexist = true;
                    }
                }

                if (string.IsNullOrWhiteSpace(textBox1.Text) ||
                        string.IsNullOrWhiteSpace(comboBox2.Text))
                {
                    MessageBox.Show("Empty field/s");
                }
                else if (isexist)
                {
                    MessageBox.Show("Already added");
                }
                else if (Convert.ToInt32(qty) > saleqty)
                {
                    MessageBox.Show("Invalid Quantity");
                }
                else
                {
                    dataGridView2.Rows.Add(productid, productname, productunit, qty, reason);
                }
            }
            
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (!grid1click)
            {
                MessageBox.Show("Please select");
            }
            else
            {
                DialogResult dr = MessageBox.Show(@"Do you want to remove all?",
                                               Application.ProductName,
                                               MessageBoxButtons.YesNo);
                if (dr == DialogResult.Yes)
                {
                    this.dataGridView1.Rows.Clear();
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (!grid1click)
            {
                MessageBox.Show("Please select");
            }
            else
            {
                DialogResult dr = MessageBox.Show(@"Remove?",
                                               Application.ProductName,
                                               MessageBoxButtons.YesNo);
                if (dr == DialogResult.Yes)
                {
                    this.dataGridView1.Rows.RemoveAt(dataGridView1.CurrentRow.Index);
                }
            }
        }
        bool grid1click = false;
        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            grid1click = true;
        }
        private void showexpired()
        {
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                DateTime expirydate = Convert.ToDateTime(row.Cells["expiry"].Value);
                string remaining = (expirydate - DateTime.Now).Days.ToString();
                if (Convert.ToInt32(remaining) < 14)
                {
                    row.Cells["expiry"].Style.BackColor = Color.LightCoral;
                }
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
