﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace creams
{
    public partial class balancepayment : Form
    {
        MySqlConnection conn;
        public balancepayment()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;");
        }

        private void creditpayment_Load(object sender, EventArgs e)
        {
            fillcustomerdetails();
            
            //textBox1.Text = customeraccount.customerid;
            amounttxtbox.Text = 0.ToString();
            if (customeraccount.orderbalance)
            {
                orderidtxt.Text = customeraccount.orderid;
                getorderdetails();
                label7.Visible = false;
                balancetext.Visible = false;
            }
            else if (customeraccount.allbalance)
            {
                orderidtxt.Visible = false;
                label1.Visible = false;
                label2.Visible = false;
                balance.Visible = false;
            }
            conn.Open();
        }
        private void fillcustomerdetails()
        {
            conn.Open();
            string q = "select * from customer where customerid = '" + customeraccount.customerid + "'";
            MySqlCommand cmdDataBase = new MySqlCommand(q, conn);
            MySqlDataReader myReader;

            myReader = cmdDataBase.ExecuteReader();

            while (myReader.Read())
            {
                string balance = myReader.GetString("balance");
                balancetext.Text = balance;
            }
            conn.Close();
        }

        private void amounttxtbox_TextChanged(object sender, EventArgs e)
        {
            try
            {
                changetxtbox.Text = (Convert.ToDouble(amounttxtbox.Text) - Convert.ToDouble(balance.Text)).ToString();
            }
            catch(Exception er)
            {

            }
        }

        private void creditpayment_FormClosing(object sender, FormClosingEventArgs e)
        {
             
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (customeraccount.allbalance)
            {
                string ins = "select p.* from payments p, orders o where p.orderid=o.orderid and o.customerid ='"+ customeraccount.customerid + "' and remaining > 0 group by orderid";
                MySqlCommand comm1 = new MySqlCommand(ins, conn);
                MySqlDataAdapter adp = new MySqlDataAdapter(comm1);
                DataTable dt = new DataTable();
                adp.Fill(dt);

                dataGridView1.DataSource = dt;
                if (Convert.ToDouble(amounttxtbox.Text) <= Convert.ToDouble(balancetext.Text))
                {
                    string q = "update customer set balance = balance - '" + amounttxtbox.Text + "' where customerid='" + customeraccount.customerid + "'";
                    MySqlCommand com = new MySqlCommand(q, conn);
                    com.ExecuteNonQuery();

                }
                else
                {
                    string q = "update customer set balance = 0 where customerid='" + customeraccount.customerid + "'";
                    MySqlCommand com = new MySqlCommand(q, conn);
                    com.ExecuteNonQuery();
                }
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    string paymentid = row.Cells["paymentid"].Value.ToString();
                    string remaining = row.Cells["remaining"].Value.ToString();
                    string orderid = row.Cells["orderid"].Value.ToString();
                    if(Convert.ToDouble(remaining) < Convert.ToDouble(amounttxtbox.Text))
                    {
                        double change = Convert.ToDouble(amounttxtbox.Text) - Convert.ToDouble(remaining);
                        string q = "insert into paymentline(customerid, paymentid, balance, payment, paychange) values('" + customeraccount.customerid + "','" + paymentid + "','" + remaining + "', '" + amounttxtbox.Text + "', '"+change+"');"
                            + " update payments set amount = total, remaining = 0, status='Paid' where paymentid = '" + paymentid + "'";
                        MySqlCommand com = new MySqlCommand(q, conn);
                        com.ExecuteNonQuery();
                        amounttxtbox.Text = (Convert.ToDouble(amounttxtbox.Text)-Convert.ToDouble(remaining)).ToString();
                        continue;
                    }
                    else if(Convert.ToDouble(remaining) >= Convert.ToDouble(amounttxtbox.Text))
                    {
                        string q = "insert into paymentline(customerid, paymentid, balance, payment, paychange) values('" + customeraccount.customerid + "','" + paymentid + "','" + remaining + "', '" + amounttxtbox.Text + "', '0');" +
                            "update payments set amount = amount + '"+amounttxtbox.Text+"',remaining = remaining - '" +amounttxtbox.Text+"' where paymentid = '" + paymentid + "'";
                        MySqlCommand com = new MySqlCommand(q, conn);
                        com.ExecuteNonQuery();
                        amounttxtbox.Text = 0.ToString();
                        continue;
                    }
                }
                this.Close();
            }
            else if (customeraccount.orderbalance)
            {
                if (Convert.ToDouble(amounttxtbox.Text) <= Convert.ToDouble(balance.Text))
                {
                    string q = "update payments set amount = amount + '"+amounttxtbox.Text+"',remaining = remaining - '" + amounttxtbox.Text + "' where orderid = '" + orderidtxt.Text + "'; "+
                        " update customer set balance = balance - '" + amounttxtbox.Text + "' where customerid='" + customeraccount.customerid + "'";
                    MySqlCommand com = new MySqlCommand(q, conn);
                    com.ExecuteNonQuery();

                    string ins = "insert into paymentline(customerid, paymentid, balance, payment, paychange) values('" + customeraccount.customerid + "','" + getpaymentid() + "','" + balance.Text + "', '" + amounttxtbox.Text + "', '0')";
                    MySqlCommand comm1 = new MySqlCommand(ins, conn);
                    comm1.ExecuteNonQuery();
                }
                else
                {
                    string q = "update customer set balance = balance - '"+balance.Text+"' where customerid='" + customeraccount.customerid + "';" +
                        "update payments set amount = total, remaining = 0, status = 'Paid' where orderid = '" + orderidtxt.Text + "'";
                    MySqlCommand com = new MySqlCommand(q, conn);
                    com.ExecuteNonQuery();

                    string ins = "insert into paymentline(customerid, paymentid, balance, payment, paychange) values('" + customeraccount.customerid + "','" + getpaymentid() + "','" + balance.Text + "', '" + amounttxtbox.Text + "', '"+changetxtbox.Text+"')";
                    MySqlCommand comm1 = new MySqlCommand(ins, conn);
                    comm1.ExecuteNonQuery();
                }
                this.Close();
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private int getcreditpaymentid()
        {
            string q = "select count(*) from paymentline";
            MySqlCommand comm = new MySqlCommand(q, conn);
            return Convert.ToInt32(comm.ExecuteScalar()) + 1;
        }
        private void getorderdetails()
        {
            string q = "select * from payments where orderid = '" + orderidtxt.Text + "'";
            conn.Open();
            MySqlCommand cmdDataBase = new MySqlCommand(q, conn);
            MySqlDataReader myReader;

            myReader = cmdDataBase.ExecuteReader();

            while (myReader.Read())
            {
                DateTime date = myReader.GetDateTime("due");
                dateTimePicker1.Value = date;
                balance.Text = myReader.GetString("remaining");
            }
            conn.Close();
        }
        private string getpaymentid()
        {
            string q = "select paymentid from payments where orderid = '"+orderidtxt.Text+"'";
            MySqlCommand comm = new MySqlCommand(q, conn);
            return comm.ExecuteScalar().ToString();
        }

        private void balancepayment_FormClosing(object sender, FormClosingEventArgs e)
        {
            conn.Close();
        }

        private void amounttxtbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back && e.KeyChar != '.')
            {
                e.Handled = true;
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
