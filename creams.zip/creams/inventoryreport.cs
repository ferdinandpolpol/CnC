﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace creams
{
    public partial class inventoryreport : Form
    {
        public inventoryreport()
        {
            InitializeComponent();
        }

        public static bool generate1 = false;
        public static bool generate2 = false;
        public static bool generate3 = false;
        public static DateTime fromdate;
        public static DateTime todate;
        private void inventoryreport_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            fromdate = dateTimePicker1.Value.Date;
            todate = dateTimePicker2.Value.Date;
            inventoryreport2.prodbutton1 = false;
            inventoryreport2.prodbutton2 = false;
            inventoryreport2.prodbutton3 = false;
            generate1 = true;
            generate2 = false;
            generate3 = false;
            showinvreport sr = new showinvreport();
            sr.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            inventoryreport2.prodbutton1 = false;
            inventoryreport2.prodbutton2 = false;
            inventoryreport2.prodbutton3 = false;
            generate1 = false;
            generate2 = true;
            generate3 = false;
            showinvreport sr = new showinvreport();
            sr.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            inventoryreport2.prodbutton1 = false;
            inventoryreport2.prodbutton2 = false;
            inventoryreport2.prodbutton3 = false;
            generate1 = false;
            generate2 = false;
            generate3 = true;
            showinvreport sr = new showinvreport();
            sr.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
