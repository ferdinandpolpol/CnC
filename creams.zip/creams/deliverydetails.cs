﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace creams
{
    public partial class deliverydetails : Form
    {
        MySqlConnection conn;
        public deliverydetails()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;");
        }

        private void deliverydetails_Load(object sender, EventArgs e)
        {
            label2.Text = productionlist.deliveryid;
            comboBox1.Items.Add("Cancel");
            comboBox1.Items.Add("Resume");
            loaddelivery();
            
            
            conn.Open();
            
        }
        private void loaddelivery()
        {
            conn.Open();
            string q = "SELECT CONCAT(c.lastname, ', ', c.firstname) as 'Customer',GROUP_CONCAT(DISTINCT CONCAT(ol.quantity, ' ', ol.productname)) AS 'Orders',d.* FROM delivery d,customer c,orders o,orderline ol WHERE d.customerid = c.customerid and d.orderid = o.orderid and o.orderid = ol.orderid and d.deliveryid='"+label2.Text+"' group by orderid";
            MySqlCommand cmdDataBase = new MySqlCommand(q, conn);
            MySqlDataReader myReader;

            myReader = cmdDataBase.ExecuteReader();

            while (myReader.Read())
            {
                string address = myReader.GetString("deliveryaddress");
                DateTime date = myReader.GetDateTime("deliverydate");
                string status = myReader.GetString("productionstatus");
                custname.Text = productionlist.customer;
                addresstxt.Text = address;
                dateTimePicker1.MinDate = date;
                dateTimePicker1.Value = date;
                comboBox1.Text = status;
            }
            conn.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrWhiteSpace(addresstxt.Text) ||
                string.IsNullOrWhiteSpace(dateTimePicker1.Text) ||
                string.IsNullOrWhiteSpace(comboBox1.Text))
            {
                MessageBox.Show("Empty field/s");
            }
            else
            {
                string status = "In Progress";
                if(comboBox1.Text == "Cancel")
                {
                    status = "Cancelled";
                }
                string q = "update delivery set deliveryaddress = '"+addresstxt.Text+"', deliverydate='"+ dateTimePicker1.Value.Date.ToString("yyyyMMdd") + "', productionstatus='"+status+"' where deliveryid='"+label2.Text+"'";
                MySqlCommand comm = new MySqlCommand(q, conn);
                comm.ExecuteNonQuery();
                this.Close();
            }
        }

        private void deliverydetails_FormClosing(object sender, FormClosingEventArgs e)
        {
            conn.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
