﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace creams
{
    public partial class purchaselist : Form
    {
        public MySqlConnection conn;
        public purchaselist()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string q = "set foreign_key_checks=0;insert into orders values('" + getorderid() + "','0','" + getstaffid() + "','0',now(),'0','Sales')";
            MySqlCommand comm = new MySqlCommand(q, conn);
            comm.ExecuteNonQuery();

            this.Hide();
            newsalesorder nso = new newsalesorder();
            nso.ShowDialog();
            this.Show();
            refreshdatabase();
        }
        private string getorderid()
        {
            MySqlCommand comm = new MySqlCommand("select count(*) from orders", conn);
            Int32 norows = Convert.ToInt32(comm.ExecuteScalar());
            norows += 1;
            return norows.ToString();
        }
        private string getstaffid()
        {
            //checks user privilege
            string query = "select staffid from staff where username like '" + loginform.currentuser + "'";
            MySqlCommand comm = new MySqlCommand(query, conn);

            string id = Convert.ToString(comm.ExecuteScalar());
            return id;
        }

        private void purchaselist_Load(object sender, EventArgs e)
        {
            conn.Open();
            refreshdatabase();
        }
        private void refreshdatabase()
        {
            string query = "SELECT orders.date,p.orderid,concat(customer.lastname, ', ', customer.firstname) as 'Customer',GROUP_CONCAT(Distinct CONCAT(ol.quantity, ' ', ol.productname)) AS 'Orders',orders.total AS 'Total',p.amount as 'Paid',orders.discount,'', p.remaining, p.type " +
 " FROM orders, customer, payments p,orderline ol " +
 " WHERE orders.type != 'Delivery' and orders.customerid = customer.customerid AND orders.orderid = p.orderid AND orders.orderid = ol.orderid and p.orderid = ol.orderid GROUP BY orderid " +
 " union all " +
 " select orders.date, p.orderid, 'Walk-in', GROUP_CONCAT(Distinct CONCAT(ol.quantity, ' ', ol.productname)) AS 'Orders',orders.total AS 'Total',p.amount as 'Paid',orders.discount,'', p.remaining, p.type " +
 " from orders, payments p, orderline ol " +
 " where orders.type != 'Delivery' and orders.customerid = 0 and orders.orderid = p.orderid and orders.orderid = ol.orderid and p.orderid = ol.orderid group by orderid order by date desc";
            MySqlCommand comm = new MySqlCommand(query, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView1.DataSource = dt;
            dataGridView1.Columns["orderid"].HeaderText = "Order #";
            dataGridView1.Columns["type"].Visible = false;

            dataGridView1.Columns[7].Visible = false;
            dataGridView1.Columns["date"].HeaderText = "Date";
            dataGridView1.Columns["remaining"].HeaderText = "Balance";
        }

        private void purchaselist_FormClosing(object sender, FormClosingEventArgs e)
        {
            conn.Close();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string query = "SELECT orders.date,p.orderid,concat(customer.lastname, ', ', customer.firstname) as 'Customer',GROUP_CONCAT(Distinct CONCAT(ol.quantity, ' ', ol.productname)) AS 'Orders',orders.total AS 'Total',p.amount as 'Paid',orders.discount,'', p.remaining, p.type " +
 " FROM orders, customer, payments p,orderline ol " +
 " WHERE orders.type != 'Delivery' and orders.customerid = customer.customerid AND orders.orderid = p.orderid AND orders.orderid = ol.orderid and p.orderid = ol.orderid and orders.date between '" + dateTimePicker1.Value.Date.ToString("yyyy-MM-dd 00:00") + "' and '" + dateTimePicker2.Value.Date.AddDays(1).AddSeconds(-1).ToString("yyyy-MM-dd HH:mm") + "' GROUP BY orderid " +
 " union all " +
 " select orders.date, p.orderid, 'Walk-in', GROUP_CONCAT(Distinct CONCAT(ol.quantity, ' ', ol.productname)) AS 'Orders',orders.total AS 'Total',p.amount as 'Paid',orders.discount,'', p.remaining, p.type " +
 " from orders, payments p, orderline ol " +
 " where orders.type != 'Delivery' and orders.customerid = 0 and orders.orderid = p.orderid and orders.orderid = ol.orderid and p.orderid = ol.orderid and orders.date between '" + dateTimePicker1.Value.Date.ToString("yyyy-MM-dd 00:00") + "' and '" + dateTimePicker2.Value.Date.AddDays(1).AddSeconds(-1).ToString("yyyy-MM-dd HH:mm") + "' group by orderid order by date desc";
            MySqlCommand comm = new MySqlCommand(query, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView1.DataSource = dt;
            dataGridView1.Columns["orderid"].HeaderText = "Order #";
            dataGridView1.Columns["type"].Visible = false;

            dataGridView1.Columns[7].Visible = false;
            dataGridView1.Columns["date"].HeaderText = "Date";
            dataGridView1.Columns["remaining"].HeaderText = "Balance";
        }
    }
}
