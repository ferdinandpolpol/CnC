﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace creams
{
    public partial class loginform : Form
    {
        public MySqlConnection conn;
        public loginform()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;");
        }

        public static string currentuser;
        public static string currentuserid;

        private void loginbtn_Click(object sender, EventArgs e)
        {
            //Finds the user with the inputted username and password
            string q = "SELECT * FROM staff WHERE username = '" + usertxtbox.Text + "' AND password = '" + passtxtbox.Text + "'";
            try
            {
                conn.Open();
                MySqlCommand comm = new MySqlCommand(q, conn);
                comm.ExecuteNonQuery();
                MySqlDataAdapter adp = new MySqlDataAdapter(comm);
                DataTable dt = new DataTable();
                adp.Fill(dt);
                conn.Close();
                //Checks if the user is existing
                if (dt.Rows.Count > 0)
                {
                    conn.Open();
                    //Views the active column which determine user status
                    string active = "Select active from staff where active='Active' and username='" + usertxtbox.Text + "'";

                    MySqlCommand com = new MySqlCommand(active, conn);
                    com.ExecuteNonQuery();
                    MySqlDataAdapter ad = new MySqlDataAdapter(com);
                    DataTable t = new DataTable();
                    ad.Fill(t);
                    conn.Close();
                    //Checks if the user is active
                    if (t.Rows.Count > 0)
                    {
                        currentuser = usertxtbox.Text;
                        MessageBox.Show("Welcome to the Creams and Crumbs System!");
                        dashboard mf = new dashboard();
                        mf.Show();
                        this.Hide();
                    }
                    //Checks if the user is inactive
                    else
                    {
                        MessageBox.Show("User credentials are inactive.");
                    }

                }
                //Error for incorrect username or password
                else
                {
                    MessageBox.Show("Incorrect employee username or password");
                    usertxtbox.Clear(); //Clear() is for clearing the textbox
                    passtxtbox.Clear();
                }
            }
            catch(Exception er)
            {
                MessageBox.Show("Can't connect to database. Contact system developer");
            }
            
        }

        private void exitbtn_Click(object sender, EventArgs e)
        {
            //Exits the program
            this.Close();
            Application.Exit();
        }

        private void testbtn_Click(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                conn.Close();
                MessageBox.Show("Succesfully connected to the database");
            }
            catch (Exception er)
            {
                conn.Close();
                MessageBox.Show("Connection Error. Contact your local administrator.");
            }
        }

        private void loginform_Load(object sender, EventArgs e)
        {

        }

        private void usertxtbox_MouseClick(object sender, MouseEventArgs e)
        {
            usertxtbox.Clear();
        }

        private void passtxtbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void passlabel_Click(object sender, EventArgs e)
        {

        }

        private void usertxtbox_TextChanged(object sender, EventArgs e)
        {

        }

        private void userlabel_Click(object sender, EventArgs e)
        {

        }
    }
}
