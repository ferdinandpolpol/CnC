﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace creams
{
    public partial class customeraccount : Form
    {
        MySqlConnection conn;
        private string tempfname;
        private string tempstatus;
        private string templname;
        private string tempcontact;
        private string tempaddress;
        public static string orderid;
        public static string name;
        public static string customerid;
        public static string address;
        public static bool active;
        public static string bal;

        public customeraccount()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;");
        }

        private void customersoa_Load(object sender, EventArgs e)
        {
            comboBox1.Visible = false;
            label4.Visible = false;
            /*if(Convert.ToDouble(label14.Text) <= 0)
            {
                button5.Enabled = false;
            }
            else if(Convert.ToDouble(label14.Text) > 0)
            {
                button5.Enabled = true;
            }*/
            disableupdate();

            fillcustomerdetails();

            customerid = label10.Text = viewcustomer.custid;

            comboBox1.Items.Add("Active");
            comboBox1.Items.Add("Inactive");
            refreshdatabase();
            getcredits();
            getincome();
            name = textBox3.Text + ", " + textBox2.Text;

            button4.Enabled = false;
            button6.Enabled = false;
            showdues();
            if (overdue)
            {
                MessageBox.Show("Overdue balances!");
            }
        }
        private void refreshdatabase()
        {
            /**/
            conn.Close();
            conn.Open();
            string query = "SELECT orders.date,p.orderid,GROUP_CONCAT(Distinct CONCAT(ol.quantity, ' ', ol.productname)) AS 'Orders',orders.discount,orders.total AS 'Total',p.amount as 'Paid', p.remaining, p.due, p.type"+
" FROM orders, customer, payments p,orderline ol"+
" WHERE orders.customerid = '"+label10.Text+"' and orders.customerid = customer.customerid AND orders.orderid = p.orderid AND orders.orderid = ol.orderid and p.orderid = ol.orderid GROUP BY orderid";
            MySqlCommand comm = new MySqlCommand(query, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView1.DataSource = dt;
            dataGridView1.Columns["orderid"].Visible = false;
            dataGridView1.Columns["type"].Visible = false;
            dataGridView1.Columns["date"].HeaderText = "Date of Order";
            dataGridView1.Columns["remaining"].HeaderText = "Remaining Balance";
            dataGridView1.Columns["due"].HeaderText = "Payment Due";

            label11.Text = totalpurchase().ToString();
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void disableupdate()
        {
            button1.Visible = false;
            button2.Visible = false;
            comboBox1.Enabled = false;
            textBox2.Enabled = false;
            textBox3.Enabled = false;
            textBox4.Enabled = false;
            textBox5.Enabled = false;
            //textBox1.Enabled = false;
        }
        private void enableupdate()
        {
            button1.Visible = true;
            button2.Visible = true;
            comboBox1.Enabled = true;
            textBox2.Enabled = true;
            textBox3.Enabled = true;
            textBox4.Enabled = true;
            textBox5.Enabled = true;
            //textBox1.Enabled = true;
        }

        //Edit Button
        private void button3_Click(object sender, EventArgs e)
        {
            tempfname = textBox2.Text;
            templname = textBox3.Text;
            tempcontact = textBox5.Text;
            tempaddress = textBox4.Text;
            tempstatus = comboBox1.Text;
            enableupdate();
        }

        //Cancel Button
        private void button1_Click(object sender, EventArgs e)
        {
            disableupdate();
            textBox2.Text = tempfname;
            textBox3.Text = templname;
            textBox5.Text = tempcontact;
            textBox4.Text = tempaddress;
            comboBox1.Text = tempstatus;
        }
        private void fillcustomerdetails()
        {
            string q = "select * from customer where customerid = '" + viewcustomer.custid + "'";
            conn.Close();
            conn.Open();
            MySqlCommand cmdDataBase = new MySqlCommand(q, conn);
            MySqlDataReader myReader;

            myReader = cmdDataBase.ExecuteReader();

            while (myReader.Read())
            {
                string fname = myReader.GetString("firstname");
                string lname = myReader.GetString("lastname");
                string status = myReader.GetString("status");
                string contact = myReader.GetString("contact");
                string address = myReader.GetString("address");
                string discount = myReader.GetString("discount");

                //textBox1.Text = discount;
                textBox2.Text = fname;
                textBox3.Text = lname;
                textBox4.Text = address;
                textBox5.Text = contact;
                comboBox1.Text = status;
            }
            conn.Close();
        }
        private double totalpurchase()
        {
            try
            {
                string query = "select sum(total) from orders where customerid=" + label10.Text;
                MySqlCommand comm = new MySqlCommand(query, conn);
                double total = Convert.ToDouble(comm.ExecuteScalar());

                return total;
            }
            catch(Exception er)
            {
                return 0;
            }

            
        }

        //Save Button
        private void button2_Click(object sender, EventArgs e)
        {
            string q = "update customer set firstname = '" + textBox2.Text + "', lastname = '" + textBox3.Text + "', contact = '" + textBox5.Text + "', address = '" + textBox4.Text + "', status = '" + comboBox1.Text + "' where customerid=" + label10.Text;
            MySqlCommand comm = new MySqlCommand(q, conn);
            comm.ExecuteNonQuery();
            MessageBox.Show("Updated user!");
            disableupdate();
        }

        private void getcredits()
        {
            string q = "select balance from customer where customerid='"+ viewcustomer.custid + "'";
            MySqlCommand comm = new MySqlCommand(q, conn);
            label14.Text = comm.ExecuteScalar().ToString();
        }
        private void getincome()
        {
            double income = Convert.ToDouble(label11.Text) - Convert.ToDouble(label14.Text);
            label15.Text = income.ToString();
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            orderid = dataGridView1["orderid", dataGridView1.CurrentRow.Index].Value.ToString();
            active = true;
            orderdetails od = new orderdetails();
            od.ShowDialog();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            orderid = dataGridView1["orderid", dataGridView1.CurrentRow.Index].Value.ToString();
            button4.Enabled = true;
            if(Convert.ToInt32(dataGridView1["remaining", dataGridView1.CurrentRow.Index].Value) <= 0)
            {
                button6.Enabled = false;
            }
            else
            {
                button6.Enabled = true;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            active = true;
            orderdetails od = new orderdetails();
            od.ShowDialog();
        }
        public static bool allbalance = false;
        public static bool orderbalance = false;

        private void button5_Click(object sender, EventArgs e)
        {
            allbalance = true;
            balancepayment pay = new balancepayment();
            pay.ShowDialog();
            allbalance = false;
            fillcustomerdetails();
            refreshdatabase();
            getcredits();
            getincome();
            
        }

        private void customeraccount_FormClosing(object sender, FormClosingEventArgs e)
        {
            active = false;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            orderbalance = true;
            balancepayment pay = new balancepayment();
            pay.ShowDialog();
            orderbalance = false;
            fillcustomerdetails();
            refreshdatabase();
            getcredits();
            getincome();
        }
        bool overdue = false;
        private void showdues()
        {
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                DateTime duedate = Convert.ToDateTime(row.Cells["due"].Value);
                string remaining = (duedate - DateTime.Now).Days.ToString();
                if (Convert.ToInt32(remaining) < 0 && row.Cells["type"].Value.ToString() == "Downpayment")
                {
                    row.Cells["due"].Style.BackColor = Color.LightCoral;
                    overdue = true;
                }
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            bal = label14.Text;
            address = textBox4.Text;
            name = textBox3.Text + ", " + textBox2.Text;
            customerstatement cs = new customerstatement();
            cs.ShowDialog();
        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
