﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace creams
{
    public partial class stockin : Form
    {
        MySqlConnection conn;
        public stockin()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;");
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void stockin_Load(object sender, EventArgs e)
        {
            fillponumber();
            dateTimePicker1.MinDate = DateTime.Now;
            conn.Open();
            label10.Text = getstockinid().ToString();
            textBox1.Enabled = false;
            dateTimePicker1.Enabled = false;
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
        public void fillponumber()
        {
            try
            {
                conn.Open();
                string qr = "select * from purchaseorder";
                MySqlCommand cmdDataBase = new MySqlCommand(qr, conn);
                MySqlDataReader myReader;

                //reads every row in product table
                myReader = cmdDataBase.ExecuteReader();
                while (myReader.Read())
                {
                    string pid = myReader.GetString("purchaseid");
                    //adding entry on comboBox1
                    comboBox1.Items.Add(pid);
                }
                conn.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Database Error: Please contact your developer.");
            }
        }

        List<string> stockins = new List<string>();

        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count <= 0)
            {
                MessageBox.Show("Please add products to Stock-in");
            }
            else
            {
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    string query = "set foreign_key_checks = 0; insert into stockinline(stockinid,purchaseid,pdid,deliverynumber,productid,quantity,expirydate,date) values('"+label10.Text+"','"+row.Cells[5].Value.ToString()+"','"+row.Cells[1].Value.ToString()+"','"
                                    +row.Cells[6].Value.ToString()+"','"+ row.Cells[0].Value.ToString() + "','"+ row.Cells[3].Value.ToString() + "','"+ row.Cells[4].Value.ToString() + "',now()); set foreign_key_checks = 1; ";
                    MySqlCommand comm = new MySqlCommand(query, conn);
                    comm.ExecuteNonQuery();

                    string query1 = "insert into saleinventory(productid, quantity, expiry, purchaseid,stockinlineid) values (" + row.Cells[0].Value.ToString() + "," + row.Cells[3].Value.ToString() + ",'"+ row.Cells[4].Value.ToString() + "','"+ row.Cells[5].Value.ToString() + "', '"+getstockinlineid()+"')";
                    MySqlCommand comm1 = new MySqlCommand(query1, conn);
                    comm1.ExecuteNonQuery();

                    string query2 = "update purchasedetails set quantity = quantity - '" + row.Cells[3].Value.ToString() + "' where pdid = '" + row.Cells[1].Value.ToString() + "'";
                    MySqlCommand comm2 = new MySqlCommand(query2, conn);
                    comm2.ExecuteNonQuery();
                    stockins.Add(row.Cells[3].Value.ToString() + " - " + row.Cells[2].Value.ToString());
                }

                string q = "insert into stockin values('" + label10.Text + "',now())";
                MySqlCommand qcomm = new MySqlCommand(q, conn);
                MessageBox.Show("Stocked-in: \n" + string.Join(Environment.NewLine, stockins));
                qcomm.ExecuteNonQuery();
                this.Close();
            } 
        }
        private string getstockinlineid()
        {
            string q = "select count(*) from stockinline";
            MySqlCommand qcomm = new MySqlCommand(q, conn);
            return qcomm.ExecuteScalar().ToString();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            conn.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            bool isexist = false;

            string pname = dataGridView2[0, dataGridView2.CurrentRow.Index].Value.ToString();
            string pdid = dataGridView2[1, dataGridView2.CurrentRow.Index].Value.ToString();
            string puid = dataGridView2[2, dataGridView2.CurrentRow.Index].Value.ToString();
            string pid = dataGridView2[3, dataGridView2.CurrentRow.Index].Value.ToString();
            string qty = dataGridView2[4, dataGridView2.CurrentRow.Index].Value.ToString();
            string subt = dataGridView2[5, dataGridView2.CurrentRow.Index].Value.ToString();
            //checks if product exists on grid
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if(row.Cells["productid"].Value.ToString() == pid)
                {
                    isexist = true;
                }
            }

            if (grid2click == false)
            {
                MessageBox.Show("Please choose a product");
            }
            else if(string.IsNullOrWhiteSpace(textBox1.Text) ||
                    string.IsNullOrWhiteSpace(textBox2.Text) ||
                    string.IsNullOrWhiteSpace(dateTimePicker1.Text))
            {
                MessageBox.Show("Empty Field/s");
            }
            else if (isexist)
            {
                MessageBox.Show("Product already added.");
            }
            else
            {
                try
                {
                    this.dataGridView1.Rows.Add(pid,pdid, pname, textBox1.Text,dateTimePicker1.Value.Date.ToString("yyyy/MM/dd"),comboBox1.Text, textBox2.Text);
                    textBox1.Clear();
                }
                catch(Exception er)
                {
                    
                }
            }   
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if(!grid1click)
            {
                MessageBox.Show("Please select");
            }
            else
            {
                DialogResult dr = MessageBox.Show(@"Remove?",
                                               Application.ProductName,
                                               MessageBoxButtons.YesNo);
                if (dr == DialogResult.Yes)
                {
                    this.dataGridView1.Rows.RemoveAt(dataGridView1.CurrentRow.Index);
                }    
            }
            
        }
        private int getstockinid()
        {
            string q = "select count(*) from stockin";
            MySqlCommand comm = new MySqlCommand(q, conn);
            return Convert.ToInt32(comm.ExecuteScalar()) + 1;
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show(@"Do you want to remove all?",
                                               Application.ProductName,
                                               MessageBoxButtons.YesNo);
            if (dr == DialogResult.Yes)
            {
                dataGridView1.Rows.Clear();
            }
        }
        bool grid1click = false;
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            grid1click = true;
        }

        private void comboBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }
        bool grid2click = false;
        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            grid2click = true;
            textBox1.Enabled = true;
            string prodid = dataGridView2[3, dataGridView2.CurrentRow.Index].Value.ToString();
            string q = "select producttype from product where productid = '" + prodid + "'";
            MySqlCommand comm = new MySqlCommand(q, conn);
            if (comm.ExecuteScalar().ToString() == "Non-Consumable")
            {
                dateTimePicker1.Enabled = false;
                dateTimePicker1.Value = DateTime.Now.AddYears(99);
            }
            else
            {
                dateTimePicker1.Enabled = true;
                dateTimePicker1.Value = DateTime.Now.AddDays(30);
            }
        }

        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            string q = "select product.productname, purchasedetails.* from purchasedetails, product where purchaseid = '" + comboBox1.Text+"' and purchasedetails.productid = product.productid";
            MySqlCommand comm = new MySqlCommand(q, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView2.DataSource = dt;
            dataGridView2.Columns["purchaseid"].Visible = false;
            dataGridView2.Columns["pdid"].Visible = false;
            dataGridView2.Columns["productid"].Visible = false;

        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            try
            {
                if (Convert.ToInt32(textBox1.Text) > Convert.ToInt32(dataGridView2["quantity", dataGridView2.CurrentRow.Index].Value.ToString()))
                {
                    MessageBox.Show("Invalid Quantity");
                    textBox1.Clear();
                }
            }
            catch
            {

            }
        }
    }
}
