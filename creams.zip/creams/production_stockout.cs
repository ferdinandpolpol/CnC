﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace creams
{ 
    public partial class production_stockout : Form
    {
        MySqlConnection conn;

        public production_stockout()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;convert zero datetime=True");
        }

        private void production_stockout_Load(object sender, EventArgs e)
        {
            conn.Open();
            loadinventory();
        }
        private void loadinventory()
        {
            string q = "select productioninventoryid, transferid, productname, sum(quantity), unit from productioninventory where quantity > 0 group by productname, unit";
            MySqlCommand comm = new MySqlCommand(q, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].Visible = false;
            dataGridView1.Columns[1].Visible = false;
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            try
            {
                if (Convert.ToInt64(textBox1.Text) > Convert.ToInt64(dataGridView1["quantity", dataGridView1.CurrentRow.Index].Value))
                {
                    MessageBox.Show("Invalid quantity");
                    textBox1.Clear();
                }
            }
            catch
            {

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrWhiteSpace(textBox1.Text) ||
                string.IsNullOrWhiteSpace(comboBox2.Text))
            {
                MessageBox.Show("Empty field/s");
            }
            else
            {
                string prodinvid = dataGridView1["productioninventoryid", dataGridView1.CurrentRow.Index].Value.ToString();
                string productname = dataGridView1[2, dataGridView1.CurrentRow.Index].Value.ToString();
                string unit = dataGridView1[4, dataGridView1.CurrentRow.Index].Value.ToString();

                string qty = textBox1.Text;
                string reason = comboBox2.Text;

                dataGridView2.Rows.Add(prodinvid, productname, unit, qty, reason);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in dataGridView2.Rows)
            {
                //string pid = row.Cells["productid"].Value.ToString();
                string pn = row.Cells[1].Value.ToString();
                string punit = row.Cells[2].Value.ToString();
                string reason = row.Cells[4].Value.ToString();
                string quantity = row.Cells["quantity"].Value.ToString();
                string piid1 = row.Cells[0].Value.ToString();

                string q = "select * from productioninventory pi where pi.productname = '" + pn + "' and unit = '" + punit + "' and quantity > 0";
                MySqlCommand comm1 = new MySqlCommand(q, conn);
                MySqlDataAdapter adp = new MySqlDataAdapter(comm1);
                DataTable dt = new DataTable();
                adp.Fill(dt);
                dataGridView3.DataSource = dt;
                
                foreach (DataGridViewRow row2 in dataGridView3.Rows)
                {
                    if (Convert.ToInt32(row2.Cells["quantity"].Value) > 0)
                    {
                        string piid = row2.Cells["productioninventoryid"].Value.ToString();
                        if (Convert.ToInt32(row2.Cells["quantity"].Value) >= Convert.ToInt32(row.Cells["quantity"].Value))
                        {
                            string q1 = "update productioninventory set productioninventory.quantity = productioninventory.quantity - '" + quantity + "' where productioninventory.productioninventoryid = '" + piid + "';" +
                                "insert into productionstockout(productioninventoryid, quantity, reason, date, productname, unit) values('"+piid+"','"+quantity+"','"+reason+ "',now(), '" + pn + "', '"+punit+"')";
                            MySqlCommand com1 = new MySqlCommand(q1, conn);
                            com1.ExecuteNonQuery();
                            break;
                        }
                        else if (Convert.ToInt32(row2.Cells["quantity"].Value) < Convert.ToInt32(row.Cells["quantity"].Value))
                        {
                            string productionquantity = row2.Cells["quantity"].Value.ToString();
                            string olquantity = row.Cells["quantity"].Value.ToString();
                            string quantityleft = (Convert.ToInt32(olquantity) - Convert.ToInt32(productionquantity)).ToString();

                            row.Cells["quantity"].Value = Convert.ToInt32(quantity) - Convert.ToInt32(quantityleft);
                            string q1 = "update productioninventory set productioninventory.quantity = 0 where productioninventory.productioninventoryid = '" + piid + "';"+
                                "insert into productionstockout(productioninventoryid, quantity, reason, date, productname, unit) values('" + piid + "','" + row.Cells["quantity"].Value.ToString() + "','" + reason + "',now(), '"+pn+"', '"+punit+"')";

                            dataGridView2.Rows.Add(piid1, pn, punit, quantityleft, reason);

                            MySqlCommand com1 = new MySqlCommand(q1, conn);
                            com1.ExecuteNonQuery();
                            break;
                        }
                    }
                    else
                    {
                        continue;
                    }
                }
            }
            MessageBox.Show("Success");
            this.Close();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (gridclick == false)
            {
                MessageBox.Show("Please select");
            }
            else
            {
                    DialogResult dr = MessageBox.Show(@"Remove?",
                                                   Application.ProductName,
                                                   MessageBoxButtons.YesNo);
                    if (dr == DialogResult.Yes)
                    {
                        this.dataGridView1.Rows.RemoveAt(dataGridView1.CurrentRow.Index);
                    }
            }
        }
        bool gridclick = false;
        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            gridclick = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (gridclick == false)
            {
                MessageBox.Show("Please select");
            }
            else
            {
                DialogResult dr = MessageBox.Show(@"Remove All?",
                                               Application.ProductName,
                                               MessageBoxButtons.YesNo);
                if (dr == DialogResult.Yes)
                {
                    this.dataGridView1.Rows.Clear();
                }
            }
        }
    }
}
