﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace creams
{
    public partial class orderdetails : Form
    {
        MySqlConnection conn;
        public orderdetails()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;");
        }

        private void orderdetails_Load(object sender, EventArgs e)
        {
            conn.Open();
            if (customeraccount.active)
            {
                label5.Text = customeraccount.orderid;
                label6.Text = customeraccount.name;
                
            }
            else if (salesreport.active)
            {
                label5.Text = salesreport.orderid;
                label6.Text = getcustomer();
            }
            else if (productionlist.active == true)
            {
                label5.Text = productionlist.orderid;
                label6.Text = getcustomer();
            }
            label8.Text = gettotal();
            label7.Text = getdate();
            getpstatus();
            if (label10.Text == "Paid")
                label10.BackColor = Color.LightGreen;
            refreshdatabase();
        }
        private void refreshdatabase()
        {
            string q = "select * from orderline where orderid = '"+label5.Text+ "'";
            MySqlCommand comm = new MySqlCommand(q, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView1.DataSource = dt;

            dataGridView1.Columns["orderlineid"].Visible = false;
            dataGridView1.Columns["orderid"].Visible = false;
            dataGridView1.Columns["productid"].Visible = false;
            dataGridView1.Columns["saleid"].Visible = false;
            dataGridView1.Columns["selling_price"].HeaderText = "Price";
            dataGridView1.Columns["productname"].HeaderText = "Product";
            dataGridView1.Columns["discount"].HeaderText = "Discount";
            dataGridView1.Columns["quantity"].HeaderText = "Quantity Bought";
            dataGridView1.Columns["subtotal"].HeaderText = "Subtotal";
        }
        private void getpstatus()
        {
            string q = "select status from payments where orderid='" + label5.Text + "'";
            MySqlCommand comm = new MySqlCommand(q, conn);
            label10.Text = comm.ExecuteScalar().ToString();
            string q1 = "select remaining from payments where orderid='" + label5.Text + "'";
            MySqlCommand comm1 = new MySqlCommand(q1, conn);
            label11.Text = comm1.ExecuteScalar().ToString();
            string q2 = "select amount from payments where orderid='" + label5.Text + "'";
            MySqlCommand comm2 = new MySqlCommand(q2, conn);
            label13.Text = comm2.ExecuteScalar().ToString();
        }
        private string getdate()
        {
            string q = "select date from orders where orderid='" + label5.Text + "'";
            MySqlCommand comm = new MySqlCommand(q, conn);
            return comm.ExecuteScalar().ToString();
        }
        private string gettotal()
        {
            string q = "select total from orders where orderid='" + label5.Text + "'";
            MySqlCommand comm = new MySqlCommand(q, conn);
            return comm.ExecuteScalar().ToString();
        }
        private string getcustomer()
        {
            string q = "select concat(customer.lastname, ', ', customer.firstname) from customer, orders where customer.customerid=orders.customerid and orders.orderid='" + label5.Text + "'";
            MySqlCommand comm = new MySqlCommand(q, conn);
            return comm.ExecuteScalar().ToString();
        }
        private void orderdetails_FormClosing(object sender, FormClosingEventArgs e)
        {
            conn.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
