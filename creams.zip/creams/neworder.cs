﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Drawing.Printing;
using Microsoft.VisualBasic;

namespace creams
{
    //ORDER TYPES: Sale, Delivery, Production, Cancelled

    public partial class neworder : Form
    {
        MySqlConnection conn;
        public static string orderid;
        public static string customerid;
        public static string total;
        public static bool active;
        public static DateTime deliverydate;
        public neworder()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;");
            
        }
        
        private void neworder_Load(object sender, EventArgs e)
        {
            dateTimePicker1.MinDate = DateTime.Now;
            submittedorder = false;
            fillcustomercmb();
            conn.Open();
            textBox1.Enabled = false;
            discounttxt.Text = 0.ToString();                //Sets default value for discount
            //discounttxt.Enabled = false;

            groupBox1.Visible = false;

            orderidtext.Text = getrowcount();
            refreshdatabase();

        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            if (customercmb.Text == "New Customer")
            {
                newcustomer newcust = new newcustomer();
                newcust.ShowDialog();
                customercmb.Items.Clear();
                fillcustomercmb();
                conn.Open();
            }
            refreshdatabase();

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }
        

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox1.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            active = true;
            orderid = orderidtext.Text;
            productlist pl = new productlist();
            pl.ShowDialog();
            active = false;

            refreshdatabase();
        }

        //Submit Order Button
        bool submittedorder = false;
        private void button3_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(customercmb.Text))
            {
                MessageBox.Show("Please choose a customer!");
            }
            else if (!isdelivery)
            {
                MessageBox.Show("Please set delivery schedule!");
            }
            else
            {
                DialogResult dr = MessageBox.Show(@"Are you sure about everything?",
                                               Application.ProductName,
                                               MessageBoxButtons.YesNo);
                if (dr == DialogResult.Yes)
                {
                    active = true;
                    string check = "select count(*) from orderline where orderid = '" + orderidtext.Text + "'";
                    MySqlCommand com = new MySqlCommand(check, conn);
                    if (Convert.ToInt32(com.ExecuteScalar()) <= 0)
                    {
                        MessageBox.Show("Please select products to order");
                    }
                    else
                    {
                        total = totalresult.Text;
                        orderid = orderidtext.Text;
                        deliverydate = dateTimePicker1.Value.Date;
                        payment pay = new payment();
                        pay.ShowDialog();
                        if (payment.cancel == true)
                        {
                            MessageBox.Show("Payment Cancelled");
                        }

                        else
                        {
                            if (string.IsNullOrWhiteSpace(discounttxt.Text))
                                discounttxt.Text = 0.ToString();
                            string query = "update orders set customerid='" + getcustomerid() + "', total='" + total + "', date=current_timestamp, discount='" + discounttxt.Text + "', type='Delivery' where orderid=" + orderidtext.Text;
                            MySqlCommand comm = new MySqlCommand(query, conn);
                            comm.ExecuteNonQuery();
                            string qdelivery = "insert into delivery(orderid, customerid, deliveryaddress, deliverydate) values('" + orderidtext.Text + "','" + getcustomerid() + "','" + address.Text + "','" + dateTimePicker1.Value.Date.ToString("yyyyMMdd") + "')";
                            MySqlCommand commdelivery = new MySqlCommand(qdelivery, conn);
                            commdelivery.ExecuteNonQuery();

                            MessageBox.Show("Succesfully created order!");
                            submittedorder = true;

                            PrintDialog printDialog = new PrintDialog();

                            PrintDocument printDocument = new PrintDocument();

                            PrintPreviewDialog printPreviewDialog1 = new PrintPreviewDialog();
                            printDialog.Document = printDocument; //add the document to the dialog box...        
                            printDocument.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(CreateReceipt); //add an event handler that will do the printing
                            printPreviewDialog1.Document = printDocument;
                            printPreviewDialog1.ShowDialog();

                            this.Close();
                        }
                    }
                }
            }
            
            //on a till you will not want to ask the user where to print but this is fine for the test envoironment.
        }
        //PRINTING SHI

        private void btnPrintReciept_Click(object sender, EventArgs e)
        {

        }

        public void CreateReceipt(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {

            double total = Convert.ToDouble(payment.total);
            double cash = Convert.ToDouble(payment.amount);
            double change = Convert.ToDouble(payment.change);

            //this prints the reciept

            Graphics graphic = e.Graphics;

            Font font = new Font("Courier New", 12); //must use a mono spaced font as the spaces need to line up

            float fontHeight = font.GetHeight();

            int startX = 10;
            int startY = 10;
            int offset = 40;

            graphic.DrawString(" Creams and Crumbs", new Font("Courier New", 18), new SolidBrush(Color.Black), startX, startY);
            string top = "Item Name".PadRight(30) + "Price";
            graphic.DrawString(top, font, new SolidBrush(Color.Black), startX, startY + offset);
            offset = offset + (int)fontHeight; //make the spacing consistent
            graphic.DrawString("----------------------------------", font, new SolidBrush(Color.Black), startX, startY + offset);
            offset = offset + (int)fontHeight + 5; //make the spacing consistent


            foreach (DataGridViewRow item in dataGridView1.Rows)
            {
                //create the string to print on the reciept
                string productDescription = item.Cells["productname"].Value.ToString() + " X " + item.Cells["quantity"].Value.ToString();
                string productTotal = item.Cells["subtotal"].Value.ToString();
                string productPrice = item.Cells["selling_price"].Value.ToString();

                //MessageBox.Show(item.Substring(item.Length - 5, 5) + "PROD TOTAL: " + productTotal);


                //totalprice += productPrice;

                if (productDescription.Contains("  -"))
                {
                    string productLine = item.Cells["subtotal"].Value.ToString();

                    graphic.DrawString(productLine, new Font("Courier New", 12, FontStyle.Italic), new SolidBrush(Color.Red), startX, startY + offset);

                    offset = offset + (int)fontHeight + 5; //make the spacing consistent
                }
                else
                {
                    string productLine = productDescription;

                    graphic.DrawString(productLine.PadRight(30) + String.Format("{0:c}", productTotal), font, new SolidBrush(Color.Black), startX, startY + offset);
                    //graphic.DrawString("Order #".PadRight(30) + String.Format("{0:c}", orderidtext.Text), font, new SolidBrush(Color.Black), startX, startY + offset);
                    offset = offset + (int)fontHeight + 5; //make the spacing consistent
                }

            }

            //when we have drawn all of the items add the total

            offset = offset + 20; //make some room so that the total stands out.
            graphic.DrawString("Order #".PadRight(30) + String.Format("{0:c}", orderidtext.Text), font, new SolidBrush(Color.Black), startX, startY + offset);
            offset = offset + 20;
            graphic.DrawString("Total to pay ".PadRight(30) + String.Format("{0:c}", total), new Font("Courier New", 12, FontStyle.Bold), new SolidBrush(Color.Black), startX, startY + offset);

            offset = offset + 30; //make some room so that the total stands out.
            graphic.DrawString("CASH ".PadRight(30) + String.Format("{0:c}", cash), font, new SolidBrush(Color.Black), startX, startY + offset);
            offset = offset + 15;
            graphic.DrawString("CHANGE ".PadRight(30) + String.Format("{0:c}", change), font, new SolidBrush(Color.Black), startX, startY + offset);
            offset = offset + 30; //make some room so that the total stands out.
            graphic.DrawString("     Thank-you for your custom,", font, new SolidBrush(Color.Black), startX, startY + offset);
            offset = offset + 15;
            graphic.DrawString("       please come back soon!", font, new SolidBrush(Color.Black), startX, startY + offset);

        }//PRINTING SHIT 

        private bool isproduction()
        {
            bool hasfood = false;
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if(row.Cells["producttype"].Value.ToString() == "Food")
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return hasfood;
        }
        //Refresh Button 
        private void button4_Click(object sender, EventArgs e)
        {
            refreshdatabase();
        }

        //Methods
        //Determines the current order id
        private string getrowcount()
        {
            MySqlCommand comm = new MySqlCommand("select count(*) from orders", conn);
            
            Int32 norows = Convert.ToInt32(comm.ExecuteScalar());
            return norows.ToString();
        }

        private string getcustomerid()
        {
            string query = "select customerid from customer where concat(lastname,', ' ,firstname)='" + customercmb.Text + "'";
            MySqlCommand comm = new MySqlCommand(query , conn);
            

            Int32 custid = Convert.ToInt32(comm.ExecuteScalar());
            customerid = custid.ToString();
            return custid.ToString();
        }

        private string gettotal()
        {
            double total = 0;
            foreach(DataGridViewRow row in dataGridView1.Rows)
            {
                total += Convert.ToDouble(row.Cells["subtotal"].Value);
            }
            return total.ToString();
        }

        private string getquantity()
        {
            string query = "select quantity from orderline";
            MySqlCommand comm = new MySqlCommand(query, conn);

            Int32 quantity = Convert.ToInt32(comm.ExecuteScalar());
            return quantity.ToString();
        }
        private void refreshdatabase()
        {
            //selects all the staff from the database
            string query = "select ol.orderlineid, ol.productid, p.productname, p.selling_price, p.producttype, ol.quantity, ol.subtotal from orderline ol join product p on ol.productid = p.productid where ol.orderid = '" + orderidtext.Text + "'";
            MySqlCommand comm = new MySqlCommand(query, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm); //used on select query only
            DataTable dt = new DataTable();
            adp.Fill(dt);

            //Loads the database values to the dataGridView
            dataGridView1.DataSource = dt;

            dataGridView1.Columns["productid"].Visible = false;
            dataGridView1.Columns["producttype"].Visible = false;
            dataGridView1.Columns["orderlineid"].Visible = false;
            dataGridView1.Columns["productname"].HeaderText = "Product";
            dataGridView1.Columns["selling_price"].HeaderText = "Price";
            dataGridView1.Columns["quantity"].HeaderText = "Quantity";
            dataGridView1.Columns["subtotal"].HeaderText = "Subtotal";
            total = totalresult.Text = gettotal();
            discounttxt.Clear();

        }
        public void fillcustomercmb()
        {
            conn.Close();
            conn.Open();
            try
            {
                string qr = "select * from customer;";
                MySqlCommand cmdDataBase = new MySqlCommand(qr, conn);
                MySqlDataReader myReader;

                myReader = cmdDataBase.ExecuteReader();

                while (myReader.Read())
                {
                    string cid = myReader.GetString("customerid");
                    //getting the name of the product on the row being read
                    
                    //Remove the irst customer which is for the  walk-in record
                    string fname = myReader.GetString("firstname");
                    string lname = myReader.GetString("lastname");
                    //adding entry on comboBox1
                    customercmb.Items.Add(lname + ", " + fname);
                }
             }
             catch (Exception)
             {
                 MessageBox.Show("Database Error: Please contact your developer.");
             }
            conn.Close();
        }

        private void neworder_FormClosing_1(object sender, FormClosingEventArgs e)
        {
            if (submittedorder == true)
            {

            }
            else
            {
                DialogResult dr = MessageBox.Show(@"Do you really want to close the form?",
                                               Application.ProductName,
                                               MessageBoxButtons.YesNo);
                if (dr == DialogResult.Yes && submittedorder == false)
                {
                    string type = "delete from orders where orderid='" + orderidtext.Text + "'; delete from orderline where orderid='" + orderidtext.Text + "'";
                    MySqlCommand commtype = new MySqlCommand(type, conn);
                    commtype.ExecuteNonQuery();
                }
                else if (dr == DialogResult.No)
                {
                    e.Cancel = true;
                }
            }
            

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string orderlineid = dataGridView1["orderlineid", dataGridView1.CurrentRow.Index].Value.ToString();
                string productname = dataGridView1[2, dataGridView1.CurrentRow.Index].Value.ToString();
                string query = "delete from orderline where orderlineid =" + orderlineid;
                MySqlCommand comm = new MySqlCommand(query, conn);
                comm.ExecuteNonQuery();

                MessageBox.Show("Removed Product " + productname);
                refreshdatabase();
            }
            catch(Exception er)
            {
                MessageBox.Show("Please select a product to remove.");
            }
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                //Collects the values from the tables to the textbox's
                //textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells["productname"].Value.ToString();
                textBox1.Enabled = true;
                textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells["quantity"].Value.ToString();
            }
            catch (Exception er)
            {
                //This is to prevent an error in the code when the table header is pressed
                //No message is shown to prevent annoying, repeating message
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            
                
        }
        private void button11_Click(object sender, EventArgs e)
        {
            
        }

        //Gets price of the selected row of product
        private double getprice()
        {
            string orderlineid2 = dataGridView1["orderlineid", dataGridView1.CurrentRow.Index].Value.ToString();
            string priceq = "select selling_price from orderline where orderlineid=" + orderlineid2 + ";";
            MySqlCommand comm2 = new MySqlCommand(priceq, conn);
            double price = Convert.ToDouble(comm2.ExecuteScalar());
            return price;
        }
        private bool isdelivery;
        private string getaddress()
        {
            string q = "select address from customer where customerid = " + Convert.ToInt32(getcustomerid());
            MySqlCommand comm = new MySqlCommand(q, conn);
            return comm.ExecuteScalar().ToString();
        }
        private void button7_Click(object sender, EventArgs e)
        {      
            groupBox1.Visible = false;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {
            
        }

        private void calculatediscount()
        {
            try
            {
                totalresult.Text = (Convert.ToDouble(totalresult.Text) - Convert.ToDouble(discounttxt.Text)).ToString();
            }
            catch (Exception er)
            {

            }
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(customercmb.Text))
            {
                MessageBox.Show("Please choose a customer!");
            }
            else
            {
                groupBox1.Visible = true;
                custname.Text = customercmb.Text;
                address.Text = getaddress();
                isdelivery = true;
            }
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            string orderlineid2 = dataGridView1["orderlineid", dataGridView1.CurrentRow.Index].Value.ToString();
            string productname = dataGridView1["productname", dataGridView1.CurrentRow.Index].Value.ToString();
            if (orderlineid2 == null)
            {
                MessageBox.Show("Please select a product");
            }
            else if (string.IsNullOrWhiteSpace(textBox1.Text))
            {

            }
            else
            {
                string pid = dataGridView1["productid", dataGridView1.CurrentRow.Index].Value.ToString();


                string qty = "select si.quantity from saleinventory si join orderline ol on si.productid=ol.productid where ol.productid='" + pid + "' group by quantity";
                MySqlCommand comm2 = new MySqlCommand(qty, conn);
                comm2.ExecuteNonQuery();
                Int32 quantity = Convert.ToInt32(comm2.ExecuteScalar());

                double subtotal = Convert.ToInt32(textBox1.Text) * getprice();

                string q = "update orderline set quantity = '" + textBox1.Text + "', subtotal = '" + subtotal + "' where orderlineid = '" + orderlineid2 + "'";
                MySqlCommand comm3 = new MySqlCommand(q, conn);
                comm3.ExecuteNonQuery();

                refreshdatabase();
            }
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
        }

        private void discounttxt_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void discounttxt_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(discounttxt.Text))
            {
                totalresult.Text = gettotal();
            }
            else
            {
                totalresult.Text = (Convert.ToDouble(totalresult.Text) - Convert.ToDouble(discounttxt.Text)).ToString();
            }

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void discounttxt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back && e.KeyChar != '.')
            {
                e.Handled = true;
            }
        }

        private void button4_Click_1(object sender, EventArgs e)
        {

        }
    }
}
