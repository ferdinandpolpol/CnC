﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

namespace creams
{
    public partial class customerstatement : Form
    {
        MySqlConnection conn;
        public customerstatement()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;");
        }

        private void customerstatement_Load(object sender, EventArgs e)
        {
            crystalReportViewer1.Visible = false;
            label3.Text = customeraccount.name;
            label4.Text = customeraccount.address;
            label5.Text = customeraccount.bal;
            refreshdatabase();
        }
        private void refreshdatabase()
        {
            string query = "select * from " +
                        "(SELECT orders.date,GROUP_CONCAT(Distinct CONCAT(ol.quantity, ' ', ol.productname)) AS 'Order', '' as Payments, p.paymentid, p.amount as 'Paid','', orders.total,p.remaining,'-' FROM orders, customer, payments p, orderline ol WHERE orders.customerid = '" + viewcustomer.custid + "' and orders.customerid = customer.customerid AND orders.orderid = p.orderid AND orders.orderid = ol.orderid and p.orderid = ol.orderid GROUP BY orders.orderid " +
                        " UNION all " +
                        " SELECT '','', 'Payment', paymentid, payment,paymentline.date, '', '', paychange FROM paymentline where  customerid = '" + viewcustomer.custid + "' order by paymentid, date) t order by paymentid desc, date desc";
            MySqlCommand comm = new MySqlCommand(query, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView1.DataSource = dt;
            dataGridView1.Columns["paymentid"].Visible = false;
            dataGridView1.Columns[1].HeaderText = "Order";
            dataGridView1.Columns[2].HeaderText = "Description";
            dataGridView1.Columns[5].HeaderText = "Payment Dates";
            dataGridView1.Columns[6].HeaderText = "Total";
            dataGridView1.Columns[7].HeaderText = "Balance";
            dataGridView1.Columns[8].HeaderText = "Change";
            dataGridView1.Columns[8].Visible = false;

            loopgrid();
        }
        private void loopgrid()
        {
            foreach(DataGridViewRow row in dataGridView1.Rows)
            {
                if(!string.IsNullOrWhiteSpace(row.Cells[1].Value.ToString()))
                {
                    row.DefaultCellStyle.BackColor = Color.Gainsboro;
                }
                else
                {

                }
                if(!string.IsNullOrWhiteSpace(row.Cells[1].Value.ToString()) && Convert.ToDouble(row.Cells[4].Value) == Convert.ToDouble(row.Cells[6].Value))
                {
                    row.Cells[4].Style.BackColor = Color.LightGreen;
                }
                else
                {

                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (cancel)
            {
                string s = System.IO.Directory.GetCurrentDirectory().ToString();

                int x = s.IndexOf("bin\\Debug");
                if (x != -1)
                {
                    s = s.Remove(x);
                }
                s += "CrystalReport5.rpt";
                crystalReportViewer1.Visible = true;
                ReportDocument cryRpt = new ReportDocument();
                cryRpt.Load(@s);

                ParameterFieldDefinitions crParameterFieldDefinitions;
                ParameterFieldDefinition crParameterFieldDefinition;
                ParameterValues crParameterValues = new ParameterValues();
                ParameterDiscreteValue crParameterDiscreteValue = new ParameterDiscreteValue();

                crParameterDiscreteValue.Value = label3.Text;
                crParameterFieldDefinitions = cryRpt.DataDefinition.ParameterFields;
                crParameterFieldDefinition = crParameterFieldDefinitions["Customername"];
                crParameterValues = crParameterFieldDefinition.CurrentValues;

                crParameterValues.Clear();
                crParameterValues.Add(crParameterDiscreteValue);
                crParameterFieldDefinition.ApplyCurrentValues(crParameterValues);

                crParameterDiscreteValue.Value = label4.Text;
                crParameterFieldDefinitions = cryRpt.DataDefinition.ParameterFields;
                crParameterFieldDefinition = crParameterFieldDefinitions["address"];
                crParameterValues = crParameterFieldDefinition.CurrentValues;

                crParameterValues.Clear();
                crParameterValues.Add(crParameterDiscreteValue);
                crParameterFieldDefinition.ApplyCurrentValues(crParameterValues);

                crystalReportViewer1.ReportSource = cryRpt;
                crystalReportViewer1.Refresh();
            }
            else if (apply)
            {
                string query = "select * from " +
                        "(SELECT orders.date,GROUP_CONCAT(Distinct CONCAT(ol.quantity, ' ', ol.productname)) AS 'Order', '' as Payments, p.paymentid, p.amount as 'Paid','' as _, orders.total,p.remaining,'-' FROM orders, customer, payments p, orderline ol WHERE orders.customerid = '" + viewcustomer.custid + "' and orders.customerid = customer.customerid AND orders.orderid = p.orderid AND orders.orderid = ol.orderid and p.orderid = ol.orderid and orders.date between '" + dateTimePicker1.Value.Date.ToString("yyyy-MM-dd 00:00") + "' and '" + dateTimePicker2.Value.Date.AddDays(1).AddSeconds(-1).ToString("yyyy-MM-dd HH:mm") + "' GROUP BY orders.orderid " +
                        " UNION all " +
                        " SELECT '','', 'Payment', paymentid, payment,paymentline.date, '', '', paychange FROM paymentline where  customerid = '" + viewcustomer.custid + "' and paymentline.date between '" + dateTimePicker1.Value.Date.ToString("yyyy-MM-dd 00:00") + "' and '" + dateTimePicker2.Value.Date.AddDays(1).AddSeconds(-1).ToString("yyyy-MM-dd HH:mm") + "' order by paymentid, date) t order by paymentid desc, date desc";
                MySqlCommand comm = new MySqlCommand(query, conn);
                MySqlDataAdapter adp = new MySqlDataAdapter(comm);
                DataSet3 ds = new DataSet3();
                ds.Clear();
                adp.Fill(ds);
  

                CrystalReport7 objRpt = new CrystalReport7();
                objRpt.SetDataSource(ds.Tables[1]);

                ParameterFieldDefinitions crParameterFieldDefinitions;
                ParameterFieldDefinition crParameterFieldDefinition;
                ParameterValues crParameterValues = new ParameterValues();
                ParameterDiscreteValue crParameterDiscreteValue = new ParameterDiscreteValue();

                crParameterDiscreteValue.Value = label3.Text;
                crParameterFieldDefinitions = objRpt.DataDefinition.ParameterFields;
                crParameterFieldDefinition = crParameterFieldDefinitions["Customername"];
                crParameterValues = crParameterFieldDefinition.CurrentValues;

                crParameterValues.Clear();
                crParameterValues.Add(crParameterDiscreteValue);
                crParameterFieldDefinition.ApplyCurrentValues(crParameterValues);

                crParameterDiscreteValue.Value = label4.Text;
                crParameterFieldDefinitions = objRpt.DataDefinition.ParameterFields;
                crParameterFieldDefinition = crParameterFieldDefinitions["address"];
                crParameterValues = crParameterFieldDefinition.CurrentValues;

                crParameterValues.Clear();
                crParameterValues.Add(crParameterDiscreteValue);
                crParameterFieldDefinition.ApplyCurrentValues(crParameterValues);

                crParameterDiscreteValue.Value = dateTimePicker1.Value.Date.ToString("yyyy-MM-dd 00:00");
                crParameterFieldDefinitions = objRpt.DataDefinition.ParameterFields;
                crParameterFieldDefinition = crParameterFieldDefinitions["fromDate"];
                crParameterValues = crParameterFieldDefinition.CurrentValues;

                crParameterValues.Clear();
                crParameterValues.Add(crParameterDiscreteValue);
                crParameterFieldDefinition.ApplyCurrentValues(crParameterValues);

                crParameterDiscreteValue.Value = dateTimePicker2.Value.Date.AddDays(1).AddSeconds(-1).ToString("yyyy-MM-dd HH:mm");
                crParameterFieldDefinitions = objRpt.DataDefinition.ParameterFields;
                crParameterFieldDefinition = crParameterFieldDefinitions["toDate"];
                crParameterValues = crParameterFieldDefinition.CurrentValues;

                crParameterValues.Clear();
                crParameterValues.Add(crParameterDiscreteValue);
                crParameterFieldDefinition.ApplyCurrentValues(crParameterValues);
                crystalReportViewer1.Visible = true;
                crystalReportViewer1.ReportSource = objRpt;
                crystalReportViewer1.Refresh();
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        bool apply = false;
        bool cancel = true;
        private void button2_Click(object sender, EventArgs e)
        {
            cancel = false;
            apply = true;
            string query = "select * from " +
                        "(SELECT orders.date,GROUP_CONCAT(Distinct CONCAT(ol.quantity, ' ', ol.productname)) AS 'Order', '' as Payments, p.paymentid, p.amount as 'Paid','', orders.total,p.remaining,'-' FROM orders, customer, payments p, orderline ol WHERE orders.customerid = '" + viewcustomer.custid + "' and orders.customerid = customer.customerid AND orders.orderid = p.orderid AND orders.orderid = ol.orderid and p.orderid = ol.orderid and orders.date between '" + dateTimePicker1.Value.Date.ToString("yyyy-MM-dd 00:00") + "' and '" + dateTimePicker2.Value.Date.AddDays(1).AddSeconds(-1).ToString("yyyy-MM-dd HH:mm") + "' GROUP BY orders.orderid " +
                        " UNION all " +
                        " SELECT '','', 'Payment', paymentid, payment,paymentline.date, '', '', paychange FROM paymentline where  customerid = '" + viewcustomer.custid + "' and paymentline.date between '" + dateTimePicker1.Value.Date.ToString("yyyy-MM-dd 00:00") + "' and '" + dateTimePicker2.Value.Date.AddDays(1).AddSeconds(-1).ToString("yyyy-MM-dd HH:mm") + "' order by paymentid, date) t order by paymentid desc, date desc";
            MySqlCommand comm = new MySqlCommand(query, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView1.DataSource = dt;
            dataGridView1.Columns["paymentid"].Visible = false;
            dataGridView1.Columns[1].HeaderText = "Order";
            dataGridView1.Columns[2].HeaderText = "Description";
            dataGridView1.Columns[5].HeaderText = "Payment Dates";
            dataGridView1.Columns[6].HeaderText = "Total";
            dataGridView1.Columns[7].HeaderText = "Balance";
            dataGridView1.Columns[8].HeaderText = "Change";

            loopgrid();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            cancel = true;
            apply = false;
            refreshdatabase();
        }
    }
}
