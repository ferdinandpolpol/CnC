﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace creams
{
    public partial class inventory : Form
    {
        MySqlConnection conn;
        bool lowstocks;
        public static string rawid;
        public static int quantity;

        public inventory()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;convert zero datetime=True");

        }



        /*private void button1_Click(object sender, EventArgs e)
        {
            //int prodid = getproductid();
            
        }*/

        private void inventory_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("Overall");
            comboBox1.Items.Add("By Batch");
            conn.Open();
            refreshgridview2();
            refreshdatabase_grid1_1();
            showexpired();
            if (hasexp)
            {
                MessageBox.Show("Products that will expire in less than 2 Weeks: \n" + string.Join(Environment.NewLine, expiring));
            }
            if (isexpired)
            {
                MessageBox.Show("Stockedout expired products: \n" + string.Join(Environment.NewLine, expired));
            }
            refreshdatabase_grid1();
            showlow();
            //refreshdatabase_grid2();
            if(haslow)
                MessageBox.Show("Current products below reorder point: \n" + string.Join(Environment.NewLine, lowproducts));
        }

        private void refreshdatabase_grid1()
        {

            string query = "SELECT si.saleid, si.productid, p.productname, p.productunit, SUM(si.quantity) as quantity, p.selling_price," +
                        "(select sum(quantity) from stockinline where productid=si.productid) as 'Stock-ins'," +
                        "(select sum(quantity) from stockout where productid = si.productid and reason = 'Sales') as 'Sales'," +
                        "(select sum(quantity) from stockout where productid = si.productid and reason = 'Production') as 'Production'," +
                        "(select sum(quantity) from stockout where productid = si.productid and reason = 'Damaged') as 'Damaged'," +
                        "(select sum(quantity) from stockout where productid = si.productid and reason = 'Expired') as 'Expired'" +
                        "FROM " +
                            "saleinventory si," +
                            "product p " +
                        "WHERE " +
                            "si.productid = p.productid " +
                        "GROUP BY p.productid " +
                        "ORDER BY p.productname DESC";
            MySqlCommand comm = new MySqlCommand(query, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView1.DataSource = dt;
            dataGridView1.Columns["saleid"].Visible = false;
            dataGridView1.Columns["productid"].Visible = false;
            dataGridView1.Columns["selling_price"].Visible = false;
            dataGridView1.Columns["productname"].HeaderText = "Product";
            dataGridView1.Columns["selling_price"].HeaderText = "Prices";
            dataGridView1.Columns["productunit"].HeaderText = "Unit";
            dataGridView1.Columns[4].HeaderText = "Current Quantity";

        }
        private void refreshdatabase_grid1_1()
        {
            if (dataGridView3.Columns.Contains("remainingdays"))
            {
                dataGridView3.Columns.Remove("remainingdays");
            }
            string query = "select p.productid,p.productname,p.productunit,p.selling_price,si.* from saleinventory si, product p where p.productid=si.productid and si.quantity > 0 order by productname, date";
            MySqlCommand comm = new MySqlCommand(query, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView3.DataSource = dt;
            dataGridView3.Columns["date"].Visible = false;
            dataGridView3.Columns["saleid"].Visible = false;
            dataGridView3.Columns["productid"].Visible = false;
            dataGridView3.Columns["productid1"].Visible = false;
            dataGridView3.Columns["productname"].HeaderText = "Product";
            dataGridView3.Columns["selling_price"].HeaderText = "Prices";
            dataGridView3.Columns["productunit"].HeaderText = "Unit";
            dataGridView3.Columns.Add("remainingdays", "Days Remaining");

            foreach(DataGridViewRow row in dataGridView3.Rows)
            {
                row.Cells["remainingdays"].Value = (Convert.ToDateTime(row.Cells["expiry"].Value) - DateTime.Now).Days.ToString();
            }

        }
        private void refreshgridview2()
        {
            //string query = "SELECT p.productid, p.productname, pi.unit,sum(pi.quantity)  FROM productioninventory pi, transfer t, product p where pi.transferid = t.transferid and t.productid = p.productid group by productid, unit";
            string query = "select productioninventoryid, transferid, pi.productname, sum(quantity), unit," +
                                "(select sum(quantity) from productionstockout where productname = pi.productname and unit = pi.unit and reason = 'Production') as 'Used'," +
                                "(select sum(quantity) from productionstockout where productname = pi.productname and unit = pi.unit and reason = 'Damaged') as 'Damaged'," +
                                "(select sum(quantity) from productionstockout where productname = pi.productname and unit = pi.unit and reason = 'Expired') as 'Expired' " + 
                                " from productioninventory pi where quantity > 0 group by productname, unit";
            MySqlCommand comm = new MySqlCommand(query, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView2.DataSource = dt;
            dataGridView2.Columns["productioninventoryid"].Visible = false;
            dataGridView2.Columns[1].Visible = false;
            dataGridView2.Columns[2].HeaderText = "Product";
            dataGridView2.Columns[3].HeaderText = "Quantity";

            //dataGridView1.Columns[""]
        }
        private void tabPage1_Click(object sender, EventArgs e)
        {
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }
        //Search button
        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            string query = "SELECT si.saleid, si.productid, p.productname, p.productunit, SUM(si.quantity) as quantity, p.selling_price," +
                        "(select sum(quantity) from stockinline where productid=si.productid) as 'Stock-ins'," +
                        "(select sum(quantity) from stockout where productid = si.productid and reason = 'Sales') as 'Sales'," +
                        "(select sum(quantity) from stockout where productid = si.productid and reason = 'Production') as 'Production'," +
                        "(select sum(quantity) from stockout where productid = si.productid and reason = 'Damaged') as 'Damaged'," +
                        "(select sum(quantity) from stockout where productid = si.productid and reason = 'Expired') as 'Expired'" +
                        "FROM " +
                            "saleinventory si," +
                            "product p " +
                        "WHERE " +
                            "si.productid = p.productid " +
                        "GROUP BY p.productid " +
                        "ORDER BY p.productname DESC";
            MySqlCommand comm = new MySqlCommand(query, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView1.DataSource = dt;
            dataGridView1.Columns["saleid"].Visible = false;
            dataGridView1.Columns["productid"].Visible = false;
            dataGridView1.Columns["selling_price"].Visible = false;
            dataGridView1.Columns["productname"].HeaderText = "Name of Product";
            dataGridView1.Columns["selling_price"].HeaderText = "Prices";
            dataGridView1.Columns["productunit"].HeaderText = "Unit";
            dataGridView1.Columns[4].HeaderText = "Current Quantity";

            if (dataGridView3.Columns.Contains("remainingdays"))
            {
                dataGridView3.Columns.Remove("remainingdays");
            }
            string query1 = "select p.productid,p.productname,p.productunit,p.selling_price,si.* from saleinventory si, product p where p.productid=si.productid and si.quantity > 0 and p.productname like '%" + textBox2.Text + "%'";
            MySqlCommand comm1 = new MySqlCommand(query1, conn);
            MySqlDataAdapter adp1 = new MySqlDataAdapter(comm1);
            DataTable dt1 = new DataTable();
            adp1.Fill(dt1);

            dataGridView3.DataSource = dt1;
            dataGridView3.Columns["date"].Visible = false;
            dataGridView3.Columns["saleid"].Visible = false;
            dataGridView3.Columns["productid"].Visible = false;
            dataGridView3.Columns["productid1"].Visible = false;
            dataGridView3.Columns["productname"].HeaderText = "Name of Product";
            dataGridView3.Columns["selling_price"].HeaderText = "Prices";
            dataGridView3.Columns["productunit"].HeaderText = "Unit";
            dataGridView3.Columns.Add("remainingdays", "Days Remaining");

            foreach (DataGridViewRow row in dataGridView3.Rows)
            {
                row.Cells["remainingdays"].Value = (Convert.ToDateTime(row.Cells["expiry"].Value) - DateTime.Now).Days.ToString();
            }
        }
        List<string> lowproducts = new List<string>();
        bool haslow = false;
        private void showlow()
        {
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                string q = "select reorderpoint from product where productid = '" + row.Cells["productid"].Value.ToString() + "'";
                MySqlCommand comm = new MySqlCommand(q, conn);
                int reorderpoint = Convert.ToInt32(comm.ExecuteScalar());

                if(Convert.ToInt32(row.Cells[4].Value) < reorderpoint)
                {
                    row.Cells[4].Style.BackColor = Color.LightCoral;
                    lowproducts.Add(row.Cells["productname"].Value.ToString() + ", "+ row.Cells[4].Value.ToString() + " left.");
                    haslow = true;
                }
            }
        }
        List<string> expiring = new List<string>();
        bool hasexp = false;

        List<string> expired = new List<string>();
        bool isexpired;
        private void showexpired()
        {
            foreach (DataGridViewRow row in dataGridView3.Rows)
            {
                DateTime expirydate = Convert.ToDateTime(row.Cells["expiry"].Value);
                string remaining = (expirydate - DateTime.Now).Days.ToString();
                if (Convert.ToInt32(remaining) < 15)
                {
                    row.Cells["quantity"].Style.BackColor = Color.LightCoral;
                    expiring.Add(row.Cells["productname"].Value.ToString() + ", " + remaining + " days left");
                    hasexp = true;
                }
                if(Convert.ToInt32(remaining) <= 0)
                {
                    string q = "insert into stockout(productid, quantity, reason) values('"+ row.Cells["productid"].Value.ToString() + "','"+ row.Cells["quantity"].Value.ToString() + "','Expired');" + 
                                "update saleinventory set quantity = 0 where saleid = '" + row.Cells["saleid"].Value.ToString() + "'";
                    MySqlCommand comm = new MySqlCommand(q, conn);
                    comm.ExecuteNonQuery();

                    expired.Add(row.Cells["productname"].Value.ToString());
                    isexpired = true;
                }
            }
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {
        }

        /*private void button5_Click(object sender, EventArgs e)
        {
            
            if(rawid == null)
            {
                MessageBox.Show("Please choose a product to repack.");
            }
            else
            {
                repack repack = new repack();
                repack.ShowDialog();
            }    
        }*/
        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }


        private void suppliercmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            stockin si = new stockin();
            si.ShowDialog();
            refreshdatabase_grid1();
            refreshdatabase_grid1_1();
            refreshgridview2();
            showlow();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            stockout so = new stockout();
            so.ShowDialog();
            refreshdatabase_grid1();
            refreshgridview2();
            refreshdatabase_grid1_1();
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
        }
        /*private void countobs() // Out by Sales counter
        {
            foreach(DataGridViewRow row in dataGridView1.Rows)
            {
                string productid = row.Cells["productid"].Value.ToString();
                string q1 = "select sum(quantity) from stockout where reason = 'Sales' and productid='" + productid + "'";
                MySqlCommand comm1 = new MySqlCommand(q1, conn);
                row.Cells["outbysales"].Value = comm1.ExecuteScalar().ToString();
            }
        }
        private void countsod() // Stockouts counter
        {
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                string productid = row.Cells["productid"].Value.ToString();
                string q1 = "select sum(quantity) from stockout where productid='" + productid + "' and reason = 'Damaged'";
                MySqlCommand comm1 = new MySqlCommand(q1, conn);
                row.Cells["outbystockoutd"].Value = comm1.ExecuteScalar().ToString();
            }
        }
        private void countsoe() // Stockouts counter
        {
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                string productid = row.Cells["productid"].Value.ToString();
                string q1 = "select sum(quantity) from stockout where productid='" + productid + "' and reason = 'Expired'";
                MySqlCommand comm1 = new MySqlCommand(q1, conn);
                row.Cells["outbystockoute"].Value = comm1.ExecuteScalar().ToString();
            }
        }
        private void countobp() // Production counter
        {
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                string productid = row.Cells["productid"].Value.ToString();
                string q1 = "select sum(quantity) from stockout where productid='" + productid + "' and reason = 'Production'";
                MySqlCommand comm1 = new MySqlCommand(q1, conn);
                row.Cells["outbyproduction"].Value = comm1.ExecuteScalar().ToString();
            }
        }
        private void counttrans() // Count transferred
        {
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                string productid = row.Cells["productid"].Value.ToString();
                string q1 = "select sum(quantity) from stockout where productid='" + productid + "' and reason = 'Production Transfer'";
                MySqlCommand comm1 = new MySqlCommand(q1, conn);
                row.Cells["transfer"].Value = comm1.ExecuteScalar().ToString();
            }
        }*/
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(comboBox1.Text == "Overall")
            {
                dataGridView1.Visible = true;
                dataGridView3.Visible = false;
                
            }
            else if(comboBox1.Text == "By Batch")
            {
                dataGridView1.Visible = false;
                dataGridView3.Visible = true;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            converttoproduction ctp = new converttoproduction();
            ctp.ShowDialog();
            refreshdatabase_grid1();
            refreshdatabase_grid1_1();
            refreshgridview2();
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            dataGridView1.ClearSelection();
        }

        private void dataGridView2_SelectionChanged(object sender, EventArgs e)
        {
            dataGridView2.ClearSelection();
        }

        private void dataGridView3_SelectionChanged(object sender, EventArgs e)
        {
            dataGridView3.ClearSelection();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            converttoproduction ctp = new converttoproduction();
            ctp.ShowDialog();
            refreshdatabase_grid1();
            refreshdatabase_grid1_1();
            refreshgridview2();
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            production_stockout ps = new production_stockout();
            ps.ShowDialog();
            refreshdatabase_grid1();
            refreshdatabase_grid1_1();
            refreshgridview2();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            purchasestocks ps = new purchasestocks();
            ps.ShowDialog();
            refreshdatabase_grid1();
            refreshdatabase_grid1_1();
            refreshgridview2();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            stockreturn sr = new stockreturn();
            sr.ShowDialog();
            refreshdatabase_grid1();
            refreshdatabase_grid1_1();
            refreshgridview2();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            inventoryreport ir = new inventoryreport();
            ir.ShowDialog();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            inventoryreport2 ir = new inventoryreport2();
            ir.ShowDialog();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Columns.Contains("outbysales") ||
                dataGridView1.Columns.Contains("outbystockoute") ||
                dataGridView1.Columns.Contains("outbystockoutd") ||
                dataGridView1.Columns.Contains("outbyproduction"))
            {
                dataGridView1.Columns.Remove("outbysales");
                dataGridView1.Columns.Remove("outbystockoute");
                dataGridView1.Columns.Remove("outbystockoutd");
                dataGridView1.Columns.Remove("outbyproduction");
            }

            string query = "SELECT si.saleid, si.productid, p.productname, p.productunit, SUM(si.quantity) as quantity, p.selling_price," +
                        "(select sum(quantity) from stockinline where productid=si.productid and date between '" + dateTimePicker1.Value.Date.ToString("yyyy-MM-dd 00:00") + "' and '" + dateTimePicker2.Value.Date.AddDays(1).AddSeconds(-1).ToString("yyyy-MM-dd HH:mm") + "') as 'stock-ins'," +
                        "(select sum(quantity) from stockout where productid = si.productid and reason = 'Sales' and date between '" + dateTimePicker1.Value.Date.ToString("yyyy-MM-dd 00:00") + "' and '" + dateTimePicker2.Value.Date.AddDays(1).AddSeconds(-1).ToString("yyyy-MM-dd HH:mm") + "') as 'sales'," +
                        "(select sum(quantity) from stockout where productid = si.productid and reason = 'Production' and date between '" + dateTimePicker1.Value.Date.ToString("yyyy-MM-dd 00:00") + "' and '" + dateTimePicker2.Value.Date.AddDays(1).AddSeconds(-1).ToString("yyyy-MM-dd HH:mm") + "') as 'production'," +
                        "(select sum(quantity) from stockout where productid = si.productid and reason = 'Damaged' and date between '" + dateTimePicker1.Value.Date.ToString("yyyy-MM-dd 00:00") + "' and '" + dateTimePicker2.Value.Date.AddDays(1).AddSeconds(-1).ToString("yyyy-MM-dd HH:mm") + "') as 'damaged'," +
                        "(select sum(quantity) from stockout where productid = si.productid and reason = 'Expired' and date between '" + dateTimePicker1.Value.Date.ToString("yyyy-MM-dd 00:00") + "' and '" + dateTimePicker2.Value.Date.AddDays(1).AddSeconds(-1).ToString("yyyy-MM-dd HH:mm") + "') as 'expired'" +
                        "FROM " +
                            "saleinventory si," +
                            "product p " +
                        "WHERE " +
                            "si.productid = p.productid " +
                        "GROUP BY p.productid " +
                        "ORDER BY p.productname DESC";
            MySqlCommand comm = new MySqlCommand(query, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView1.DataSource = dt;
            dataGridView1.Columns["saleid"].Visible = false;
            dataGridView1.Columns["productid"].Visible = false;
            dataGridView1.Columns["selling_price"].Visible = false;
            dataGridView1.Columns["productname"].HeaderText = "Product";
            dataGridView1.Columns["selling_price"].HeaderText = "Prices";
            dataGridView1.Columns["productunit"].HeaderText = "Unit";
            dataGridView1.Columns[4].HeaderText = "Current Quantity";
        }

        private void button11_Click(object sender, EventArgs e)
        {
            refreshdatabase_grid1();
            refreshdatabase_grid1_1();
            refreshgridview2();
        }
    }
}
