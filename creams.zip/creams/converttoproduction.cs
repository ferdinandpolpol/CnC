﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace creams
{
    public partial class converttoproduction : Form
    {
        MySqlConnection conn;
        public converttoproduction()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;convert zero datetime=True");
        }

        private void converttoproduction_Load(object sender, EventArgs e)
        {
            groupBox2.Enabled = false;
            textBox2.Enabled = false;
            conn.Open();
            refreshdatabase();
            comboBox1.Items.Add("Pieces");
            comboBox1.Items.Add("Cups");
            comboBox1.Items.Add("Tbsps");
            comboBox1.Items.Add("tsps");
            comboBox1.Items.Add("grams");
            comboBox1.Items.Add("ml");
        }
        private void refreshdatabase()
        {
            string query = "select si.saleid, si.productid, p.productname, p.productunit,sum(si.quantity), p.selling_price from saleinventory si, product p where si.productid=p.productid and si.quantity > 0 and p.producttype = 'Consumable' group by p.productid order by si.quantity desc ";
            MySqlCommand comm = new MySqlCommand(query, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView1.DataSource = dt;
            dataGridView1.Columns["saleid"].Visible = false;
            dataGridView1.Columns["selling_price"].Visible = false;
            dataGridView1.Columns["productid"].Visible = false;

            dataGridView1.Columns["productname"].HeaderText = "Product";
            dataGridView1.Columns["productunit"].HeaderText = "Unit";
            dataGridView1.Columns[4].HeaderText = "Quantity";
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox2.Enabled = true;
            textBox3.Text = dataGridView1["productname", dataGridView1.CurrentRow.Index].Value.ToString();
            string unit = textBox4.Text =  dataGridView1["productunit", dataGridView1.CurrentRow.Index].Value.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrWhiteSpace(textBox1.Text) ||
                string.IsNullOrWhiteSpace(comboBox1.Text) ||
                string.IsNullOrWhiteSpace(textBox2.Text))
            {
                MessageBox.Show("Empty field/s");
            }
            else
            {
                string saleid = dataGridView1["saleid", dataGridView1.CurrentRow.Index].Value.ToString();
                string pid = dataGridView1["productid", dataGridView1.CurrentRow.Index].Value.ToString();
                string product = dataGridView1["productname", dataGridView1.CurrentRow.Index].Value.ToString() +", "+ dataGridView1["productunit", dataGridView1.CurrentRow.Index].Value.ToString();
                dataGridView2.Rows.Add(saleid,pid, product, textBox2.Text, comboBox1.Text, textBox1.Text);
                dataGridView1[4, dataGridView1.CurrentRow.Index].Value = Convert.ToInt32(dataGridView1[4, dataGridView1.CurrentRow.Index].Value) - Convert.ToInt32(textBox2.Text); 
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            foreach(DataGridViewRow row1 in dataGridView2.Rows)
            {
                string pid = row1.Cells["productid"].Value.ToString();
                
                string grid2saleid = row1.Cells["saleid"].Value.ToString();
                string grid2product = row1.Cells[2].Value.ToString();
                string grid2unit = row1.Cells["unit"].Value.ToString();
                int grid2quantity = Convert.ToInt32(row1.Cells["salequantity"].Value);

                string q1 = "select saleid, quantity from saleinventory where quantity > 0 and productid = '" + pid + "';";
                MySqlCommand comm1 = new MySqlCommand(q1, conn);
                MySqlDataAdapter adp = new MySqlDataAdapter(comm1);
                DataTable dt = new DataTable();
                adp.Fill(dt);

                dataGridView3.DataSource = dt;
                foreach(DataGridViewRow row2 in dataGridView3.Rows)
                {
                    int grid3quantity = Convert.ToInt32(row2.Cells["quantity"].Value);
                    int quantityleft = grid2quantity - grid3quantity;
                    string grid3saleid = row2.Cells[0].Value.ToString();
                    /*
                     * if grid3 quantity >= grid2 quantity
                     *      update saleinventory set quantity - grid2 quantity
                     * else if grid3 quantity < grid2 quantitu
                     *      update saleinventory set quantity = 0
                     *      grid2.Row[quantity].Value = grid2 - grid3
                     *      grid2.Row.Add(saleid quantityleft)
                     * else
                     *      continue;
                     */
                    if(grid3quantity >= grid2quantity)
                    {
                        string q2 = "update saleinventory set quantity = quantity - '" + grid2quantity + "' where saleid = '" + grid3saleid + "'";
                        MySqlCommand comm2 = new MySqlCommand(q2, conn);
                        comm2.ExecuteNonQuery();
                        string q3 = "insert into stockout(productid, quantity, reason) values('"+pid+"','"+grid2quantity+"','Production')";
                        MySqlCommand comm3 = new MySqlCommand(q3, conn);
                        comm3.ExecuteNonQuery();
                        break;
                    }
                    else if(grid3quantity < grid2quantity)
                    {
                        string q2 = "update saleinventory set quantity = 0 where saleid = '" + grid3saleid + "'";
                        MySqlCommand comm2 = new MySqlCommand(q2, conn);
                        comm2.ExecuteNonQuery();
                        string q3 = "insert into stockout(productid, quantity, reason) values('" + pid + "','" + quantityleft + "','Production')";
                        MySqlCommand comm3 = new MySqlCommand(q3, conn);
                        comm3.ExecuteNonQuery();
                        dataGridView2.Rows.Add(grid2saleid, pid, grid2product, quantityleft, grid2unit, 0.ToString());
                    }
                    else
                    {
                        continue;
                    }
                }

            }
            foreach (DataGridViewRow row in dataGridView2.Rows)
            {
                string pid = row.Cells["productid"].Value.ToString();
                string pname = row.Cells["product"].Value.ToString();
                string[] res = pname.Split(',');
                string saleqty = row.Cells["salequantity"].Value.ToString();
                string qty = row.Cells["quantity"].Value.ToString();
                string unit = row.Cells["unit"].Value.ToString();
                string q1 = "set foreign_key_checks=0;insert into transfer(productid,productname, salequantity, converted_quantity, converted_unit) values('"+pid+"','" + res[0] + "','" + saleqty + "','" + qty + "','" + unit + "');" + 
                            "insert into productioninventory(transferid, productname, quantity, unit) values('"+gettransferid()+"','"+ res[0] + "','"+qty+"','"+unit+"')";
                MySqlCommand comm1 = new MySqlCommand(q1, conn);
                comm1.ExecuteNonQuery();
            }
            this.Close();
        }
        private int gettransferid()
        {
            string q = "select count(*) from transfer";
            MySqlCommand comm = new MySqlCommand(q, conn);
            return Convert.ToInt32(comm.ExecuteScalar());
        }
        private void converttoproduction_FormClosing(object sender, FormClosingEventArgs e)
        {
            conn.Close();
        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            try
            {
                int salequantity = Convert.ToInt32(dataGridView1[4, dataGridView1.CurrentRow.Index].Value);
                if (Convert.ToInt32(textBox2.Text) > salequantity)
                {
                    MessageBox.Show("Quantity exceeds current sale quantity");
                    textBox2.Clear();
                }
                groupBox2.Enabled = true;
            }
            catch(Exception er)
            {

            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string pid = dataGridView1[1, dataGridView1.CurrentRow.Index].Value.ToString();
            if(comboBox1.Text == "Cups")
            {
                string q = "select cups * '" + textBox2.Text + "' from productconversion where productid = '" + pid + "'";
                MySqlCommand comm = new MySqlCommand(q, conn);
                textBox1.Text = comm.ExecuteScalar().ToString();
            }
            else if (comboBox1.Text == "Tbsps")
            {
                string q = "select tbsps * '" + textBox2.Text + "' from productconversion where productid = '" + pid + "'";
                MySqlCommand comm = new MySqlCommand(q, conn);
                textBox1.Text = comm.ExecuteScalar().ToString();
            }
            else if (comboBox1.Text == "Tsps")
            {
                string q = "select tsps * '" + textBox2.Text + "' from productconversion where productid = '" + pid + "'";
                MySqlCommand comm = new MySqlCommand(q, conn);
                textBox1.Text = comm.ExecuteScalar().ToString();
            }
            else if (comboBox1.Text == "grams")
            {
                string q = "select grams * '" + textBox2.Text + "' from productconversion where productid = '" + pid + "'";
                MySqlCommand comm = new MySqlCommand(q, conn);
                textBox1.Text = comm.ExecuteScalar().ToString();
            }
            else if (comboBox1.Text == "ml")
            {
                string q = "select ml * '" + textBox2.Text + "' from productconversion where productid = '" + pid + "'";
                MySqlCommand comm = new MySqlCommand(q, conn);
                textBox1.Text = comm.ExecuteScalar().ToString();
            }
            else if (comboBox1.Text == "Pieces")
            {
                string q = "select pieces * '" + textBox2.Text + "' from productconversion where productid = '" + pid + "'";
                MySqlCommand comm = new MySqlCommand(q, conn);
                textBox1.Text = comm.ExecuteScalar().ToString();
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            groupBox2.Enabled = true;
            if (string.IsNullOrWhiteSpace(textBox2.Text))
            {
                groupBox2.Enabled = false;
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void textBox1_Click(object sender, EventArgs e)
        {
            textBox1.Enabled = true;
        }

        private void textBox1_MouseDown(object sender, MouseEventArgs e)
        {
            textBox1.Enabled = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
