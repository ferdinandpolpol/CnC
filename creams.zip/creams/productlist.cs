﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace creams
{
    public partial class productlist : Form
    {
        MySqlConnection conn;
        public productlist()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;");
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            loadingredients();
        }
        private void loadfoodlist()
        {
            string q1 = "select productid, productname, productdesc, productunit, selling_price from product where producttype = 'Food'";
            MySqlCommand comm1 = new MySqlCommand(q1, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm1);
            DataTable dt = new DataTable();

            adp.Fill(dt);

            dataGridView1.DataSource = dt;
            dataGridView1.Columns["productid"].Visible = false;
        }
        private void loadingredients()
        {
            string prod = dataGridView1["productid", dataGridView1.CurrentRow.Index].Value.ToString();
            string q1 = "select i.quantity, i.unit, i.productname from ingredients i where i.foodid = '"+prod+"'";
            MySqlCommand comm1 = new MySqlCommand(q1, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm1);
            DataTable dt = new DataTable();

            adp.Fill(dt);

            dataGridView2.DataSource = dt;
            //dataGridView2.Columns["productid"].Visible = false;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string q1 = "select productid, productname, productunit from product where producttype = 'Food' and productname like '"+textBox1.Text+"%'";
            MySqlCommand comm1 = new MySqlCommand(q1, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm1);
            DataTable dt = new DataTable();

            adp.Fill(dt);

            dataGridView1.DataSource = dt;
            dataGridView1.Columns["productid"].Visible = false;
            dataGridView1.Columns["productname"].HeaderText = "Product";
            dataGridView1.Columns["productunit"].HeaderText = "Unit";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string productid = dataGridView1[0, dataGridView1.CurrentRow.Index].Value.ToString();
            if (productid == null)
            {
                MessageBox.Show("Please select a product");
            }
            else
            {
                string prodid = "select productid from orderline where orderid='" + neworder.orderid + "' and productid='" + productid + "'";
                MySqlCommand check = new MySqlCommand(prodid, conn);
                MySqlDataAdapter adp = new MySqlDataAdapter(check);
                DataTable dt = new DataTable();
                adp.Fill(dt);

                //0 quantity checker
                string qty = "select quantity from saleinventory where productid='" + productid + "'";
                MySqlCommand checkqty = new MySqlCommand(qty, conn);
                checkqty.ExecuteNonQuery();
                Int32 quantity = Convert.ToInt32(checkqty.ExecuteScalar());

                if (dt.Rows.Count > 0)
                {
                    MessageBox.Show("Product already added to order!");

                }
                else
                {
                    string productname = dataGridView1[1, dataGridView1.CurrentRow.Index].Value.ToString();
                    string selling_price = dataGridView1["selling_price", dataGridView1.CurrentRow.Index].Value.ToString();

                    string query = "set foreign_key_checks=0;insert into orderline(orderid, saleid, productid, productname, selling_price, subtotal) values('"
                        + neworder.orderid + "','0','" + productid + "','" + productname + "','" + selling_price + "','" + selling_price + "')";
                    MySqlCommand comm = new MySqlCommand(query, conn);
                    comm.ExecuteNonQuery();

                    conn.Close();
                    this.Close();
                }
            }
        }

        private void productlist_Load(object sender, EventArgs e)
        {
            conn.Open();
            loadfoodlist();

        }

        private void productlist_FormClosing(object sender, FormClosingEventArgs e)
        {
            conn.Close();
        }

        private void dataGridView2_SelectionChanged(object sender, EventArgs e)
        {
            dataGridView2.ClearSelection();
        }
    }
}
