﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace creams
{
    public partial class dashboard : Form
    {
        public MySqlConnection conn;

        public dashboard()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Shows new form window 'viewuser'
            viewuser view = new viewuser();
            view.ShowDialog();
        }

        private void logoutbtn_Click(object sender, EventArgs e)
        {
            loginform login = new loginform();
            login.Show();
            this.Close();
        }

        private void addproductbtn_Click(object sender, EventArgs e)
        {
            newproduct newprod = new newproduct();
            newprod.ShowDialog();
        }

        private void viewproductbtn_Click(object sender, EventArgs e)
        {
            viewproduct viewprod = new viewproduct();
            viewprod.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            newcustomer newcust = new newcustomer();
            newcust.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            viewcustomer viewcust = new viewcustomer();
            viewcust.ShowDialog();
        }

        private void neworderbtn_Click(object sender, EventArgs e)
        {
            
        }

        private void home_neworderbtn_Click(object sender, EventArgs e)
        {
            conn.Open();
            string q = "set foreign_key_checks=0;insert into orders values('" + getorderid() + "','0','" + getstaffid() + "','0',now(),'0','Sale')";
            MySqlCommand comm = new MySqlCommand(q, conn);
            comm.ExecuteNonQuery();
            conn.Close();
            neworder neword = new creams.neworder();
            neword.ShowDialog();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void dashboard_Load(object sender, EventArgs e)
        {
        }

        private bool checkadmin()
        {
            conn.Open();
            //checks user privilege
            string query = "select stafftype from staff where username like '" + loginform.currentuser + "'";
            MySqlCommand comm = new MySqlCommand(query, conn);

            string privilege = Convert.ToString(comm.ExecuteScalar());
            conn.Close();
            if (privilege == "Admin")
                return true;
            else
                return false;
        }

        private string getorderid()
        {
            MySqlCommand comm = new MySqlCommand("select count(*) from orders", conn);
            Int32 norows = Convert.ToInt32(comm.ExecuteScalar());
            norows += 1;
            return norows.ToString();
        }
        private string getstaffid()
        {
            //checks user privilege
            string query = "select staffid from staff where username like '" + loginform.currentuser + "'";
            MySqlCommand comm = new MySqlCommand(query, conn);

            string id = Convert.ToString(comm.ExecuteScalar());
            return id;
        }
        private string getreturnid()
        {
            MySqlCommand comm = new MySqlCommand("SELECT count(*) FROM creamsncrumbs.`return`;", conn);
            Int32 norows = Convert.ToInt32(comm.ExecuteScalar());
            norows += 1;
            return norows.ToString();
        }

        private void inventorybtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            inventory inv = new inventory();
            inv.ShowDialog();
            this.Show();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            records rec = new records();
            rec.ShowDialog();
            this.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //delivery deliver = new delivery();
            //deliver.ShowDialog();
        }

        private void vieworderbtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            salesreport order = new salesreport();
            order.ShowDialog();
            this.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            
        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            viewsupplier supplier = new viewsupplier();
            supplier.ShowDialog();
            this.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            
        }

        private void viewreturnbtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            returns ret = new returns();
            ret.ShowDialog();
            this.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            productionlist pl = new productionlist();
            pl.ShowDialog();
            this.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(0);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(1);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(2);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(3);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            loginform login = new loginform();
            login.Show();
            this.Close();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            this.Hide();
            purchaselist pl = new creams.purchaselist();
            pl.ShowDialog();
            this.Show();
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }
    }
}
