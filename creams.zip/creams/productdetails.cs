﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace creams
{
    public partial class productdetails : Form
    {
        MySqlConnection conn;
        public productdetails()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;");
        }

        private void productdetails_Load(object sender, EventArgs e)
        {
            dataGridView2.Visible = false;
            enabletext();
            label10.Text = viewproduct.productid;
            filltypecmb();
            fillproductinfo();
            if (comboBox1.Text == "Food")
            {
                this.Size = new Size(928,625);
                textBox4.Enabled = false;
                textBox6.Enabled = false;
            }
            else
            {
                if(comboBox1.Text == "Consumable")
                {
                    dataGridView2.Visible = true;
                    loadconversion();
                }
                else
                {
                    dataGridView2.Visible = false;
                }
                comboBox3.Enabled = false;
                textBox7.Enabled = false;
                dataGridView1.Enabled = false;
                button3.Enabled = false;
                button4.Enabled = false;
            }
            fillproducts();
            loadingredients();
            
            conn.Open();

        }
        private void loadingredients()
        {
            string q = "select i.ingredientid,i.foodid, i.productname, i.quantity, i.unit from ingredients i where foodid = '"+label10.Text+"'";
            MySqlCommand comm1 = new MySqlCommand(q, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm1);
            DataTable dt = new DataTable();

            adp.Fill(dt);

            dataGridView1.DataSource = dt;
            dataGridView1.Columns["foodid"].Visible = false;
            dataGridView1.Columns["ingredientid"].Visible = false;
            //dataGridView1.Columns["productid"].Visible = false;
        }
        private void loadconversion()
        {
            conn.Open();
            string q = "select pieces,cups,tbsps,tsps,grams,ml from productconversion where productid = '"+label10.Text+"'";
            MySqlCommand cmdDataBase = new MySqlCommand(q, conn);
            MySqlDataReader myReader;

            //reads every row in product table
            myReader = cmdDataBase.ExecuteReader();

            while (myReader.Read())
            {
                string pieces = myReader.GetString("pieces");
                string cups = myReader.GetString("cups");
                string tbsps = myReader.GetString("tbsps");
                string tsps = myReader.GetString("tsps");
                string grams = myReader.GetString("grams");
                string ml = myReader.GetString("ml");
                dataGridView2.Rows.Add(pieces,cups,tbsps,tsps,grams,ml);
            }
            conn.Close();
        }
        private void fillproducts()
        {
            conn.Open();
            string q = "select pi.* from productioninventory pi group by productname, unit";
            MySqlCommand cmdDataBase = new MySqlCommand(q, conn);
            MySqlDataReader myReader;

            //reads every row in product table
            myReader = cmdDataBase.ExecuteReader();


            while (myReader.Read())
            {
                string pname = myReader.GetString("productname");
                string unit = myReader.GetString("unit");
                comboBox3.Items.Add(pname + "," + unit);
            }
            conn.Close();
        }
        public void filltypecmb()
        {
                comboBox1.Items.Add("Consumable");
                comboBox1.Items.Add("Non-Consumable");
                comboBox1.Items.Add("Food");
                conn.Close();
        }
        public void fillunits()
        {
            if (comboBox1.Text == "Consumable")
            {
                comboBox2.Items.Add("Pack");
                comboBox2.Items.Add("100 grams");
                comboBox2.Items.Add("200 grams");
                comboBox2.Items.Add("300 grams");
                comboBox2.Items.Add("400 grams");
                comboBox2.Items.Add("500 grams");
                comboBox2.Items.Add("1 Kg");
                comboBox2.Items.Add("2 Kg");
                comboBox2.Items.Add("3 Kg");
                comboBox2.Items.Add("4 Kg");
            }
            else if (comboBox1.Text == "Non-Consumable")
            {
                comboBox2.Items.Add("Very Small");
                comboBox2.Items.Add("Small");
                comboBox2.Items.Add("Medium");
                comboBox2.Items.Add("Large");
                comboBox2.Items.Add("Very Large");
            }
            else if (comboBox1.Text == "Food")
            {
                comboBox2.Items.Add("Small");
                comboBox2.Items.Add("Medium");
                comboBox2.Items.Add("Large");
            }
        }

        private void fillproductinfo()
        {
            conn.Open();
            try
            {
                string q = "select * from product where productid = " + Convert.ToInt32(label10.Text);
                MySqlCommand cmdDataBase = new MySqlCommand(q, conn);
                MySqlDataReader myReader;

                myReader = cmdDataBase.ExecuteReader();

                while (myReader.Read())
                {
                    textBox2.Text = myReader.GetString("productname");
                    textBox3.Text = myReader.GetString("productdesc");
                    textBox4.Text = myReader.GetString("purchase_price");
                    textBox5.Text = myReader.GetString("selling_price");
                    
                    textBox6.Text = myReader.GetString("reorderpoint");
                    comboBox1.Text = myReader.GetString("producttype");
                    comboBox2.Text = myReader.GetString("productunit");
                }
                
            }
            catch(Exception er)
            {
                MessageBox.Show("Please choose a product");
            }
            conn.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(comboBox1.Text == "Food")
            {
                string q = "update product set productname='" + textBox2.Text + "',selling_price='" + textBox5.Text + "',purchase_price='" + textBox4.Text + "',producttype='"
                        + comboBox1.Text + "',productdesc='" + textBox3.Text + "',productunit='" + comboBox2.Text + "', reorderpoint = '" + textBox6.Text + "' where productid='" + label10.Text + "';";
                       
                MySqlCommand comm = new MySqlCommand(q, conn);
                comm.ExecuteNonQuery();
                // Informs the user for succesful update
                MessageBox.Show("Successfully updated product " + textBox2.Text + "!");
            }
            else if(comboBox1.Text == "Consumable")
            {
                string pieces = dataGridView2[0, 0].Value.ToString();
                string cups = dataGridView2[1, 0].Value.ToString();
                string tbsps = dataGridView2[2, 0].Value.ToString();
                string tsps = dataGridView2[3, 0].Value.ToString();
                string grams = dataGridView2[4, 0].Value.ToString();
                string ml = dataGridView2[5, 0].Value.ToString();
                string q = "update product set productname='" + textBox2.Text + "',selling_price='" + textBox5.Text + "',purchase_price='" + textBox4.Text + "',producttype='"
                            + comboBox1.Text + "',productdesc='" + textBox3.Text + "',productunit='" + comboBox2.Text + "', reorderpoint = '"+textBox6.Text+"' where productid='" + label10.Text + "';" +
                            "update productconversion set pieces = '"+pieces+"', cups = '"+cups+"', tbsps = '"+tbsps+"', tsps = '"+tsps+"', grams = '"+grams+"', ml = '"+ml+"'";
                MySqlCommand comm = new MySqlCommand(q, conn);
                comm.ExecuteNonQuery();
                // Informs the user for succesful update
                MessageBox.Show("Successfully updated product " + textBox2.Text + "!");
            }
            else
            {
                string q = "update product set productname='" + textBox2.Text + "',selling_price='" + textBox5.Text + "',purchase_price='" + textBox4.Text + "',producttype='"
                            + comboBox1.Text + "',productdesc='" + textBox3.Text + "',productunit='" + comboBox2.Text + "', reorderpoint = '" + textBox6.Text + "' where productid='" + label10.Text + "';";
                MySqlCommand comm = new MySqlCommand(q, conn);
                comm.ExecuteNonQuery();
                // Informs the user for succesful update
                MessageBox.Show("Successfully updated product " + textBox2.Text + "!");
            }
            
        }

        private void productdetails_FormClosing(object sender, FormClosingEventArgs e)
        {
            conn.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            enabletext();
            button2.Visible = true;
            button1.Visible = true;
        }

        private void enabletext()
        {
            comboBox2.Enabled = true;
            textBox2.Enabled = true;
            textBox3.Enabled = true;
            textBox4.Enabled = true;
            textBox5.Enabled = true;
            textBox6.Enabled = true;
            comboBox1.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            string temp = comboBox3.Text;
            string[] result = temp.Split(',');

            if (string.IsNullOrWhiteSpace(comboBox3.Text) ||
                string.IsNullOrWhiteSpace(textBox7.Text))
            {
                MessageBox.Show("Empty Field/s");
            }
            else
            {
                string q = "insert into ingredients(foodid, productname, quantity, unit) values('"+label10.Text+"','"+result[0]+"','"+textBox7.Text+"','"+result[1]+"')";
                MySqlCommand comm = new MySqlCommand(q, conn);
                comm.ExecuteNonQuery();
                loadingredients();
            }
        }
        bool gridpressed = false;
        private void button4_Click(object sender, EventArgs e)
        {
            if (gridpressed == false)
            {

            }
            else
            {
                string ingid = dataGridView1["ingredientid", dataGridView1.CurrentRow.Index].Value.ToString();
                string q = "SET SQL_SAFE_UPDATES = 0;delete from ingredients where ingredientid='" + ingid + "';SET SQL_SAFE_UPDATES = 1;";
                MySqlCommand comm = new MySqlCommand(q, conn);
                comm.ExecuteNonQuery();
                loadingredients();
            }
            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox2.Items.Clear();
            fillunits();
        }

        private void textBox7_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void textBox6_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back && e.KeyChar != '.')
            {
                e.Handled = true;
            }
        }

        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back && e.KeyChar != '.')
            {
                e.Handled = true;
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
           
        }
        
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            gridpressed = true;
        }
    }
}
