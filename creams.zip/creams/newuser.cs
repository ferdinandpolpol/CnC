﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace creams
{
    public partial class newuser : Form
    {
        public MySqlConnection conn;
        public newuser()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;");
        }

        private void cancelbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void submitbtn_Click(object sender, EventArgs e)
        {
            //Checks what radio button is picked
            string type = "";
            if (adminradio.Checked)
            {
                type = adminradio.Text; //returns Admin
            }
            else if (staffradio.Checked)
            {
                type = staffradio.Text; //returns Staff
            }
            conn.Open();
            //Selects all username in the database
            string checkuser = "select * from staff where username='" + usertxtbox.Text +"'";
            MySqlCommand check = new MySqlCommand(checkuser, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(check);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            //Verifies that all fields are populated
            if (string.IsNullOrWhiteSpace(fnametxtbox.Text) ||
                string.IsNullOrWhiteSpace(lnametxtbox.Text) ||
                string.IsNullOrWhiteSpace(usertxtbox.Text) ||
                string.IsNullOrWhiteSpace(passtxtbox.Text) ||
                type == null)
            {
                //Shows error message
                MessageBox.Show("Error: One of the fields are empty");
            }
            else if (dt.Rows.Count > 0)
            {
                
                //Checks if username is already existing
                MessageBox.Show("Username already exists!");
                usertxtbox.Clear();
            }
            // If user does not exist, it will proceed to adding a user
            else
            {
                //If all conditions satisfied, this will add the user
                // String for inserting the values into the staff table
                string q = "insert into staff(firstname, lastname, username, password, stafftype) values('" +
                fnametxtbox.Text+"','"+lnametxtbox.Text + "','"+usertxtbox.Text + "','"+passtxtbox.Text + "','"+type+"')";
                MySqlCommand comm = new MySqlCommand(q, conn);
                comm.ExecuteNonQuery();

                MessageBox.Show("Successfully added user " + fnametxtbox.Text + ", " + lnametxtbox.Text + "!");
                this.Close();
            }
            conn.Close();
        }

        private void adminradio_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void newuser_Load(object sender, EventArgs e)
        {

        }
    }
}
