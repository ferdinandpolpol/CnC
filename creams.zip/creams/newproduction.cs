﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace creams
{
    public partial class newproduction : Form
    {
        MySqlConnection conn;
        public static bool active;
        public newproduction()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;");
        }

        private void newproduction_Load(object sender, EventArgs e)
        {
            conn.Open();
            orderidtext.Text = productionlist.orderid;
            textBox3.Text = productionlist.deliveryid;
            label9.Text = productionlist.productionid.ToString();
            loadorder();
            //loaddetails();
            refreshdatabase();
            insufficient();
            conn.Close();
            conn.Open();
        }
        private void loadorder()
        {
            string q = "select orderline.productid,product.productname, orderline.quantity from orderline, orders, product where orderline.productid=product.productid and orderline.orderid=orders.orderid and orders.orderid='" + orderidtext.Text + "'";
            MySqlCommand comm = new MySqlCommand(q, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView2.DataSource = dt;
            dataGridView2.Columns["productid"].Visible = false;
            dataGridView2.Columns["productname"].HeaderText = "Product";
            dataGridView2.Columns["quantity"].HeaderText = "Quantity";
        }
        private void loaddetails()
        {
        }


        bool submittedorder;
        private void button3_Click(object sender, EventArgs e)
        {
            conn.Close();
            conn.Open();
            if(hasinsufficient == true)
            {
                MessageBox.Show("Insufficient production materials");
            }
            else
            {
                string query = "insert into production values('" + label9.Text + "','" + orderidtext.Text + "','" + textBox3.Text + "', now())";
                MySqlCommand comm = new MySqlCommand(query, conn);
                comm.ExecuteNonQuery();


                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    //string pid = row.Cells["productid"].Value.ToString();
                    string pn = row.Cells["productname"].Value.ToString();
                    string punit = row.Cells["unit"].Value.ToString();

                    string q = "select * from productioninventory pi where pi.productname = '" + pn + "' and unit = '"+punit+"' and quantity > 0";
                    MySqlCommand comm1 = new MySqlCommand(q, conn);
                    MySqlDataAdapter adp = new MySqlDataAdapter(comm1);
                    DataTable dt = new DataTable();
                    adp.Fill(dt);
                    dataGridView3.DataSource = dt;
                    string quantity = row.Cells["quantity"].Value.ToString();
                    foreach (DataGridViewRow row2 in dataGridView3.Rows)
                    {
                        if (Convert.ToInt32(row2.Cells["quantity"].Value) > 0)
                        {
                            string piid = row2.Cells["productioninventoryid"].Value.ToString();
                            if (Convert.ToInt32(row2.Cells["quantity"].Value) >= Convert.ToInt32(row.Cells["quantity"].Value))
                            {
                                string q1 = "update productioninventory set productioninventory.quantity = productioninventory.quantity - '" + quantity + "' where productioninventory.productioninventoryid = '" + piid + "';" +
                                     "insert into productionstockout(productioninventoryid, quantity, reason, date, productname, unit) values('" + piid + "','" + row.Cells["quantity"].Value.ToString() + "','Production',now(), '" + pn + "', '"+punit+"');" +
                                     "insert into productionline(productioninventoryid, productionid, quantity) values('" + piid + "','"+label9.Text+"','" + row.Cells["quantity"].Value.ToString() + "')" ;
                                MySqlCommand com1 = new MySqlCommand(q1, conn);
                                com1.ExecuteNonQuery();
                                break;
                            }
                            else if (Convert.ToInt32(row2.Cells["quantity"].Value) < Convert.ToInt32(row.Cells["quantity"].Value))
                            {
                                string productionquantity = row2.Cells["quantity"].Value.ToString();
                                string olquantity = row.Cells["quantity"].Value.ToString();
                                string quantityleft = (Convert.ToInt32(olquantity) - Convert.ToInt32(productionquantity)).ToString();


                                row.Cells["quantity"].Value = Convert.ToInt32(row.Cells["quantity"].Value) - Convert.ToInt32(quantityleft);
                                string q1 = "update productioninventory set productioninventory.quantity = 0 where productioninventory.productioninventoryid = '" + piid + "';" +
                                     "insert into productionstockout(productioninventoryid, quantity, reason, date, productname, unit) values('" + piid + "','" + row.Cells["quantity"].Value.ToString() + "','Production',now(), '" + pn + "','"+punit+"');" +
                                     "insert into productionline(productioninventoryid, productionid, quantity) values('" + piid + "','" + label9.Text + "','" + row.Cells["quantity"].Value.ToString() + "')";
                                MySqlCommand com1 = new MySqlCommand(q1, conn);
                                com1.ExecuteNonQuery();
                                dataGridView1.Rows.Add(row.Cells["foodid"].Value.ToString(), row.Cells["productname"].Value.ToString(), quantityleft, row.Cells["unit"].Value.ToString());
                                break;
                            }
                        }
                        else
                        {
                            continue;
                        }
                    }
                }

                string del = "update delivery set productionstatus='Finished' where deliveryid='" + textBox3.Text + "'";
                MySqlCommand exec = new MySqlCommand(del, conn);
                exec.ExecuteNonQuery();
                MessageBox.Show("Succesfully created order!");
                submittedorder = true;
                this.Close();
            }
            
        }

        private void newproduction_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (submittedorder == true)
            {

            }
            else
            {
                DialogResult dr = MessageBox.Show(@"Do you really want to close the form?",
                                               Application.ProductName,
                                               MessageBoxButtons.YesNo);
                if (dr == DialogResult.Yes && submittedorder == false)
                {
                    string type = "delete from production where productionid='" + label9.Text + "'";
                    MySqlCommand commtype = new MySqlCommand(type, conn);
                    commtype.ExecuteNonQuery();
                }
                else if (dr == DialogResult.No)
                {
                    e.Cancel = true;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            active = true;
            inventorylist inv = new inventorylist();
            inv.ShowDialog();
            refreshdatabase();
        }

        private void refreshdatabase()
        {
            foreach(DataGridViewRow row in dataGridView2.Rows)
            {
                conn.Close();
                conn.Open();
                string q = "select foodid, ingredients.productname, (quantity * "+Convert.ToInt32(row.Cells["quantity"].Value)+"), ingredients.unit from ingredients where foodid = '" + row.Cells["productid"].Value.ToString() + "'";
                MySqlCommand cmdDataBase = new MySqlCommand(q, conn);
                MySqlDataReader myReader;

                //reads every row in product table
                myReader = cmdDataBase.ExecuteReader();
                while (myReader.Read())
                {
                    string foodid = myReader.GetString("foodid");
                    //string productid = myReader.GetString("productid");
                    string productname = myReader.GetString("productname");
                    string quantity = myReader.GetString(2);
                    string unit = myReader.GetString("unit");

                    dataGridView1.Rows.Add(foodid, productname, quantity, unit);
                }
                conn.Close();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            refreshdatabase();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private string gettotal()
        {
            string query = "select sum(subtotal) from productioninventory where productionid=" + label9.Text + ";";
            MySqlCommand comm = new MySqlCommand(query, conn);

            string total = comm.ExecuteScalar().ToString();
            if (string.IsNullOrEmpty(total))
            {
                return 0.ToString();
            }
            else
            {
                return total;
            }
        }

        private void totalresult_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView4_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        bool hasinsufficient;
        private void insufficient()
        {
            foreach(DataGridViewRow row in dataGridView1.Rows)
            {
                conn.Close();
                conn.Open();
                int qty = 0;
                string q = "select sum(quantity) from productioninventory where productname = '" + row.Cells["productname"].Value.ToString() + "' and unit='"+ row.Cells["unit"].Value.ToString() + "'";
                MySqlCommand com = new MySqlCommand(q, conn);
                if(com.ExecuteScalar() is DBNull)
                {
                    continue;
                }
                else
                {
                    qty = Convert.ToInt32(com.ExecuteScalar());
                }
                
                if(Convert.ToInt32(row.Cells[2].Value) > qty)
                {
                    row.DefaultCellStyle.BackColor = Color.IndianRed;
                    hasinsufficient = true;
                    label3.Visible = true;
                }
                conn.Close();
            }
        }
    }
}
