﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace creams
{
    public partial class newproduct : Form
    {
        public MySqlConnection conn;
        public newproduct()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;");
        }

        private void cancelbtn_Click(object sender, EventArgs e)
        {
            //Close newproduct form
            this.Close();
        }

        private void submitbtn_Click(object sender, EventArgs e)
        {
            conn.Open();
            //Selects all product name and unit
            string checkuser = "select * from product where productname='" + prodnametxtbox.Text + "' and productunit='"+comboBox2.Text+"'";
            MySqlCommand check = new MySqlCommand(checkuser, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(check);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            //Verifies that all fields are populated
            if (string.IsNullOrWhiteSpace(prodnametxtbox.Text) ||
                    string.IsNullOrWhiteSpace(pricetxtbox.Text) ||
                    string.IsNullOrWhiteSpace(textBox1.Text) ||
                    string.IsNullOrWhiteSpace(textBox2.Text) ||
                    string.IsNullOrWhiteSpace(comboBox2.Text))
            {
                //Shows error message
                MessageBox.Show("Empty field/s");
            }
            //Checks if product with unit is already existing
            else if (dt.Rows.Count > 0)
            {
                MessageBox.Show("Product Already Exists!");
            }
            else if(Convert.ToDouble(textBox1.Text) > Convert.ToDouble(pricetxtbox.Text))
            {
                MessageBox.Show("Selling price must be greater than purchased price");
            }
            // If product does not exist, it will proceed to adding a product
            else
            {
                //If all conditions satisfied, this will add the user
                // String for inserting the values into the product table
                string q = "insert into product(productname, selling_price, purchase_price, productdesc, productunit, producttype, reorderpoint) values('" +
                    prodnametxtbox.Text + "','" + pricetxtbox.Text + "','" + textBox1.Text + "','" + desctxtbox.Text + "','" + comboBox2.Text + "','" + comboBox1.Text + "', '"+ textBox2.Text + "')";
                MySqlCommand comm = new MySqlCommand(q, conn);
                comm.ExecuteNonQuery();

                MessageBox.Show("Successfully added " + prodnametxtbox.Text + "!");

                //Inserts product into saleinventory if product is not a food
                if(comboBox1.Text == "Consumable" || comboBox1.Text == "Non-Consumable")
                {
                    string query1 = "set foreign_key_checks=0;insert into saleinventory(productid, quantity, expiry, purchaseid,stockinlineid) values (" + getproductcount() + ",0,now(),0,0)";
                    MySqlCommand comm1 = new MySqlCommand(query1, conn);
                    comm1.ExecuteNonQuery();

                    if (comboBox1.Text == "Consumable")
                    {
                        string test = "select * from productioninventory where productname = '" + prodnametxtbox.Text + "'";
                        MySqlCommand comm2 = new MySqlCommand(test, conn);
                        MySqlDataAdapter adp2 = new MySqlDataAdapter(comm2);
                        DataTable dt2 = new DataTable();

                        if (dt2.Rows.Count > 0)
                        {
                            
                        }
                        else
                        {
                            foreach (var items in comboBox4.Items)
                            {
                                if (string.IsNullOrWhiteSpace(items.ToString()))
                                {
                                    continue;
                                }
                                    string q1 = "set foreign_key_checks=0; insert into productioninventory(transferid, productname, quantity, unit) values('0', '" + prodnametxtbox.Text + "', 0, '" + items.ToString() + "');";
                                MySqlCommand com = new MySqlCommand(q1, conn);
                                com.ExecuteNonQuery();
                            }
                        }
                        
                        string pieces = dataGridView2[0, 0].Value.ToString();
                        string cups = dataGridView2[1, 0].Value.ToString();
                        string tbsps = dataGridView2[2, 0].Value.ToString();
                        string tsps = dataGridView2[3, 0].Value.ToString();
                        string grams = dataGridView2[4, 0].Value.ToString();
                        string ml = dataGridView2[5, 0].Value.ToString();
                        string ins = "set foreign_key_checks=0;INSERT INTO productconversion values('" + getprodid() + "','" + pieces + "','" + cups + "','" + dataGridView2["tbsps", 0].Value.ToString() + "','" + dataGridView2["tsps", 0].Value.ToString() + "','" + dataGridView2["grams", 0].Value.ToString() + "','" + dataGridView2["ml", 0].Value.ToString() + "')";
                        MySqlCommand com1 = new MySqlCommand(ins, conn);
                        com1.ExecuteNonQuery();
                    }
                }
                else if(comboBox1.Text == "Food")
                {
                    string foodid = getprodid();
                    foreach(DataGridViewRow row in dataGridView1.Rows)
                    {
                        string q2 = "set foreign_key_checks=0;insert into ingredients(foodid, productname, quantity, unit) values('" + foodid + "','"
                            + row.Cells["productname"].Value.ToString() + "','"
                            + row.Cells["quantity"].Value.ToString() + "','" 
                            + row.Cells["unit"].Value.ToString() + "')";
                        MySqlCommand comm2 = new MySqlCommand(q2, conn);
                        comm2.ExecuteNonQuery();
                    }
                }
                
                this.Close();
            }
            conn.Close();
        }
        private void fillunits1()
        {
            comboBox4.Items.Add("Pieces");
            comboBox4.Items.Add("Cups");
            comboBox4.Items.Add("Tbsps");
            comboBox4.Items.Add("tsps");
            comboBox4.Items.Add("grams");
            comboBox4.Items.Add("ml");
        }
        
        private void newproduct_Load(object sender, EventArgs e)
        {
            fillproducts();
            filltypecmb();
            fillunits1();
            dataGridView2.Visible = false;
        }
        public void filltypecmb()
        {
            try
            {
                conn.Open();
                //reads every row in product table
                //while there are still values needed to be read
                comboBox1.Items.Add("Consumable");
                comboBox1.Items.Add("Non-Consumable");
                comboBox1.Items.Add("Food");
                conn.Close();

            }
            catch (Exception er)
            {
                MessageBox.Show("Database Error: Please contact your developer.");
            }
        }

        public void fillunits()
        {
            if (comboBox1.Text == "Consumable")
            {
                comboBox2.Items.Add("Pack");
                comboBox2.Items.Add("100 grams");
                comboBox2.Items.Add("200 grams");
                comboBox2.Items.Add("300 grams");
                comboBox2.Items.Add("400 grams");
                comboBox2.Items.Add("500 grams");
                comboBox2.Items.Add("1 Kg");
                comboBox2.Items.Add("2 Kg");
                comboBox2.Items.Add("3 Kg");
                comboBox2.Items.Add("4 Kg");
            }
            else if (comboBox1.Text == "Non-Consumable")
            {
                comboBox2.Items.Add("Very Small");
                comboBox2.Items.Add("Small");
                comboBox2.Items.Add("Medium");
                comboBox2.Items.Add("Large");
                comboBox2.Items.Add("Very Large");
            }
            else if (comboBox1.Text == "Food")
            {
                comboBox2.Items.Add("Small");
                comboBox2.Items.Add("Medium");
                comboBox2.Items.Add("Large");
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox2.Items.Clear();
            fillunits();
            if(comboBox1.Text == "Food")
            {
                this.Size = new Size(891, 587);
                textBox1.Text = 0.ToString();
                textBox1.Enabled = false;
                textBox2.Text = 0.ToString();
                textBox2.Enabled = false;
                dataGridView2.Visible = false;
            }
            else if(comboBox1.Text == "Consumable")
            {
                textBox1.Enabled = true;
                textBox2.Enabled = true;
                dataGridView2.Visible = true;
                if(dataGridView2.Rows.Count >= 1)
                {
                    dataGridView2.Rows.RemoveAt(0);
                }
                dataGridView2.Rows.Add(0,0,0,0,0,0);
            }
            else
            {
                dataGridView2.Visible = false;
                textBox1.Enabled = true;
                textBox2.Enabled = true;
                
            }
        }
        private int getproductcount()
        {
            string q = "select count(*) from product";
            MySqlCommand comm = new MySqlCommand(q, conn);
            return Convert.ToInt32(comm.ExecuteScalar());
        }
        private void fillproducts()
        {
            conn.Open();
            string q = "select pi.* from productioninventory pi group by productname, unit";
            MySqlCommand cmdDataBase = new MySqlCommand(q, conn);
            MySqlDataReader myReader;

            //reads every row in product table
            myReader = cmdDataBase.ExecuteReader();


            while (myReader.Read())
            {
                string pname = myReader.GetString("productname");
                string unit = myReader.GetString("unit");
                comboBox3.Items.Add(pname +"," + unit);
            }
            conn.Close();
        }
        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            string temp = comboBox3.Text;
            string[] result = temp.Split(',');
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string temp = comboBox3.Text;
            string[] result = temp.Split(',');
            if(string.IsNullOrWhiteSpace(comboBox1.Text) ||
                string.IsNullOrWhiteSpace(textBox3.Text))
            {
                MessageBox.Show("Empty Field/s");
            }
            else
            {
                this.dataGridView1.Rows.Add("", result[0], result[1], textBox3.Text);
            }
            
        }

        private string getprodid()
        {
            string q = "select count(*) from product";
            MySqlCommand comm = new MySqlCommand(q, conn);
            return comm.ExecuteScalar().ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.dataGridView1.Rows.RemoveAt(dataGridView1.CurrentRow.Index);
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void pricetxtbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back && e.KeyChar != '.')
            {
                e.Handled = true;
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back && e.KeyChar != '.')
            {
                e.Handled = true;
            }
        }
    }
}
