﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace creams
{
    public partial class purchasestocks : Form
    {
        MySqlConnection conn;

        public purchasestocks()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;");
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void purchasestocks_Load(object sender, EventArgs e)
        {
            fillsuppliercmb();
            fillproductcmb();

            conn.Open();

            label10.Text = getponumber();
            totaltext.Text = 0.ToString();
        }
        public void fillsuppliercmb()
        {
            try
            {
                conn.Open();
                string qr = "select * from supplier;";
                MySqlCommand cmdDataBase = new MySqlCommand(qr, conn);
                MySqlDataReader myReader;

                //reads every row in product table
                myReader = cmdDataBase.ExecuteReader();
                while (myReader.Read())
                {

                    //Remove the irst customer which is for the  walk-in 
                    string sid = myReader.GetString("supplierid");
                    string sname = myReader.GetString("suppliername");
                    //adding entry on comboBox1
                    comboBox2.Items.Add(sid + ", " + sname);
                }
                conn.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Database Error: Please contact your developer.");
            }

        }
        public void fillproductcmb()
        {
            try
            {
                conn.Open();
                string qr = "select * from product where producttype !='Food';";
                MySqlCommand cmdDataBase = new MySqlCommand(qr, conn);
                MySqlDataReader myReader;

                //reads every row in product table
                myReader = cmdDataBase.ExecuteReader();
                while (myReader.Read())
                {
                    string pid = myReader.GetString("productid");
                    string pname = myReader.GetString("productname");
                    string punit = myReader.GetString("productunit");
                    string pprice = myReader.GetString("purchase_price");
                    //adding entry on comboBox1
                    dataGridView2.Rows.Add(pid, pname, punit,pprice);
                }
                conn.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Database Error: Please contact your developer.");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            bool isexist = false;

            string prodid = dataGridView2["productid1", dataGridView2.CurrentRow.Index].Value.ToString();
            string prodname = dataGridView2["productname1", dataGridView2.CurrentRow.Index].Value.ToString();
            string prodprice = dataGridView2["subtotal1", dataGridView2.CurrentRow.Index].Value.ToString();
            //checks if product exists on grid
            

            if (grid1click == false)
            {
                MessageBox.Show("Please choose a product");
            }
            else if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("Empty Field/s");
            }
            
            else
            {
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    if (row.Cells["productid"].Value.ToString() == prodid)
                    {
                        isexist = true;
                    }
                }
                if (isexist)
                {
                    MessageBox.Show("Product already added.");
                }
                else
                {
                    try
                    {
                        this.dataGridView1.Rows.Add(prodid, prodname, textBox1.Text, (Convert.ToDouble(prodprice) * Convert.ToInt32(textBox1.Text)));
                        textBox1.Clear();
                        comboBox2.ResetText();
                    }
                    catch (Exception er)
                    {

                    }
                }
               
            }
        }
        private string getponumber()
        {
            string q = "select count(*) from purchaseorder";
            MySqlCommand comm = new MySqlCommand(q, conn);
            return (Convert.ToInt32(comm.ExecuteScalar()) + 1).ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string temp = comboBox2.Text;
            string[] res = temp.Split(',');
            string q = "insert into purchaseorder(staffid, supplierid, total,date) values('"+getstaffid()+"','"+res[0]+"','"+totaltext.Text+"',now())";
            MySqlCommand comm = new MySqlCommand(q, conn);
            comm.ExecuteNonQuery();

            foreach(DataGridViewRow row in dataGridView1.Rows)
            {
                string q2 = "insert into purchasedetails(purchaseid,productid,quantity,subtotal, totalquantity) values('"+label10.Text+"','"+row.Cells[0].Value+"','"+ row.Cells[2].Value + "','"+ row.Cells[3].Value + "', '"+ row.Cells[2].Value + "')";
                MySqlCommand comm2 = new MySqlCommand(q2, conn);
                comm2.ExecuteNonQuery();
            }
            MessageBox.Show("Purchase success!");
            this.Close();
        }
        private string getstaffid()
        {
            //checks user privilege
            string query = "select staffid from staff where username like '" + loginform.currentuser + "'";
            MySqlCommand comm = new MySqlCommand(query, conn);

            string id = Convert.ToString(comm.ExecuteScalar());
            return id;
        }

        private void dataGridView1_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            double total = 0;
            foreach(DataGridViewRow row in dataGridView1.Rows)
            {
                total += Convert.ToDouble(row.Cells["subtotal"].Value.ToString());
                
            }
            totaltext.Text = total.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (!grid2click)
            {
                MessageBox.Show("Please select");
            }
            else
            {
                DialogResult dr = MessageBox.Show(@"Remove?",
                                               Application.ProductName,
                                               MessageBoxButtons.YesNo);
                if (dr == DialogResult.Yes)
                {
                    this.dataGridView1.Rows.RemoveAt(dataGridView1.CurrentRow.Index);
                }
            }
        }
        bool grid1click = false;
        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            grid1click = true;
        }
        bool grid2click = false;
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            grid1click = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!grid2click)
            {
                MessageBox.Show("Please select");
            }
            else
            {
                DialogResult dr = MessageBox.Show(@"Remove All?",
                                               Application.ProductName,
                                               MessageBoxButtons.YesNo);
                if (dr == DialogResult.Yes)
                {
                    this.dataGridView1.Rows.Clear();
                }
            }
        }
    }
}
