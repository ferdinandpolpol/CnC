﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Drawing.Printing;
using Microsoft.VisualBasic;

namespace creams
{
    public partial class newsalesorder : Form
    {
        MySqlConnection conn;
        public static string orderid;
        public static string customerid;
        public static string total;
        public static bool active;
        public newsalesorder()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;");
        }
        bool submittedorder;
        private void button3_Click(object sender, EventArgs e)
        {
            active = true;
            string check = "select count(*) from orderline where orderid = '" + orderidtext.Text + "'";
            MySqlCommand com = new MySqlCommand(check, conn);
            if (Convert.ToInt32(com.ExecuteScalar()) <= 0)
            {
                MessageBox.Show("Please select products to order");
            }
            else
            {
                if (string.IsNullOrEmpty(customercmb.Text))
                {
                    MessageBox.Show("Please choose a customer!");
                }
                else
                {
                    conn.Close();
                    conn.Open();
                    total = totalresult.Text;
                    orderid = orderidtext.Text;
                    if(customercmb.Text == "Walk-in")
                    {
                        customerid = 0.ToString();
                    }
                    else
                    {
                        customerid = getcustomerid();
                    }
                    
                    payment pay = new payment();
                    pay.ShowDialog();
                    if (payment.cancel == true)
                    {
                    }
                    else
                    {
                        string query = "update orders set customerid='" + customerid + "', total='" + total + "', date=current_timestamp, type='Sales',discount ='"+discounttxt.Text+"' where orderid=" + orderidtext.Text;
                        MySqlCommand comm = new MySqlCommand(query, conn);
                        comm.ExecuteNonQuery();
                        // string update = "update saleinventory set quantity = quantity - '" + getquantity() + "'";//  + "' where productid = '" ++ "'";
                        MessageBox.Show("Succesfully created order!");
                        submittedorder = true;

                        
                        foreach (DataGridViewRow row in dataGridView1.Rows)
                        {
                            string saleinv = "select * from saleinventory where productid='"+ row.Cells["productid"].Value.ToString() +"'";
                            MySqlCommand comm1 = new MySqlCommand(saleinv, conn);
                            MySqlDataAdapter adp = new MySqlDataAdapter(comm1); //used on select query only
                            DataTable dt = new DataTable();
                            adp.Fill(dt);

                            dataGridView2.DataSource = dt;

                            string orderlineid = row.Cells["orderlineid"].Value.ToString();
                            string quantity = row.Cells["quantity"].Value.ToString();
                            foreach (DataGridViewRow row2 in dataGridView2.Rows)
                            {
                                if(Convert.ToInt32(row2.Cells["quantity"].Value) > 0)
                                {
                                    string saleid = row2.Cells["saleid"].Value.ToString();
                                    string prodid = row2.Cells["productid"].Value.ToString();
                                    if (Convert.ToInt32(row2.Cells["quantity"].Value) >= Convert.ToInt32(row.Cells["quantity"].Value))
                                    {
                                        string q1 = "update saleinventory set saleinventory.quantity = saleinventory.quantity - '"+quantity+"' where saleinventory.saleid = '" + saleid + "';" +
                                                    "insert into stockout(productid, quantity, reason) values('" + prodid + "','" + quantity + "','Sales')";
                                        MySqlCommand com1 = new MySqlCommand(q1, conn);
                                        com1.ExecuteNonQuery();
                                        break;
                                    }
                                    else if (Convert.ToInt32(row2.Cells["quantity"].Value) < Convert.ToInt32(row.Cells["quantity"].Value))
                                    {
                                        string salequantity = row2.Cells["quantity"].Value.ToString();
                                        string olquantity = row.Cells["quantity"].Value.ToString();
                                        double price = Convert.ToDouble(row.Cells["selling_price"].Value);
                                        string quantityleft = (Convert.ToInt32(olquantity) - Convert.ToInt32(salequantity)).ToString();
                                        double subtotal = price * Convert.ToInt32(quantityleft);
                                        double presubtotal = (Convert.ToInt32(olquantity) - Convert.ToInt32(quantityleft)) * price;

                                        string q1 = "update saleinventory set saleinventory.quantity = 0 where saleinventory.saleid = '" + saleid + "';" +
                                                    "insert into stockout(productid, quantity, reason) values('" + prodid + "','" + salequantity + "','Sales');" +
                                                    "update orderline set quantity =quantity - '"+quantityleft+"',subtotal ='"+presubtotal+"' where orderlineid='"+orderlineid+"';"+
                                                    "set foreign_key_checks=0;insert into orderline(orderid, saleid, productid, productname, selling_price, subtotal, quantity) " +
                                                    "values('"+orderidtext.Text+ "','" + row.Cells["saleid"].Value.ToString() + "','" + row.Cells["productid"].Value.ToString() +
                                                    "','" + row.Cells["productname"].Value.ToString() + "','" + row.Cells["selling_price"].Value.ToString() + "','"+subtotal+"', '"+quantityleft+"');set foreign_key_checks=1;";
                                        MySqlCommand com1 = new MySqlCommand(q1, conn);
                                        com1.ExecuteNonQuery();
                                        refreshdatabase();
                                        break;
                                    }
                                }
                                else
                                {
                                    continue;
                                }
                            }
                        
                        }
                        PrintDialog printDialog = new PrintDialog();

                        PrintDocument printDocument = new PrintDocument();

                        PrintPreviewDialog printPreviewDialog1 = new PrintPreviewDialog();
                        printDialog.Document = printDocument; //add the document to the dialog box...        
                        printDocument.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(CreateReceipt); //add an event handler that will do the printing
                        printPreviewDialog1.Document = printDocument;
                        printPreviewDialog1.ShowDialog();
                        this.Close();

                    }
                }
            }

            
            //on a till you will not want to ask the user where to print but this is fine for the test envoironment.
        }
        //PRINTING SHI
        
        private void btnPrintReciept_Click(object sender, EventArgs e)
        {
            
        }

        public void CreateReceipt(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {

            double total = Convert.ToDouble(payment.total);
            double cash = Convert.ToDouble(payment.amount);
            double change = Convert.ToDouble(payment.change);

            //this prints the reciept

            Graphics graphic = e.Graphics;

            Font font = new Font("Courier New", 12); //must use a mono spaced font as the spaces need to line up

            float fontHeight = font.GetHeight();

            int startX = 10;
            int startY = 10;
            int offset = 40;

            graphic.DrawString(" Creams and Crumbs", new Font("Courier New", 18), new SolidBrush(Color.Black), startX, startY);
            string top = "Item Name".PadRight(30) + "Price";
            graphic.DrawString(top, font, new SolidBrush(Color.Black), startX, startY + offset);
            offset = offset + (int)fontHeight; //make the spacing consistent
            graphic.DrawString("----------------------------------", font, new SolidBrush(Color.Black), startX, startY + offset);
            offset = offset + (int)fontHeight + 5; //make the spacing consistent


            foreach (DataGridViewRow item in dataGridView1.Rows)
            {
                //create the string to print on the reciept
                string productDescription = item.Cells["productname"].Value.ToString() + " X " + item.Cells["quantity"].Value.ToString();
                string productTotal = item.Cells["subtotal"].Value.ToString();
                string productPrice = item.Cells["selling_price"].Value.ToString();

                //MessageBox.Show(item.Substring(item.Length - 5, 5) + "PROD TOTAL: " + productTotal);


                //totalprice += productPrice;

                if (productDescription.Contains("  -"))
                {
                    string productLine = item.Cells["subtotal"].Value.ToString();

                    graphic.DrawString(productLine, new Font("Courier New", 12, FontStyle.Italic), new SolidBrush(Color.Red), startX, startY + offset);

                    offset = offset + (int)fontHeight + 5; //make the spacing consistent
                }
                else
                {
                    string productLine = productDescription;

                    graphic.DrawString(productLine.PadRight(30) + String.Format("{0:c}",productTotal), font, new SolidBrush(Color.Black), startX, startY + offset);
                    //graphic.DrawString("Order #".PadRight(30) + String.Format("{0:c}", orderidtext.Text), font, new SolidBrush(Color.Black), startX, startY + offset);
                    offset = offset + (int)fontHeight + 5; //make the spacing consistent
                }

            }

            //when we have drawn all of the items add the total

            offset = offset + 20; //make some room so that the total stands out.
            graphic.DrawString("Order #".PadRight(30) + String.Format("{0:c}", orderidtext.Text), font, new SolidBrush(Color.Black), startX, startY + offset);
            offset = offset + 20;
            graphic.DrawString("Total to pay ".PadRight(30) + String.Format("{0:c}", total), new Font("Courier New", 12, FontStyle.Bold), new SolidBrush(Color.Black), startX, startY + offset);

            offset = offset + 30; //make some room so that the total stands out.
            graphic.DrawString("CASH ".PadRight(30) + String.Format("{0:c}", cash), font, new SolidBrush(Color.Black), startX, startY + offset);
            offset = offset + 15;
            graphic.DrawString("CHANGE ".PadRight(30) + String.Format("{0:c}", change), font, new SolidBrush(Color.Black), startX, startY + offset);
            offset = offset + 30; //make some room so that the total stands out.
            graphic.DrawString("     Thank-you for your custom,", font, new SolidBrush(Color.Black), startX, startY + offset);
            offset = offset + 15;
            graphic.DrawString("       please come back soon!", font, new SolidBrush(Color.Black), startX, startY + offset);

        }//PRINTING SHIT

        private void button1_Click(object sender, EventArgs e)
        {
            active = true;
            inventorylist inv = new inventorylist();
            inv.ShowDialog();
            active = false;
            refreshdatabase();
        }
        private string getrowcount()
        {
            MySqlCommand comm = new MySqlCommand("select count(*) from orders", conn);

            Int32 norows = Convert.ToInt32(comm.ExecuteScalar());
            return norows.ToString();
        }
        private string getcustomerid()
        {
            string query = "select customerid from customer where concat(lastname,', ' ,firstname)='" + customercmb.Text + "'";
            MySqlCommand comm = new MySqlCommand(query, conn);


            Int32 custid = Convert.ToInt32(comm.ExecuteScalar());
            customerid = custid.ToString();
            return custid.ToString();
        }
        private string gettotal()
        {
            string query = "select sum(subtotal) from orderline where orderid=" + orderidtext.Text + ";";
            MySqlCommand comm = new MySqlCommand(query, conn);

            string total = comm.ExecuteScalar().ToString();
            if (string.IsNullOrEmpty(total))
            {
                return 0.ToString();
            }
            else
            {
                return total;
            }
        }
        private void newsalesorder_Load(object sender, EventArgs e)
        {
            submittedorder = false;
            fillcustomercmb();
            customercmb.Text = "Walk-in";
            conn.Open();
            orderidtext.Text = getrowcount();
            discounttxt.Text = 0.ToString();                //Sets default value for discount
            refreshdatabase();
        }
        private void refreshdatabase()
        {
            //selects all the staff from the database
            string query = "select ol.orderlineid, ol.productid, p.productname,p.productunit, p.selling_price, p.producttype, ol.quantity, ol.subtotal, ol.saleid from orderline ol join product p on ol.productid = p.productid where ol.orderid = '" + orderidtext.Text + "'";
            MySqlCommand comm = new MySqlCommand(query, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm); //used on select query only
            DataTable dt = new DataTable();
            adp.Fill(dt);

            //Loads the database values to the dataGridView
            dataGridView1.DataSource = dt;

            dataGridView1.Columns["producttype"].Visible = false;
            dataGridView1.Columns["orderlineid"].Visible = false;
            dataGridView1.Columns["saleid"].Visible = false;
            dataGridView1.Columns["productid"].Visible = false;
            dataGridView1.Columns["productunit"].HeaderText = "Unit";
            dataGridView1.Columns["productname"].HeaderText = "Product";
            dataGridView1.Columns["selling_price"].HeaderText = "Price";
            dataGridView1.Columns["quantity"].HeaderText = "Quantity";
            dataGridView1.Columns["subtotal"].HeaderText = "Subtotal";
            total = totalresult.Text = gettotal();
        }
        private string getquantity()
        {
            string query = "select quantity from orderline";
            MySqlCommand comm = new MySqlCommand(query, conn);

            Int32 quantity = Convert.ToInt32(comm.ExecuteScalar());
            return quantity.ToString();
        }
        public void fillcustomercmb()
        {
            conn.Close();
            conn.Open();
            try
            {
                string qr = "select * from customer;";
                MySqlCommand cmdDataBase = new MySqlCommand(qr, conn);
                MySqlDataReader myReader;

                //reads every row in product table
                myReader = cmdDataBase.ExecuteReader();
                customercmb.Items.Add("Walk-in");
                while (myReader.Read())
                {
                    string cid = myReader.GetString("customerid");
                    string fname = myReader.GetString("firstname");
                    string lname = myReader.GetString("lastname");

                    customercmb.Items.Add(lname + ", " + fname);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Database Error: Please contact your developer.");
            }
            conn.Close();
        }
        private double getprice()
        {
            string orderlineid2 = dataGridView1["orderlineid", dataGridView1.CurrentRow.Index].Value.ToString();
            string priceq = "select selling_price from orderline where orderlineid=" + orderlineid2 + ";";
            MySqlCommand comm2 = new MySqlCommand(priceq, conn);
            double price = Convert.ToDouble(comm2.ExecuteScalar());
            return price;
        }

        private void button10_Click(object sender, EventArgs e)
        {
        }

        private void button5_Click(object sender, EventArgs e)
        {
            
        }

        private void button11_Click(object sender, EventArgs e)
        { }
            

        private void discounttxt_TextChanged(object sender, EventArgs e)
        {
    
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string orderlineid = dataGridView1["orderlineid", dataGridView1.CurrentRow.Index].Value.ToString();
                string productname = dataGridView1[2, dataGridView1.CurrentRow.Index].Value.ToString();
                string query = "delete from orderline where orderlineid =" + orderlineid;
                MySqlCommand comm = new MySqlCommand(query, conn);
                comm.ExecuteNonQuery();

                MessageBox.Show("Removed Product " + productname);
                refreshdatabase();
            }
            catch (Exception er)
            {
                MessageBox.Show("Please select a product to remove.");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            refreshdatabase();
        }

        private void newsalesorder_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (submittedorder == true)
            {

            }
            else
            {
                DialogResult dr = MessageBox.Show(@"Do you really want to close the form?",
                                               Application.ProductName,
                                               MessageBoxButtons.YesNo);
                if (dr == DialogResult.Yes && submittedorder == false)
                {
                    string type = "set foreign_key_checks = 0;delete from orders where orderid='" + orderidtext.Text + "'; delete from orderline where orderid='" + orderidtext.Text + "'; set foreign_key_checks=1;";
                    MySqlCommand commtype = new MySqlCommand(type, conn);
                    commtype.ExecuteNonQuery();
                }
                else if (dr == DialogResult.No)
                {
                    e.Cancel = true;
                }
            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
            
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            string check = "select count(*) from orderline where orderid = '" + orderidtext.Text + "'";
            MySqlCommand com = new MySqlCommand(check, conn);
            if (Convert.ToInt32(com.ExecuteScalar()) <= 0)
            {
                MessageBox.Show("Please select products to order");
            }
            else
            {
                string orderlineid2 = dataGridView1["orderlineid", dataGridView1.CurrentRow.Index].Value.ToString();
                string productname = dataGridView1["productname", dataGridView1.CurrentRow.Index].Value.ToString();
                if (orderlineid2 == null)
                {
                    MessageBox.Show("Please select a product");
                    textBox1.Clear();
                }
                else if (string.IsNullOrWhiteSpace(textBox1.Text))
                {

                }
                else
                {
                    Int32 productid = Convert.ToInt32(dataGridView1["productid", dataGridView1.CurrentRow.Index].Value);

                    string qty = "select sum(quantity) from saleinventory where productid='" + productid + "' group by productid";
                    MySqlCommand comm2 = new MySqlCommand(qty, conn);
                    comm2.ExecuteNonQuery();
                    Int32 quantity = Convert.ToInt32(comm2.ExecuteScalar());

                    if (Convert.ToInt32(textBox1.Text) > quantity)
                    {
                        MessageBox.Show("Quantity exceeds current sales quantity");
                        textBox1.Clear();
                    }
                    else
                    {

                        double subtotal = Convert.ToInt32(textBox1.Text) * getprice();

                        string q = "update orderline set quantity = '" + textBox1.Text + "', subtotal = '" + subtotal + "' where orderlineid = '" + orderlineid2 + "'";
                        MySqlCommand comm3 = new MySqlCommand(q, conn);
                        comm3.ExecuteNonQuery();

                        // Informs the user for succesful update
                        refreshdatabase();
                    }
                }
            }
        }

        private void textBox1_Enter(object sender, EventArgs e)
        {
            
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void discounttxt_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(discounttxt.Text))
            {
                totalresult.Text = gettotal();
            }
            else
            {
                totalresult.Text = (Convert.ToDouble(totalresult.Text) - Convert.ToDouble(discounttxt.Text)).ToString();
            }
        }
    }
}