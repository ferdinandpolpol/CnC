﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace creams
{
    public partial class viewproduct : Form
    {
        public MySqlConnection conn;
        public static string productid;
        public viewproduct()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;");
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void viewproduct_Load_1(object sender, EventArgs e)
        {
            //button2.Visible = false;
            textBox4.Visible = false;
            label7.Visible = false;
            refreshdatabase();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Closes the viewproduct form
            this.Close();
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                //Collects the values from the tables to the textbox's
                label1.Text = dataGridView1.Rows[e.RowIndex].Cells["productname"].Value.ToString();

                productid = textBox4.Text = dataGridView1.Rows[e.RowIndex].Cells["productid"].Value.ToString();
            }
            catch (Exception er)
            {
                //This is to prevent an error in the code when the table header is pressed
                //No message is shown to prevent annoying, repeating message
            }

        }

        private void updatebtn_Click(object sender, EventArgs e)
        {
            
        }

        //Search for product

        private void refreshdatabase()
        {
            conn.Open();
            //selects all the product from the database
            MySqlCommand comm = new MySqlCommand("select * from product", conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm); //used on select query only
            DataTable dt = new DataTable();
            adp.Fill(dt);

            //Loads the database values to the dataGridView
            dataGridView1.DataSource = dt;
            conn.Close();

            //.Visible removes the unnecessary and valuable information
            dataGridView1.Columns["productid"].Visible = false;


            //Changes the header text from the database
            dataGridView1.Columns["productname"].HeaderText = "Name of Product";
            dataGridView1.Columns["purchase_price"].HeaderText = "Purchase Price";
            dataGridView1.Columns["selling_price"].HeaderText = "Sale Price";
            dataGridView1.Columns["producttype"].HeaderText = "Type";
            dataGridView1.Columns["productdesc"].HeaderText = "Description";
            dataGridView1.Columns["productunit"].HeaderText = "Unit";
            dataGridView1.Columns["reorderpoint"].HeaderText = "Reorder Point";
        }

        private void addprodbtn_Click(object sender, EventArgs e)
        {
            newproduct np = new newproduct();
            np.ShowDialog();

            refreshdatabase();
        }

        private void searchtxtbox_TextChanged(object sender, EventArgs e)
        {
            conn.Open();
            //selects all the product from the database
            MySqlCommand comm = new MySqlCommand("select * from product where productname like '" + searchtxtbox.Text + "%'", conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm); //used on select query only
            DataTable dt = new DataTable();
            adp.Fill(dt);

            //Loads the database values to the dataGridView
            dataGridView1.DataSource = dt;
            conn.Close();

            //.Visible removes the unnecessary and valuable information
            dataGridView1.Columns["productid"].Visible = false;


            //Changes the header text from the database
            dataGridView1.Columns["productname"].HeaderText = "Name of Product";
            dataGridView1.Columns["selling_price"].HeaderText = "Prices";
            dataGridView1.Columns["producttype"].HeaderText = "Type";
            dataGridView1.Columns["productdesc"].HeaderText = "Description";
            dataGridView1.Columns["productunit"].HeaderText = "Unit";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox4.Text))
            {
                MessageBox.Show("Please choose a product");
            }
            else
            {
                 productdetails pd = new productdetails();
                pd.ShowDialog();
                refreshdatabase();
            } 
        }

        private void button2_Click(object sender, EventArgs e)
        {
            refreshdatabase();
        }
    }
}
