﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace creams
{
    public partial class stockreturn : Form
    {
        MySqlConnection conn;
        public stockreturn()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;convert zero datetime=True");
        }

        private void stockreturn_Load(object sender, EventArgs e)
        {
            groupBox1.Enabled = false;
            fillponumber();
            conn.Open();
        }
        private void loadinventory()
        {
            
        }
        public void fillponumber()
        {
            try
            {
                conn.Open();
                string qr = "select * from purchaseorder";
                MySqlCommand cmdDataBase = new MySqlCommand(qr, conn);
                MySqlDataReader myReader;

                //reads every row in product table
                myReader = cmdDataBase.ExecuteReader();
                while (myReader.Read())
                {
                    string pid = myReader.GetString("purchaseid");
                    //adding entry on comboBox1
                    comboBox1.Items.Add(pid);
                }
                conn.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Database Error: Please contact your developer.");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (gridclick == false)
            {
                MessageBox.Show("Please select");
            }
            else
            {
                DialogResult dr = MessageBox.Show(@"Remove?",
                                               Application.ProductName,
                                               MessageBoxButtons.YesNo);
                if (dr == DialogResult.Yes)
                {
                    this.dataGridView1.Rows.RemoveAt(dataGridView1.CurrentRow.Index);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (gridclick == false)
            {
                MessageBox.Show("Please select");
            }
            else
            {
                DialogResult dr = MessageBox.Show(@"Remove All?",
                                               Application.ProductName,
                                               MessageBoxButtons.YesNo);
                if (dr == DialogResult.Yes)
                {
                    this.dataGridView1.Rows.Clear();
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            dataGridView2.Rows.Clear();
            string query = "select si.saleid, si.productid, p.productname, si.purchaseid, p.productunit,si.quantity, p.selling_price, stl.deliverynumber from saleinventory si, product p, stockinline stl where stl.stockinlineid=si.stockinlineid and si.productid=p.productid and si.purchaseid='"+comboBox1.Text+"' and si.quantity>0 order by p.productname desc ";
            MySqlCommand comm = new MySqlCommand(query, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView1.DataSource = dt;


            dataGridView1.Columns["purchaseid"].Visible = false;
            dataGridView1.Columns["saleid"].Visible = false;
            dataGridView1.Columns["productid"].Visible = false;
            dataGridView1.Columns["selling_price"].Visible = false;
            dataGridView1.Columns["productname"].HeaderText = "Product";
            dataGridView1.Columns["selling_price"].HeaderText = "Prices";
            dataGridView1.Columns["productunit"].HeaderText = "Unit";
            dataGridView1.Columns[4].HeaderText = "Current Quantity";
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (Convert.ToInt32(textBox1.Text) > Convert.ToInt32(dataGridView1[5, dataGridView1.CurrentRow.Index].Value.ToString()))
            {
                MessageBox.Show("Invalid Quantity");
                textBox1.Clear();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            bool isexist = false;
            string sid = dataGridView1[0, dataGridView1.CurrentRow.Index].Value.ToString();
            string pid = dataGridView1[1, dataGridView1.CurrentRow.Index].Value.ToString();
            string pname = dataGridView1[2, dataGridView1.CurrentRow.Index].Value.ToString();
            string punit = dataGridView1[4, dataGridView1.CurrentRow.Index].Value.ToString();
            string puid = dataGridView1[3, dataGridView1.CurrentRow.Index].Value.ToString();
            string qty = textBox1.Text;
            string reason = comboBox2.Text;

            //checks if product exists on grid
            foreach (DataGridViewRow row in dataGridView2.Rows)
            {
                if (row.Cells["saleid"].Value.ToString() == sid)
                {
                    isexist = true;
                }
            }

            if (dataGridView1.CurrentRow.Index == null)
            {
                MessageBox.Show("Please choose a product");
            }
            else if (string.IsNullOrWhiteSpace(textBox1.Text) ||
                    string.IsNullOrWhiteSpace(comboBox2.Text))
            {
                MessageBox.Show("Empty Field/s");
            }
            else if (isexist)
            {
                MessageBox.Show("Product already added.");
            }
            else
            {
                try
                {
                    this.dataGridView2.Rows.Add(sid,pid, puid, pname, punit, qty, reason);
                    textBox1.Clear();
                }
                catch (Exception er)
                {

                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            groupBox1.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string ret = "insert into stockreturn(staffid, purchaseid, date) values('"+getstaffid()+"','"+comboBox1.Text+"',now())";
            MySqlCommand commret = new MySqlCommand(ret, conn);
            commret.ExecuteNonQuery();

            foreach(DataGridViewRow row in dataGridView2.Rows)
            {
                string saleid = row.Cells[0].Value.ToString();
                string pid = row.Cells[1].Value.ToString();
                string purchid = row.Cells[2].Value.ToString();
                string pname = row.Cells[3].Value.ToString();
                string punit = row.Cells[4].Value.ToString();
                string quantity = row.Cells[5].Value.ToString();
                string reason = row.Cells[6].Value.ToString();

                string upd = "update saleinventory set quantity = quantity - '" + quantity + "' where saleid = '" + saleid + "';" +
                                     "insert into stockout(productid, quantity, reason) values('" + pid + "','" + quantity + "','" + reason + "');" +
                                     " update purchasedetails set quantity = quantity + '" + quantity + "' where purchaseid = '" + purchid + "' and productid = '" + pid + "';" +
                                     "insert into stockreturnline(stockreturnid, productid, quantity, reason) values('" + getsreturnid() + "','" + pid + "','" + quantity + "','" + reason + "') ";
                MySqlCommand comm = new MySqlCommand(upd, conn);
                comm.ExecuteNonQuery();

                /*string loadsale = "select * from saleinventory where purchaseid = '"+purchid+"' and productid = '"+pid+"' and quantity > 0";
                MySqlCommand comm1 = new MySqlCommand(loadsale, conn);
                MySqlDataAdapter adp = new MySqlDataAdapter(comm1);
                DataTable dt = new DataTable();
                adp.Fill(dt);

                dataGridView3.DataSource = dt;

                foreach (DataGridViewRow row2 in dataGridView3.Rows)
                {
                    
                    string saleqty = row2.Cells[3].Value.ToString();
                    string saleid = row2.Cells[0].Value.ToString();
                    int quantityleft = Convert.ToInt32(quantity) - Convert.ToInt32(saleqty);

                    if(Convert.ToInt32(quantity) >= Convert.ToInt32(saleqty))
                    {

                        string upd = "update saleinventory set quantity = 0 where saleid = '"+saleid+"';" +
                                     "insert into stockout(productid, quantity, reason) values('" + pid + "','" + saleqty + "','" + reason + "');"  + 
                                     "update purchasedetails set quantity = quantity + '"+saleqty+"' where purchaseid = '"+purchid+"' and productid = '"+pid+"';" +
                                     "insert into stockreturnline(stockreturnid, productid, quantity, reason) values('"+getsreturnid()+"','"+pid+"','"+saleqty+"','"+reason+"') ";
                        MySqlCommand comm = new MySqlCommand(upd, conn);
                        comm.ExecuteNonQuery();

                        row.Cells[4].Value = Convert.ToInt32(quantity) - Convert.ToInt32(quantityleft);
                        dataGridView2.Rows.Add(pid,purchid,pname,punit,quantityleft,reason);
                        break;
                    }
                    else if(Convert.ToInt32(quantity) < Convert.ToInt32(saleqty))
                    {
                        string upd = "update saleinventory set quantity = quantity - '"+quantity+"' where saleid = '" + saleid + "';" +
                                     "insert into stockout(productid, quantity, reason) values('" + pid + "','" + quantity + "','" + reason + "');" +
                                     " update purchasedetails set quantity = quantity + '" + quantity + "' where purchaseid = '" + purchid + "' and productid = '" + pid + "';" +
                                     "insert into stockreturnline(stockreturnid, productid, quantity, reason) values('" + getsreturnid() + "','" + pid + "','" + quantity + "','" + reason + "') ";
                        MySqlCommand comm = new MySqlCommand(upd, conn);
                        comm.ExecuteNonQuery();
                        break;
                    }
                }*/
            }
            MessageBox.Show("Return Submitted!");
            this.Close();
        }
        private string getstaffid()
        {
            //checks user privilege
            string query = "select staffid from staff where username like '" + loginform.currentuser + "'";
            MySqlCommand comm = new MySqlCommand(query, conn);

            string id = Convert.ToString(comm.ExecuteScalar());
            return id;
        }
        private string getsreturnid()
        {
            //checks user privilege
            string query = "select count(*) from stockreturn";
            MySqlCommand comm = new MySqlCommand(query, conn);

            string id = Convert.ToString(comm.ExecuteScalar());
            return id;
        }
        bool gridclick = false;
        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            gridclick = true;
        }
    }
}
