﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace creams
{
    public partial class newreturns : Form
    {
        MySqlConnection conn;
        private double total;       //Global Variable total
        public newreturns()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;");
        }

        private void returns_Load(object sender, EventArgs e)
        {
            fillordercmb();
            conn.Open();
            filltype();
            //label8.Text = 0.ToString();
            label5.Text = 0.ToString();
            label10.Text = getreturnid().ToString();     
        }
        public void fillordercmb()
        {

            conn.Open();
            try
            {
                string qr = "select orders.* from orders where type != 'Returned' and date(orders.date) between (current_date() - interval 3 day) and date(now())  and orders.type != 'Delivery' order by orders.orderid;";
                MySqlCommand cmdDataBase = new MySqlCommand(qr, conn);
                MySqlDataReader myReader;

                //reads every row in product table
                myReader = cmdDataBase.ExecuteReader();
                //while there are still values needed to be read
                while (myReader.Read())
                {
                    string oid = myReader.GetString("orderid");

                    comboBox1.Items.Add(oid);
                }


            }
            catch (Exception)
            {
                MessageBox.Show("Database Error: Please contact your developer.");
            }
            conn.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            refreshdatabase();
            conn.Close();
            conn.Open();
            
        }
        private void refreshdatabase()
        {
            
            string q = "select orderline.orderlineid,product.productid, product.productname, product.selling_price, sum(orderline.quantity), orderline.subtotal from orderline, product where orderid ='" + comboBox1.Text + "' and orderline.productid=product.productid group by productid";
            MySqlCommand comm = new MySqlCommand(q, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm);
            DataTable dt = new DataTable();
            adp.Fill(dt);
            dataGridView3.DataSource = dt;

            dataGridView3.Columns[0].Visible = false;
            dataGridView3.Columns[1].Visible = false;
            dataGridView3.Columns[3].HeaderText = "Price";
            dataGridView3.Columns[4].HeaderText = "Quantity";
        }
        
        private void returns_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (submittedorder == true)
            {

            }
            else
            {
                DialogResult dr = MessageBox.Show(@"Do you really want to close the form?",
                                               Application.ProductName,
                                               MessageBoxButtons.YesNo);
                if (dr == DialogResult.Yes && submittedorder == false)
                {
                    string type = "set foreign_key_checks = 0;delete from creamsncrumbs.`return` where returnid = '" + label10.Text + "'; delete from returnline where returnid = '" + label10.Text + "'; set foreign_key_checks=1";
                    MySqlCommand commtype = new MySqlCommand(type, conn);
                    commtype.ExecuteNonQuery();
                }
                else if (dr == DialogResult.No)
                {
                    e.Cancel = true;
                }
            }
        }

        private int quantity1;

        bool grid1_pressed;
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //Sets the original quantity of the product
            
            quantity1 = Convert.ToInt32(dataGridView1["quantity", dataGridView1.CurrentRow.Index].Value.ToString());
            textBox1.Text = dataGridView1["quantity", dataGridView1.CurrentRow.Index].Value.ToString();
            
        }
        private string getprodtype(string prodid)
        {
            string q = "select producttype from product where productid = '" + prodid + "'";
            MySqlCommand comm = new MySqlCommand(q, conn);
            return comm.ExecuteScalar().ToString();
        }
        private void dataGridView1_CellValueChanged_1(object sender, DataGridViewCellEventArgs e)
        {
            gettotal();
            //calculatediscount();
        }

        //Remove Button
        private void button2_Click(object sender, EventArgs e)
        {
            if (!grid1_pressed)
            {
                MessageBox.Show("Please select");
            }
            else
            {
                dataGridView1.Rows.RemoveAt(dataGridView1.CurrentRow.Index);
                gettotal();

            }
            //calculatediscount();
        }

        //Reload orders button
        private void button3_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(comboBox1.Text))
            {
                MessageBox.Show("No Data to Reload");
            }
            else
            {
                conn.Close();
                if (dataGridView1.Columns.Contains("returntype") || dataGridView1.Columns.Contains("productstatus"))
                {
                    dataGridView1.Columns.Remove("returntype");
                    dataGridView1.Columns.Remove("productstatus");
                }
                conn.Open();
                refreshdatabase();
                conn.Close();
                conn.Open();
            }
        }

        //get total orders value
        private void gettotal()
        {
            double stotal = 0;
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                stotal += Convert.ToDouble(row.Cells["subtotal"].Value);
            }
            label5.Text = stotal.ToString();
        }

        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {       
        }

        //Submit Button
        bool submittedorder;
        private string getstockinlineid()
        {
            string q = "select count(*) from stockinline";
            MySqlCommand qcomm = new MySqlCommand(q, conn);
            return qcomm.ExecuteScalar().ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(dataGridView1.Rows.Count <= 0)
            {
                MessageBox.Show("Please select order or reload, " + e.ToString());
            }
            else
            {
                conn.Close();
                conn.Open();
                string temp = comboBox1.Text.ToString();
                string[] result = temp.Split(',');
                string update = "update creamsncrumbs.`return` set orderid = '" + comboBox1.Text + "', returntotal = '" + label5.Text + "' where returnid='" + label10.Text + "'";
                MySqlCommand comm = new MySqlCommand(update, conn);
                comm.ExecuteNonQuery();

                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    string orderlineid = row.Cells["orderlineid"].Value.ToString();
                    string q1 = "insert into returnline(returnid, orderlineid, quantityreturned, subtotal, returntype,productstatus,action)values('"
                                + label10.Text + "','" + orderlineid + "','" + row.Cells["quantity"].Value.ToString() + "','" + row.Cells["subtotal"].Value.ToString() + "', '"
                                + row.Cells["returntype"].Value.ToString() + "', '" + row.Cells["productstatus"].Value.ToString() + "', '" + row.Cells["action"].Value.ToString() + "')";
                    MySqlCommand rlupdate = new MySqlCommand(q1, conn);
                    rlupdate.ExecuteNonQuery();

                    string prodid = row.Cells["productid"].Value.ToString(); ;
                    string producttype = getproducttype(Convert.ToInt32(row.Cells["productid"].Value));
                    string action = row.Cells["action"].Value.ToString();
                    if (row.Cells["returntype"].Value.ToString() == "Replace")
                    {
                        if (action == "Throw")
                        {
                            string saleinv = "select * from saleinventory where productid='" + row.Cells["productid"].Value.ToString() + "'";
                            MySqlCommand comm1 = new MySqlCommand(saleinv, conn);
                            MySqlDataAdapter adp = new MySqlDataAdapter(comm1); //used on select query only
                            DataTable dt = new DataTable();
                            adp.Fill(dt);

                            dataGridView2.DataSource = dt;

                            string pid = row.Cells["productid"].Value.ToString();
                            string pname = row.Cells["productname"].Value.ToString();
                            string quantity = row.Cells["quantity"].Value.ToString();
                            string reason = row.Cells["productstatus"].Value.ToString();
                            string price = (Convert.ToDouble(row.Cells["subtotal"].Value)/Convert.ToInt32(quantity)).ToString();
                            foreach (DataGridViewRow row2 in dataGridView2.Rows)
                            {
                                if (Convert.ToInt32(row2.Cells["quantity"].Value) > 0)
                                {
                                    string saleid = row2.Cells["saleid"].Value.ToString();
                                    string prodid2 = row2.Cells["productid"].Value.ToString();
                                    if (Convert.ToInt32(row2.Cells["quantity"].Value) >= Convert.ToInt32(row.Cells["quantity"].Value))
                                    {
                                        string q2 = "update saleinventory set saleinventory.quantity = saleinventory.quantity - '" + quantity + "' where saleinventory.saleid = '" + saleid + "';" +
                                                    "insert into stockout(productid, quantity, reason) values('" + prodid2 + "','" + quantity + "','" + reason + " and Replaced')";
                                        MySqlCommand com1 = new MySqlCommand(q2, conn);
                                        com1.ExecuteNonQuery();
                                        break;
                                    }
                                    else if (Convert.ToInt32(row2.Cells["quantity"].Value) < Convert.ToInt32(row.Cells["quantity"].Value))
                                    {
                                        string salequantity = row2.Cells["quantity"].Value.ToString();
                                        string olquantity = row.Cells["quantity"].Value.ToString();
                                        string quantityleft = (Convert.ToInt32(olquantity) - Convert.ToInt32(salequantity)).ToString();

                                        string q2 = "update saleinventory set saleinventory.quantity = 0 where saleinventory.saleid = '" + saleid + "';" +
                                                    "insert into stockout(productid, quantity, reason) values('" + prodid2 + "','" + salequantity + "','" + reason + " and Replaced');";
                                        MySqlCommand com1 = new MySqlCommand(q2, conn);
                                        com1.ExecuteNonQuery();
                                        row.Cells["quantity"].Value = Convert.ToInt32(quantity) - Convert.ToInt32(quantityleft);
                                        dataGridView1.Rows.Add(orderlineid, pid, pname, price, quantityleft, Convert.ToDouble(price) * Convert.ToDouble(quantityleft), reason, "Replace", "Throw");
                                        break;
                                    }
                                }
                                else
                                {
                                    continue;
                                }
                            }
                        }
                        else if (action == "Re-Stock")
                        {
                            string upd1 = "set foreign_key_checks=0;insert into saleinventory(productid, quantity, expiry, purchaseid,stockinlineid) values (" + prodid + "," + row.Cells["quantity"].Value.ToString() + ",'" + DateTime.Now.AddYears(99).ToString("yyyy/MM/dd") + "', (select si.purchaseid from saleinventory si, orderline ol where si.saleid=ol.saleid and ol.orderlineid='" + orderlineid + "'), '" + (Convert.ToInt32(getstockinlineid()) + 1) + "')"
                            + ";insert into stockin(date) values(now()); insert into stockinline(stockinid, productid, quantity, expirydate, date, purchaseid, deliverynumber,pdid) values ('" + getstockinid() + "', '" + prodid + "', '" + row.Cells["quantity"].Value.ToString() + "', '" + DateTime.Now.AddYears(99).ToString("yyyy/MM/dd") + "','" + DateTime.Now.ToString("yyyy/MM/dd hh:mm:ss") + "' " +
                            ",(select si.purchaseid from saleinventory si, orderline ol where si.saleid=ol.saleid and ol.orderlineid='" + orderlineid + "'),(select * from(select deliverynumber from stockinline where purchaseid=(select si.purchaseid from saleinventory si, orderline ol where si.saleid=ol.saleid and ol.orderlineid='" + orderlineid + "') and productid = '" + prodid + "' group by productid) as temp),(select * from(select pdid from stockinline where purchaseid=(select si.purchaseid from saleinventory si, orderline ol where si.saleid=ol.saleid and ol.orderlineid='" + orderlineid + "') and productid = '" + prodid + "' group by productid) as temp));";
                            MySqlCommand com1 = new MySqlCommand(upd1, conn);
                            com1.ExecuteNonQuery();

                            string saleinv = "select * from saleinventory where productid='" + row.Cells["productid"].Value.ToString() + "'";
                            MySqlCommand comm1 = new MySqlCommand(saleinv, conn);
                            MySqlDataAdapter adp = new MySqlDataAdapter(comm1); //used on select query only
                            DataTable dt = new DataTable();
                            adp.Fill(dt);

                            dataGridView2.DataSource = dt;

                            string pid = row.Cells["productid"].Value.ToString();
                            string pname = row.Cells["productname"].Value.ToString();
                            string quantity = row.Cells["quantity"].Value.ToString();
                            string reason = row.Cells["productstatus"].Value.ToString();
                            string price = row.Cells["selling_price"].Value.ToString();
                            foreach (DataGridViewRow row2 in dataGridView2.Rows)
                            {
                                if (Convert.ToInt32(row2.Cells["quantity"].Value) > 0)
                                {
                                    string saleid = row2.Cells["saleid"].Value.ToString();
                                    string prodid2 = row2.Cells["productid"].Value.ToString();
                                    if (Convert.ToInt32(row2.Cells["quantity"].Value) >= Convert.ToInt32(row.Cells["quantity"].Value))
                                    {
                                        string q2 = "update saleinventory set saleinventory.quantity = saleinventory.quantity - '" + quantity + "' where saleinventory.saleid = '" + saleid + "';" +
                                                    "insert into stockout(productid, quantity, reason) values('" + prodid2 + "','" + quantity + "','" + reason + " and Replaced')";
                                        MySqlCommand com2 = new MySqlCommand(q2, conn);
                                        com2.ExecuteNonQuery();
                                        break;
                                    }
                                    else if (Convert.ToInt32(row2.Cells["quantity"].Value) < Convert.ToInt32(row.Cells["quantity"].Value))
                                    {
                                        string salequantity = row2.Cells["quantity"].Value.ToString();
                                        string olquantity = row.Cells["quantity"].Value.ToString();
                                        string quantityleft = (Convert.ToInt32(olquantity) - Convert.ToInt32(salequantity)).ToString();

                                        string q2 = "update saleinventory set saleinventory.quantity = 0 where saleinventory.saleid = '" + saleid + "';" +
                                                    "insert into stockout(productid, quantity, reason) values('" + prodid2 + "','" + salequantity + "','" + reason + " and Replaced');";
                                        MySqlCommand com2 = new MySqlCommand(q2, conn);
                                        com2.ExecuteNonQuery();
                                        row.Cells["quantity"].Value = Convert.ToInt32(quantity) - Convert.ToInt32(quantityleft);
                                        dataGridView1.Rows.Add(orderlineid, pid, pname, price, quantityleft, Convert.ToDouble(price) * Convert.ToDouble(quantityleft), reason, "Replace", "Throw");
                                        break;
                                    }
                                }
                                else
                                {
                                    continue;
                                }
                            }
                        }
                    }
                    else if (row.Cells["returntype"].Value.ToString() == "Refund")
                    {
                        if (action == "Throw")
                        {
                        }
                        else if (action == "Re-Stock")
                        {
                            string upd1 = "set foreign_key_checks=0;insert into saleinventory(productid, quantity, expiry, purchaseid,stockinlineid) values (" + prodid + "," + row.Cells["quantity"].Value.ToString() + ",'" + DateTime.Now.AddYears(99).ToString("yyyy/MM/dd") + "', (select si.purchaseid from saleinventory si, orderline ol where si.saleid=ol.saleid and ol.orderlineid='"+orderlineid+ "'), '" + (Convert.ToInt32(getstockinlineid()) + 1) + "')"
                            + ";insert into stockin(date) values(now()); insert into stockinline(stockinid, productid, quantity, expirydate, date, purchaseid, deliverynumber,pdid) values ('" + getstockinid() + "', '" + prodid + "', '" + row.Cells["quantity"].Value.ToString() + "', '" + DateTime.Now.AddYears(99).ToString("yyyy/MM/dd") + "','" + DateTime.Now.ToString("yyyy/MM/dd hh:mm:ss") + "' "+
                            ",(select si.purchaseid from saleinventory si, orderline ol where si.saleid=ol.saleid and ol.orderlineid='" + orderlineid + "'),(select * from(select deliverynumber from stockinline where purchaseid=(select si.purchaseid from saleinventory si, orderline ol where si.saleid=ol.saleid and ol.orderlineid='" + orderlineid + "') and productid = '"+prodid+ "' group by productid) as temp),(select * from(select pdid from stockinline where purchaseid=(select si.purchaseid from saleinventory si, orderline ol where si.saleid=ol.saleid and ol.orderlineid='" + orderlineid + "') and productid = '" + prodid + "' group by productid) as temp));";
                            MySqlCommand com1 = new MySqlCommand(upd1, conn);
                            com1.ExecuteNonQuery();
                        }
                        string ins = "insert into refund(date, amount, returnlineid) values ('" + DateTime.Now.ToString("yyyy/MM/dd hh:mm:ss") + "', '" + row.Cells["subtotal"].Value.ToString() + "', '" + getreturnlineid() + "');";
                        MySqlCommand comm2 = new MySqlCommand(ins, conn);
                        comm2.ExecuteNonQuery();
                    }

                }
                string q = "update orders set type = 'Returned' where orderid='" + comboBox1.Text + "'";
                MySqlCommand setq = new MySqlCommand(q, conn);
                setq.ExecuteNonQuery();
                MessageBox.Show("Return Submitted");
                submittedorder = true;
                this.Close();
            }
        }
        private string getproducttype(int productid)
        {
            string q = "select producttype from product where productid = '"+productid+"'";
            MySqlCommand com = new MySqlCommand(q, conn);
            return com.ExecuteScalar().ToString();
        }
        private int getreturnid()
        {
            string q = "select count(*) from creamsncrumbs.`return`";
            MySqlCommand comm = new MySqlCommand(q, conn);
            return Convert.ToInt32(comm.ExecuteScalar());
        }
        private void filltype()
        {
            comboBox2.Items.Add("Replace");
            comboBox2.Items.Add("Refund");

            comboBox3.Items.Add("Damaged");
            comboBox3.Items.Add("Expired");
            comboBox3.Items.Add("Good");

            comboBox4.Items.Add("Throw");
            comboBox4.Items.Add("Re-Stock");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            
            
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_Leave(object sender, EventArgs e)
        {
            if (!grid1_pressed)
            {
                MessageBox.Show("Please select");
            }
            else
            {
                if (string.IsNullOrWhiteSpace(textBox1.Text))
                {
                    
                }
                else if (Convert.ToInt32(textBox1.Text) > Convert.ToInt32(dataGridView3[4, dataGridView3.CurrentRow.Index].Value))
                {
                    MessageBox.Show("Invalid Quantity");
                }
                else
                {

                }
            }         
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
        private int getstockinid()
        {
            string q = "select count(*) from stockin";
            MySqlCommand comm = new MySqlCommand(q, conn);
            return Convert.ToInt32(comm.ExecuteScalar()) + 1;
        }
        private int getreturnlineid()
        {
            string q = "select count(*) from returnline";
            MySqlCommand comm = new MySqlCommand(q, conn);
            return Convert.ToInt32(comm.ExecuteScalar());
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string prodid = dataGridView3["productid", dataGridView3.CurrentRow.Index].Value.ToString();
            string prodtype = getprodtype(prodid);
            if (prodtype == "Consumable")
            {
                comboBox4.Items.Clear();
                comboBox4.Items.Add("Throw");
            }
            else if (prodtype == "Non-Consumable")
            {
                comboBox4.Items.Clear();
                comboBox4.Items.Add("Throw");
                comboBox4.Items.Add("Re-Stock");
            }
            grid1_pressed = true;
        }
        double rtotal = 0;
        private void button3_Click_1(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(comboBox1.Text))
            {
                MessageBox.Show("Select Order");
            }
            else if(string.IsNullOrWhiteSpace(textBox1.Text) ||
                string.IsNullOrWhiteSpace(comboBox2.Text) ||
                string.IsNullOrWhiteSpace(comboBox3.Text) ||
                string.IsNullOrWhiteSpace(comboBox4.Text))
            {
                MessageBox.Show("Empty Field/s");
            }
            else
            {
                string oid = dataGridView3["orderlineid", dataGridView3.CurrentRow.Index].Value.ToString();
                string pid = dataGridView3["productid", dataGridView3.CurrentRow.Index].Value.ToString();
                string productname = dataGridView3["productname", dataGridView3.CurrentRow.Index].Value.ToString();
                string sellingprice =  dataGridView3["selling_price", dataGridView3.CurrentRow.Index].Value.ToString();
                string subtotal = (Convert.ToInt32(textBox1.Text) * Convert.ToDouble(sellingprice)).ToString();
                rtotal += Convert.ToDouble(subtotal);
                label5.Text = rtotal.ToString();
                dataGridView1.Rows.Add(oid, pid, productname, textBox1.Text,sellingprice, subtotal, comboBox3.Text, comboBox2.Text, comboBox4.Text);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
