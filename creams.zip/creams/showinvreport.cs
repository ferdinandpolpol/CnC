﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

namespace creams
{
    public partial class showinvreport : Form
    {
        MySqlConnection conn;
        public showinvreport()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;convert zero datetime=True");
        }
        public static DateTime opening;
        private void showinvreport_Load(object sender, EventArgs e)
        {
            if (inventoryreport.generate1)
            {
                DateTime fromdate = inventoryreport.fromdate;
                DateTime todate = inventoryreport.todate;
                string query = "SELECT si.saleid, si.productid, p.productname, p.productunit, SUM(si.quantity) as quantity, p.selling_price," +
                        "(select sum(quantity) from stockinline where productid=si.productid and date between '" + fromdate.ToString("yyyy-MM-dd") + "' and '" + (todate).AddDays(1).AddSeconds(-1).ToString("yyyy-MM-dd HH:mm") + "') as 'stock-ins'," + 
                        "(select sum(quantity) from stockout where productid = si.productid and reason = 'Sales' and date between '"+fromdate.ToString("yyyy-MM-dd")+"' and '"+ (todate).AddDays(1).AddSeconds(-1).ToString("yyyy-MM-dd HH:mm") + "') as 'sales'," +
                        "(select sum(quantity) from stockout where productid = si.productid and reason = 'Production' and date between '" + fromdate.ToString("yyyy-MM-dd") + "' and '" + (todate).AddDays(1).AddSeconds(-1).ToString("yyyy-MM-dd HH:mm") + "') as 'production'," +
                        "(select sum(quantity) from stockout where productid = si.productid and reason = 'Damaged' and date between '" + fromdate.ToString("yyyy-MM-dd") + "' and '" + (todate).AddDays(1).AddSeconds(-1).ToString("yyyy-MM-dd HH:mm") + "') as 'damaged'," +
                        "(select sum(quantity) from stockout where productid = si.productid and reason = 'Expired' and date between '" + fromdate.ToString("yyyy-MM-dd") + "' and '" + (todate).AddDays(1).AddSeconds(-1).ToString("yyyy-MM-dd HH:mm") + "') as 'expired'" +
                        "FROM " +
                            "saleinventory si," +
                            "product p " +
                        "WHERE " +
                            "si.productid = p.productid " +
                        "GROUP BY p.productid " +
                        "ORDER BY p.productname DESC";
                conn.Open();
                MySqlCommand comm = new MySqlCommand(query, conn);
                MySqlDataAdapter adp = new MySqlDataAdapter(comm);
                DataSet1 ds = new DataSet1();
                ds.Clear();
                adp.Fill(ds);
                conn.Close();

                CrystalReport1 objRpt = new CrystalReport1();
                objRpt.SetDataSource(ds.Tables[1]);

                ParameterFieldDefinitions crParameterFieldDefinitions;
                ParameterFieldDefinition crParameterFieldDefinition;
                ParameterValues crParameterValues = new ParameterValues();
                ParameterDiscreteValue crParameterDiscreteValue = new ParameterDiscreteValue();

                crParameterDiscreteValue.Value = fromdate.ToString("yyyy-MM-dd HH:mm");
                crParameterFieldDefinitions = objRpt.DataDefinition.ParameterFields;
                crParameterFieldDefinition = crParameterFieldDefinitions["fromDate"];
                crParameterValues = crParameterFieldDefinition.CurrentValues;

                crParameterValues.Clear();
                crParameterValues.Add(crParameterDiscreteValue);
                crParameterFieldDefinition.ApplyCurrentValues(crParameterValues);

                crParameterDiscreteValue.Value = (todate).AddDays(1).AddSeconds(-1).ToString("yyyy-MM-dd HH:mm");
                crParameterFieldDefinitions = objRpt.DataDefinition.ParameterFields;
                crParameterFieldDefinition = crParameterFieldDefinitions["toDate"];
                crParameterValues = crParameterFieldDefinition.CurrentValues;

                crParameterValues.Clear();
                crParameterValues.Add(crParameterDiscreteValue);
                crParameterFieldDefinition.ApplyCurrentValues(crParameterValues);

                crystalReportViewer1.ReportSource = objRpt;
                crystalReportViewer1.Refresh();
            }
            else if (inventoryreport.generate2)
            {
                string s = System.IO.Directory.GetCurrentDirectory().ToString();
                opening = DateTime.Now;

                int x = s.IndexOf("bin\\Debug");
                if (x != -1)
                {
                    s = s.Remove(x);
                }
                s += "CrystalReport3.rpt";
                crystalReportViewer1.Visible = true;
                ReportDocument cryRpt = new ReportDocument();
                cryRpt.Load(@s);

                crystalReportViewer1.ReportSource = cryRpt;
                crystalReportViewer1.Refresh();
            }
            else if (inventoryreport.generate3)
            {
                string query = "SELECT si.saleid, si.productid, p.productname, p.productunit, SUM(si.quantity) as quantity, p.selling_price," +
                        "(select sum(quantity) from stockinline where productid=si.productid and date between '" + DateTime.Now.ToString("yyyy-MM-dd 00:00") + "' and now()) as 'stock-ins'," +
                        "(select sum(quantity) from stockout where productid = si.productid and reason = 'Sales' and date between '" + DateTime.Now.ToString("yyyy-MM-dd 00:00") + "' and '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm") + "') as 'sales'," +
                        "(select sum(quantity) from stockout where productid = si.productid and reason = 'Production' and date between '" + DateTime.Now.ToString("yyyy-MM-dd 00:00") + "' and '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm") + "') as 'production'," +
                        "(select sum(quantity) from stockout where productid = si.productid and reason = 'Damaged' and date between '" + DateTime.Now.ToString("yyyy-MM-dd 00:00") + "' and '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm") + "') as 'damaged'," +
                        "(select sum(quantity) from stockout where productid = si.productid and reason = 'Expired' and date between '" + DateTime.Now.ToString("yyyy-MM-dd 00:00") + "' and '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm") + "') as 'expired'" +
                        "FROM " +
                            "saleinventory si," +
                            "product p " +
                        "WHERE " +
                            "si.productid = p.productid " +
                        "GROUP BY p.productid " +
                        "ORDER BY p.productname DESC";
                conn.Open();
                MySqlCommand comm = new MySqlCommand(query, conn);
                MySqlDataAdapter adp = new MySqlDataAdapter(comm);
                DataSet1 ds = new DataSet1();
                ds.Clear();
                adp.Fill(ds);
                
                conn.Close();

                CrystalReport1 objRpt = new CrystalReport1();
                objRpt.SetDataSource(ds.Tables[1]);

                ParameterFieldDefinitions crParameterFieldDefinitions;
                ParameterFieldDefinition crParameterFieldDefinition;
                ParameterValues crParameterValues = new ParameterValues();
                ParameterDiscreteValue crParameterDiscreteValue = new ParameterDiscreteValue();

                crParameterDiscreteValue.Value = DateTime.Now.ToString("yyyy-MM-dd 00:00");
                crParameterFieldDefinitions = objRpt.DataDefinition.ParameterFields;
                crParameterFieldDefinition = crParameterFieldDefinitions["fromDate"];
                crParameterValues = crParameterFieldDefinition.CurrentValues;

                crParameterValues.Clear();
                crParameterValues.Add(crParameterDiscreteValue);
                crParameterFieldDefinition.ApplyCurrentValues(crParameterValues);

                crParameterDiscreteValue.Value = DateTime.Now.ToString("yyyy-MM-dd HH:mm");
                crParameterFieldDefinitions = objRpt.DataDefinition.ParameterFields;
                crParameterFieldDefinition = crParameterFieldDefinitions["toDate"];
                crParameterValues = crParameterFieldDefinition.CurrentValues;

                crParameterValues.Clear();
                crParameterValues.Add(crParameterDiscreteValue);
                crParameterFieldDefinition.ApplyCurrentValues(crParameterValues);

                crystalReportViewer1.ReportSource = objRpt;
                crystalReportViewer1.Refresh();
            }
            else if (inventoryreport2.prodbutton1)
            {
                string query = "SELECT productioninventoryid, transferid, pi.productname, SUM(quantity) as quantity, pi.unit,"+
                                "(select sum(quantity) from productionstockout where productname = pi.productname and unit = pi.unit and reason = 'Production' and date between '"+inventoryreport2.fromDate+"' and '"+inventoryreport2.toDate+"') as 'Used',"+
                                "(select sum(quantity) from productionstockout where productname = pi.productname and unit = pi.unit and reason = 'Damaged' and date between '" + inventoryreport2.fromDate + "' and '" + inventoryreport2.toDate + "') as 'Damaged'," +
                                "(select sum(quantity) from productionstockout where productname = pi.productname and unit = pi.unit and reason = 'Expired' and date between '" + inventoryreport2.fromDate + "' and '" + inventoryreport2.toDate + "') as 'Expired' " +
                            "FROM productioninventory pi "+
                            "WHERE quantity > 0 "+
                            "GROUP BY productname , unit";
                conn.Open();
                MySqlCommand comm = new MySqlCommand(query, conn);
                MySqlDataAdapter adp = new MySqlDataAdapter(comm);
                DataSet2 ds = new DataSet2();
                ds.Clear();
                adp.Fill(ds);
                conn.Close();

                CrystalReport4 objRpt = new CrystalReport4();
                objRpt.SetDataSource(ds.Tables[1]);

                ParameterFieldDefinitions crParameterFieldDefinitions;
                ParameterFieldDefinition crParameterFieldDefinition;
                ParameterValues crParameterValues = new ParameterValues();
                ParameterDiscreteValue crParameterDiscreteValue = new ParameterDiscreteValue();

                crParameterDiscreteValue.Value = inventoryreport2.fromDate;
                crParameterFieldDefinitions = objRpt.DataDefinition.ParameterFields;
                crParameterFieldDefinition = crParameterFieldDefinitions["fromDate"];
                crParameterValues = crParameterFieldDefinition.CurrentValues;

                crParameterValues.Clear();
                crParameterValues.Add(crParameterDiscreteValue);
                crParameterFieldDefinition.ApplyCurrentValues(crParameterValues);

                crParameterDiscreteValue.Value = inventoryreport2.toDate;
                crParameterFieldDefinitions = objRpt.DataDefinition.ParameterFields;
                crParameterFieldDefinition = crParameterFieldDefinitions["toDate"];
                crParameterValues = crParameterFieldDefinition.CurrentValues;

                crParameterValues.Clear();
                crParameterValues.Add(crParameterDiscreteValue);
                crParameterFieldDefinition.ApplyCurrentValues(crParameterValues);

                crystalReportViewer1.ReportSource = objRpt;
                crystalReportViewer1.Refresh();
            }
            else if (inventoryreport2.prodbutton2)
            {
                string s = System.IO.Directory.GetCurrentDirectory().ToString();
                opening = DateTime.Now;

                int x = s.IndexOf("bin\\Debug");
                if (x != -1)
                {
                    s = s.Remove(x);
                }
                s += "CrystalReport6.rpt";
                crystalReportViewer1.Visible = true;
                ReportDocument cryRpt = new ReportDocument();
                cryRpt.Load(@s);

                crystalReportViewer1.ReportSource = cryRpt;
                crystalReportViewer1.Refresh();
            }
            else if (inventoryreport2.prodbutton3)
            {
                string query = "SELECT productioninventoryid, transferid, pi.productname, SUM(quantity) as quantity, pi.unit," +
                                "(select sum(quantity) from productionstockout where productname = pi.productname and unit = pi.unit and reason = 'Production' and date between '" + DateTime.Now.ToString("yyyy-MM-dd 00:00") + "' and '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm") + "') as 'Used'," +
                                "(select sum(quantity) from productionstockout where productname = pi.productname and unit = pi.unit and reason = 'Damaged' and date between '" + DateTime.Now.ToString("yyyy-MM-dd 00:00") + "' and '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm") + "') as 'Damaged'," +
                                "(select sum(quantity) from productionstockout where productname = pi.productname and unit = pi.unit and reason = 'Expired' and date between '" + DateTime.Now.ToString("yyyy-MM-dd 00:00") + "' and '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm") + "') as 'Expired' " +
                            "FROM productioninventory pi " +
                            "WHERE quantity > 0 " +
                            "GROUP BY productname , unit";
                conn.Open();
                MySqlCommand comm = new MySqlCommand(query, conn);
                MySqlDataAdapter adp = new MySqlDataAdapter(comm);
                DataSet2 ds = new DataSet2();
                ds.Clear();
                adp.Fill(ds);
                conn.Close();

                CrystalReport4 objRpt = new CrystalReport4();
                objRpt.SetDataSource(ds.Tables[1]);

                ParameterFieldDefinitions crParameterFieldDefinitions;
                ParameterFieldDefinition crParameterFieldDefinition;
                ParameterValues crParameterValues = new ParameterValues();
                ParameterDiscreteValue crParameterDiscreteValue = new ParameterDiscreteValue();

                crParameterDiscreteValue.Value = DateTime.Now.ToString("yyyy-MM-dd 00:00");
                crParameterFieldDefinitions = objRpt.DataDefinition.ParameterFields;
                crParameterFieldDefinition = crParameterFieldDefinitions["fromDate"];
                crParameterValues = crParameterFieldDefinition.CurrentValues;

                crParameterValues.Clear();
                crParameterValues.Add(crParameterDiscreteValue);
                crParameterFieldDefinition.ApplyCurrentValues(crParameterValues);

                crParameterDiscreteValue.Value = DateTime.Now.ToString("yyyy-MM-dd HH:mm");
                crParameterFieldDefinitions = objRpt.DataDefinition.ParameterFields;
                crParameterFieldDefinition = crParameterFieldDefinitions["toDate"];
                crParameterValues = crParameterFieldDefinition.CurrentValues;

                crParameterValues.Clear();
                crParameterValues.Add(crParameterDiscreteValue);
                crParameterFieldDefinition.ApplyCurrentValues(crParameterValues);

                crystalReportViewer1.ReportSource = objRpt;
                crystalReportViewer1.Refresh();
            }
        }
    }
}
