﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace creams
{
    public partial class inventorylist : Form
    {
        MySqlConnection conn;
        public inventorylist()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;");
        }

        private void inventorylist_Load(object sender, EventArgs e)
        {
            if (newsalesorder.active || neworder.active)
            {
                textBox2.Text = getrowcount();
            }
            else if (newproduction.active)
                textBox2.Text = productionlist.orderid;
            refreshdatabase();
        }

        private void refreshdatabase()
        {
            if(neworder.active == true)
            {
                conn.Open();
                string query = "select * from product where producttype = 'Food'";
                MySqlCommand comm = new MySqlCommand(query, conn);
                MySqlDataAdapter adp = new MySqlDataAdapter(comm);
                DataTable dt = new DataTable();
                adp.Fill(dt);

                dataGridView1.DataSource = dt;
                conn.Close();
                dataGridView1.Columns["purchase_price"].Visible = false;
                dataGridView1.Columns["reorderpoint"].Visible = false;
                dataGridView1.Columns["productid"].HeaderText = "ID";
                dataGridView1.Columns["productname"].HeaderText = "Name of Product";
                dataGridView1.Columns["selling_price"].HeaderText = "Prices";
                dataGridView1.Columns["productunit"].HeaderText = "Unit";
            }
            else if(newsalesorder.active == true || newproduction.active)
            {
                string query = "select si.saleid, si.productid, p.productname, p.productunit, sum(si.quantity), p.selling_price from saleinventory si, product p where si.productid=p.productid and quantity > 0 group by p.productid order by p.productname desc ";
                MySqlCommand comm = new MySqlCommand(query, conn);
                MySqlDataAdapter adp = new MySqlDataAdapter(comm);
                DataTable dt = new DataTable();
                adp.Fill(dt);

                dataGridView1.DataSource = dt;
                dataGridView1.Columns["saleid"].Visible = false;
                dataGridView1.Columns["productid"].Visible = false;
                dataGridView1.Columns["selling_price"].Visible = false;
                dataGridView1.Columns["productname"].HeaderText = "Name of Product";
                dataGridView1.Columns["selling_price"].HeaderText = "Prices";
                dataGridView1.Columns["productunit"].HeaderText = "Unit";
                dataGridView1.Columns[4].HeaderText = "Current Quantity";
            }
            //showlow();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            neworder.active = false;
            newsalesorder.active = false;
            newproduction.active = false;
            this.Close();
        }
        private string getrowcount()
        {
            conn.Open();
            MySqlCommand comm = new MySqlCommand("select count(*) from orders", conn);

            Int32 norows = Convert.ToInt32(comm.ExecuteScalar());
            conn.Close();
            return norows.ToString();
        }

        //Add Product in orderline button
        private void button2_Click(object sender, EventArgs e)
        {
            conn.Close();
            conn.Open();
            if(neworder.active == true)
            {
                
                if (grid1_pressed == false)
                {
                    MessageBox.Show("Please select a product");
                }
                else
                {
                    string productid = dataGridView1[0, dataGridView1.CurrentRow.Index].Value.ToString();
                    string prodid = "select productid from orderline where orderid='" + textBox2.Text + "' and productid='" + productid + "'";
                    MySqlCommand check = new MySqlCommand(prodid, conn);
                    MySqlDataAdapter adp = new MySqlDataAdapter(check);
                    DataTable dt = new DataTable();
                    adp.Fill(dt);

                    //0 quantity checker
                    string qty = "select quantity from saleinventory where productid='" + productid + "'";
                    MySqlCommand checkqty = new MySqlCommand(qty, conn);
                    checkqty.ExecuteNonQuery();
                    Int32 quantity = Convert.ToInt32(checkqty.ExecuteScalar());
                    conn.Close();

                    if (dt.Rows.Count > 0)
                    {
                        MessageBox.Show("Product already added to order!");

                    }
                    else
                    {

                        string productname = dataGridView1[2, dataGridView1.CurrentRow.Index].Value.ToString();
                        string selling_price = dataGridView1["selling_price", dataGridView1.CurrentRow.Index].Value.ToString();
                        

                        conn.Open();
                        string query = "set foreign_key_checks=0;insert into orderline(orderid, saleid, productid, productname, selling_price, subtotal) values('"
                            + textBox2.Text + "','0','" + productid + "','" + productname + "','" + selling_price + "','" + selling_price + "')";
                        MySqlCommand comm = new MySqlCommand(query, conn);
                        comm.ExecuteNonQuery();

                        conn.Close();
                        MessageBox.Show("Added product " + productname);
                        this.Close();
                    }
                }
            }
            else if(newsalesorder.active == true)
            {
                
                if (grid1_pressed == false)
                {
                    MessageBox.Show("Please select a product");
                }
                else
                {
                    string productid = dataGridView1[1, dataGridView1.CurrentRow.Index].Value.ToString();
                    string prodid = "select productid from orderline where orderid='" + textBox2.Text + "' and productid='" + productid + "'";
                    MySqlCommand check = new MySqlCommand(prodid, conn);
                    MySqlDataAdapter adp = new MySqlDataAdapter(check);
                    DataTable dt = new DataTable();
                    adp.Fill(dt);

                    conn.Close();

                    if (dt.Rows.Count > 0)
                    {
                        MessageBox.Show("Product Added");

                    }
                    else if(dataGridView1[4, dataGridView1.CurrentRow.Index].Value.ToString() == 0.ToString())
                    {
                        MessageBox.Show("No Stocks");
                    }
                    else
                    {

                        string productname = dataGridView1[2, dataGridView1.CurrentRow.Index].Value.ToString();
                        string selling_price = dataGridView1["selling_price", dataGridView1.CurrentRow.Index].Value.ToString();
                        string saleid = dataGridView1["saleid", dataGridView1.CurrentRow.Index].Value.ToString();

                        conn.Open();
                        string query = "set foreign_key_checks=0;insert into orderline(orderid, saleid, productid, productname, selling_price, subtotal) values('"
                            + textBox2.Text + "','"+saleid+"','" + productid + "','" + productname + "','" + selling_price + "','" + selling_price + "')";
                        MySqlCommand comm = new MySqlCommand(query, conn);
                        comm.ExecuteNonQuery();

                        conn.Close();
                        MessageBox.Show("Added product " + productname);
                        this.Close();
                    }
                }
            }
            else if (newproduction.active == true)
            {
                string productid = dataGridView1[1, dataGridView1.CurrentRow.Index].Value.ToString();
                if (grid1_pressed == false)
                {
                    MessageBox.Show("Please select a product");
                }
                else
                {
                    string prodid = "select productid from productioninventory where productionid='" + productionlist.productionid + "' and productid='" + productid + "'";
                    MySqlCommand check = new MySqlCommand(prodid, conn);
                    MySqlDataAdapter adp = new MySqlDataAdapter(check);
                    DataTable dt = new DataTable();
                    adp.Fill(dt);

                    //0 quantity checker
                    string qty = "select quantity from saleinventory where productid='" + productid + "'";
                    MySqlCommand checkqty = new MySqlCommand(qty, conn);
                    checkqty.ExecuteNonQuery();
                    Int32 quantity = Convert.ToInt32(checkqty.ExecuteScalar());
                    conn.Close();

                    if (dt.Rows.Count > 0)
                    {
                        MessageBox.Show("Product already added to order!");

                    }
                    else if (dataGridView1[4, dataGridView1.CurrentRow.Index].Value.ToString() == 0.ToString())
                    {
                        MessageBox.Show("No stocks of current product");
                    }
                    else
                    {

                        string productname = dataGridView1[1, dataGridView1.CurrentRow.Index].Value.ToString();
                        string purchase_price = dataGridView1["purchase_price", dataGridView1.CurrentRow.Index].Value.ToString();
                        string saleid = dataGridView1["saleid", dataGridView1.CurrentRow.Index].Value.ToString();

                        conn.Open();
                        string query = "set foreign_key_checks=0;insert into productioninventory(productionid, saleid, productid, quantity, subtotal) values('"
                            + productionlist.productionid + "','" + saleid + "','" + productid + "','1','" + purchase_price + "')";
                        MySqlCommand comm = new MySqlCommand(query, conn);
                        comm.ExecuteNonQuery();

                        conn.Close();
                        MessageBox.Show("Added product " + productname);
                        this.Close();
                    }
                    
                }
            }
            

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
        bool grid1_pressed = false;
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            grid1_pressed = true;
        }
        private void inventorylist_FormClosing(object sender, FormClosingEventArgs e)
        {
        }

        private void searchtxtbox_TextChanged_1(object sender, EventArgs e)
        {
            conn.Close();
            conn.Open();
            string query = "select si.saleid, si.productid, p.productname, p.productunit, sum(si.quantity), p.selling_price from saleinventory si, product p where si.productid=p.productid and p.productname like '%"+searchtxtbox.Text+"%' group by p.productid order by p.productname desc ";
            MySqlCommand comm = new MySqlCommand(query, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView1.DataSource = dt;
            dataGridView1.Columns["saleid"].Visible = false;
            dataGridView1.Columns["productid"].Visible = false;
            dataGridView1.Columns["selling_price"].Visible = false;
            dataGridView1.Columns["productname"].HeaderText = "Name of Product";
            dataGridView1.Columns["selling_price"].HeaderText = "Prices";
            dataGridView1.Columns["productunit"].HeaderText = "Unit";
            dataGridView1.Columns[4].HeaderText = "Current Quantity";
        }

        private void inventorylist_FormClosing_1(object sender, FormClosingEventArgs e)
        {
            neworder.active = false;
            newsalesorder.active = false;
            newproduction.active = false;
        }

        /*private void showlow()
        {
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if (Convert.ToInt32(row.Cells["quantity"].Value) <= 0)
                {
                    row.DefaultCellStyle.BackColor = Color.Maroon;
                }
                else if (Convert.ToInt32(row.Cells["quantity"].Value) <= 5)
                {
                    row.DefaultCellStyle.BackColor = Color.IndianRed;

                }
                else if (Convert.ToInt32(row.Cells["quantity"].Value) <= 10)
                {
                    row.DefaultCellStyle.BackColor = Color.Orange;
                }
            }
        }*/
    }
}
