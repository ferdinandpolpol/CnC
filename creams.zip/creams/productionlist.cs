﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace creams
{
    public partial class productionlist : Form
    {
        MySqlConnection conn;
        public static string orderid;
        public static string deliveryid;
        public static string productionid;
        public static string customer;
        public static bool active;
        public productionlist()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;");
        }

        private void productionlist_Load(object sender, EventArgs e)
        {
            conn.Open();
            refreshdatabase();
            showneardelivery();
            if (delivery)
            {
                MessageBox.Show("Orders near delivery: \n" + string.Join(Environment.NewLine, neardelivery));
            }
        }
        private void refreshdatabase()
        {
            if (dataGridView1.Columns.Contains("remaining"))
            {
                dataGridView1.Columns.Remove("remaining");
            }
            MySqlCommand comm = new MySqlCommand("SELECT CONCAT(c.lastname, ', ', c.firstname) as 'Customer',GROUP_CONCAT(DISTINCT CONCAT(ol.quantity, ' ', ol.productname)) AS 'Orders',d.*,p.status FROM delivery d,customer c,orders o,orderline ol, payments p  WHERE d.customerid = c.customerid and d.orderid = o.orderid and o.orderid = ol.orderid and p.orderid=o.orderid group by orderid", conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm); //used on select query only
            DataTable dt = new DataTable();
            adp.Fill(dt);

            //Loads the database values to the dataGridView
            dataGridView1.DataSource = dt;
            dataGridView1.Columns["deliveryid"].HeaderText = "Delivery #";
            dataGridView1.Columns["orderid"].HeaderText = "Order #";
            dataGridView1.Columns["deliveryaddress"].HeaderText = "Address";
            dataGridView1.Columns["deliverydate"].HeaderText = "Deliver By";
            dataGridView1.Columns["productionstatus"].HeaderText = "Production";
            dataGridView1.Columns["status"].HeaderText = "Payment";
            dataGridView1.Columns["date"].HeaderText = "Order Created";
            dataGridView1.Columns["customerid"].Visible = false;
            showfinished();
            showundelivered();

            dataGridView1.Columns.Add("remaining","Days to Delivery");
            countremaining();

            string q1 = "select p.date, p.orderid, p.deliveryid, p.productionid from production p, delivery d, orders o where o.orderid=p.orderid and d.deliveryid=p.deliveryid and d.orderid=o.orderid ";
            MySqlCommand comm1 = new MySqlCommand(q1, conn);
            MySqlDataAdapter adp1 = new MySqlDataAdapter(comm1); //used on select query only
            DataTable dt1 = new DataTable();
            adp1.Fill(dt1);

            dataGridView2.DataSource = dt1;
            dataGridView2.Columns[0].HeaderText = "Date produced";
            dataGridView2.Columns[1].HeaderText = "Order #";
            dataGridView2.Columns[2].HeaderText = "Delivery #";
            dataGridView2.Columns[3].Visible = false;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            orderid = dataGridView1["orderid", dataGridView1.CurrentRow.Index].Value.ToString();
            label3.Text = deliveryid = dataGridView1["deliveryid", dataGridView1.CurrentRow.Index].Value.ToString();
            customer = dataGridView1[0, dataGridView1.CurrentRow.Index].Value.ToString();
            if (dataGridView1["productionstatus", dataGridView1.CurrentRow.Index].Value.ToString() == "Finished")
            {
                button7.Enabled = false;
                button7.BackColor = Color.Gray;
            }
            else if (dataGridView1["productionstatus", dataGridView1.CurrentRow.Index].Value.ToString() == "Undelivered")
            {
                button7.Enabled = true;
                button7.BackColor = Color.Firebrick;
            }
            else
            {
                button7.BackColor = Color.Firebrick;
                button7.Enabled = true;
                DateTime deliverydate = Convert.ToDateTime(dataGridView1["deliverydate", dataGridView1.CurrentRow.Index].Value);
            }
            
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(label3.Text))
            {
                MessageBox.Show("Choose an order");
            }
            else
            {
                if(dataGridView1["status", dataGridView1.CurrentRow.Index].Value.ToString() == "Pending")
                {
                    DialogResult dr = MessageBox.Show(@"Pending Payment. Do you want to proceed to production?",
                                               Application.ProductName,
                                               MessageBoxButtons.YesNo);
                    if (dr == DialogResult.Yes)
                    {
                        getproductionid();
                        newproduction np = new newproduction();
                        np.ShowDialog();
                        refreshdatabase();
                    }
                    else if (dr == DialogResult.No)
                    {
                        
                    }
                }
                else
                {
                    getproductionid();
                    newproduction np = new newproduction();
                    np.ShowDialog();
                    refreshdatabase();
                }
                
            }   
        }
        private void getproductionid()
        {
            conn.Close();
            conn.Open();
            string q = "select count(*) from production";
            MySqlCommand comm = new MySqlCommand(q, conn);
            productionid = (Convert.ToInt32(comm.ExecuteScalar()) + 1).ToString();
            conn.Close();
        }

        private void productionlist_FormClosing(object sender, FormClosingEventArgs e)
        {
            conn.Close();
        }
        private void showfinished()
        {
            conn.Close();
            conn.Open();
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if ((string)row.Cells["productionstatus"].Value == "Finished")
                {
                    row.Cells["productionstatus"].Style.BackColor = Color.LightGreen;
                    row.ReadOnly = true;
                }
            }
        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {
            showfinished();
        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            showfinished();
        }

        private void dataGridView1_RowHeaderCellChanged(object sender, DataGridViewRowEventArgs e)
        {
            showfinished();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            orderid = orderid = dataGridView1["orderid", dataGridView1.CurrentRow.Index].Value.ToString();
            active = true;
            orderdetails od = new orderdetails();
            od.ShowDialog();
            active = false;
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
        private void showundelivered()
        {
            foreach(DataGridViewRow row in dataGridView1.Rows)
            {
                DateTime deliverydate = Convert.ToDateTime(row.Cells["deliverydate"].Value);
                int remaining = (deliverydate - DateTime.Now).Days;
                if (remaining < 0 && row.Cells["productionstatus"].Value.ToString() != "Finished")
                {
                    row.Cells["productionstatus"].Value = "Undelivered";
                }
                else if(remaining > 0 && row.Cells["productionstatus"].Value.ToString() != "Cancelled" && row.Cells["productionstatus"].Value.ToString() != "Finished")
                {
                    row.Cells["productionstatus"].Value = "In Progress";
                }
            }
        }
        bool delivery;
        List<string> neardelivery = new List<string>();
        private void showneardelivery()
        {
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                DateTime deliverydate = Convert.ToDateTime(row.Cells["deliverydate"].Value);
                int remaining = (deliverydate - DateTime.Now).Days;
                if (remaining < 5 && row.Cells["productionstatus"].Value.ToString() == "In Progress")
                {
                    row.Cells["deliverydate"].Style.BackColor = Color.LightCoral;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            deliverydetails del = new deliverydetails();
            del.ShowDialog();
            refreshdatabase();
        }

        private void button3_Click(object sender, EventArgs e)
        {
        }

        private void home_neworderbtn_Click(object sender, EventArgs e)
        {
            conn.Close();
            conn.Open();
            string q = "set foreign_key_checks=0;insert into orders values('" + getorderid() + "','0','" + getstaffid() + "','0',now(),'0','Sale')";
            MySqlCommand comm = new MySqlCommand(q, conn);
            comm.ExecuteNonQuery();
            conn.Close();
            neworder neword = new creams.neworder();
            neword.ShowDialog();
            refreshdatabase();
            conn.Close();
        }
        private string getorderid()
        {
            MySqlCommand comm = new MySqlCommand("select count(*) from orders", conn);
            Int32 norows = Convert.ToInt32(comm.ExecuteScalar());
            norows += 1;
            return norows.ToString();
        }
        private string getstaffid()
        {
            //checks user privilege
            string query = "select staffid from staff where username like '" + loginform.currentuser + "'";
            MySqlCommand comm = new MySqlCommand(query, conn);

            string id = Convert.ToString(comm.ExecuteScalar());
            return id;
        }
        private void countremaining()
        {
            foreach(DataGridViewRow row in dataGridView1.Rows)
            {
                DateTime expirydate = Convert.ToDateTime(row.Cells["deliverydate"].Value);
                string remaining = (Convert.ToInt32((expirydate - DateTime.Now).Days) + 1).ToString();
                if(Convert.ToInt32(remaining) <= 0)
                {
                    row.Cells["remaining"].Value = 0;
                }
                else
                {
                    row.Cells["remaining"].Value = remaining;
                }
            }
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            orderid = orderid = dataGridView1["orderid", dataGridView1.CurrentRow.Index].Value.ToString();
            active = true;
            orderdetails od = new orderdetails();
            od.ShowDialog();
            active = false;
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string pid = dataGridView2[3, dataGridView2.CurrentRow.Index].Value.ToString();
            string oid = dataGridView2[1, dataGridView2.CurrentRow.Index].Value.ToString();
            string q = "select sum(pl.quantity),pi.unit,pi.productname from productionline pl, productioninventory pi, production p where pl.productioninventoryid=pi.productioninventoryid and p.productionid=pl.productionid and pl.productionid = '" + pid+"' group by productname";
            MySqlCommand comm1 = new MySqlCommand(q, conn);
            MySqlDataAdapter adp1 = new MySqlDataAdapter(comm1); //used on select query only
            DataTable dt1 = new DataTable();
            adp1.Fill(dt1);

            dataGridView3.DataSource = dt1;
            dataGridView3.Columns[0].HeaderText = "Quantity";
            dataGridView3.Columns[1].HeaderText = "Unit";
            dataGridView3.Columns[2].HeaderText = "Ingredient";

            string q2 = "select orderline.productid,product.productname, orderline.quantity from orderline, orders, product where orderline.productid=product.productid and orderline.orderid=orders.orderid and orders.orderid='" + oid + "'";
            MySqlCommand comm = new MySqlCommand(q2, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView4.DataSource = dt;
            dataGridView4.Columns["productid"].Visible = false;
            dataGridView4.Columns["productname"].HeaderText = "Product";
            dataGridView4.Columns["quantity"].HeaderText = "Quantity";
        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
