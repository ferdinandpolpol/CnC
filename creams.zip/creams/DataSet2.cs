﻿namespace creams
{


    partial class DataSet2
    {
        partial class DataTable1DataTable
        {
        }
    }
}
