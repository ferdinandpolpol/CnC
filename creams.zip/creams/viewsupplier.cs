﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace creams
{
    public partial class viewsupplier : Form
    {
        public MySqlConnection conn;
        public viewsupplier()
        {
            InitializeComponent();
            conn = new MySqlConnection("Server=localhost;Database=creamsncrumbs;Uid=root;Pwd=root;");
        }

        private void addcustomerbtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            newsupplier ns = new newsupplier();
            ns.ShowDialog();
            this.Show();
            refreshdatabase();
        }

        private void viewsupplier_Load(object sender, EventArgs e)
        {
            refreshdatabase();
        }
        private void refreshdatabase()
        {
            string q = "select * from supplier";
            MySqlCommand comm = new MySqlCommand(q, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm); //used on select query only
            DataTable dt = new DataTable();
            adp.Fill(dt);

            //Loads the database values to the dataGridView
            dataGridView1.DataSource = dt;
            dataGridView1.Columns["supplierid"].Visible = false;
            dataGridView1.Columns["suppliername"].HeaderText = "Supplier Name";
            dataGridView1.Columns["suppliercontact"].HeaderText = "Contact Number";
            dataGridView1.Columns["supplieraddress"].HeaderText = "Address";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            refreshdatabase();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
